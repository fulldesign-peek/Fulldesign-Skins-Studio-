Fulldesign Skins Studio - atualização de texturas MDL

1. Envie MainActivity.java para a raiz do repositório GitHub e faça Commit changes.
2. No Codespaces, execute:
   git pull origin main
   cp MainActivity.java app/src/main/java/com/fulldesign/skinstudio/MainActivity.java
   ./gradlew assembleDebug
3. O APK será gerado em app/build/outputs/apk/debug/app-debug.apk.

Esta versão adiciona leitura de tabelas de textura em modelos GoldSrc MDL v10 e substituição dos pixels de uma textura interna por conversão para a paleta existente. Teste em cópias dos modelos. Não modifica geometria/UVs nem texturas WAD.
