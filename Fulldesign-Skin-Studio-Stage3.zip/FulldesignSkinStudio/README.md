# Fulldesign Skin Studio

Aplicativo Android Java para edição de imagens de texturas e preparação de arquivos para packs de skins do Counter-Strike 1.6 Mobile. O projeto não inclui modelos, armas ou outros arquivos protegidos do jogo: importe seus próprios arquivos.

## Implementado nesta versão

### Idiomas
- Seletor persistente de idioma na tela inicial e no Pack Mixer: português, espanhol, russo e inglês.
- As opções são apresentadas como `Português`, `Español`, `Русский` e `English`; a seleção é salva e usada nas duas telas.
- Ao trocar o idioma dentro do Pack Mixer, o código reconstrói a interface preservando o modelo, o ZIP, a seleção de textura, o FOV e os valores X/Y/Z.
- As labels e mensagens mais comuns das telas principais são traduzidas localmente, sem acesso à internet.

### Skin Lab
- Importa PNG, JPEG e BMP usando o seletor de arquivos do Android.
- Ajusta brilho, contraste, saturação, matiz e nitidez sem sobrescrever a imagem original.
- Redimensiona texturas ou mantém as dimensões de trabalho.
- Exporta BMP RGB de 24 bits ou BMP indexado real de 8 bits com paleta, alinhamento de linhas e ordem bottom-up.
- Converte para até 256 cores com dithering Floyd–Steinberg opcional e máscara configurável.

### Pack Mixer / Editor MDL
- Importa ZIP com limites de segurança e rejeita caminhos de extração que escapem da pasta temporária.
- Lista modelos `.mdl` e imagens externas; o ZIP original nunca é alterado.
- Lê o cabeçalho GoldSrc Studio MDL v10 e a tabela de texturas nos campos corretos (`numtextures` no byte 180 e `textureindex` no byte 184).
- Mostra a prévia real de texturas indexadas embutidas e permite substituir os pixels usando a paleta existente do próprio modelo.
- Inclui um visualizador OpenGL ES 2.0 de geometria real: converte comandos de triangle strip/fan em triângulos, aplica a pose padrão dos ossos, usa UVs e texturas do MDL e permite girar por arraste e aproximar/afastar com pinça. O parser visualiza a primeira opção do primeiro bodypart.
- Mantém bytes fora do plano de pixels escolhido, incluindo cabeçalho, geometria, UVs, animações, tabelas e paleta.
- Mantém o índice transparente 255 para texturas marcadas como masked quando a imagem de entrada contém alpha transparente.
- Pode substituir em lote texturas embutidas quando os nomes-base de imagens do ZIP correspondem exatamente aos nomes de textura do MDL (sem extensão).
- **Aplicação de braço/luva em lote:** permite marcar uma textura de um modelo de referência como textura de braço e outra como textura de luva. O app percorre os outros MDLs no ZIP e aplica as texturas aos slots cujos nomes identificam braços, mãos, mangas ou luvas. A paleta do modelo de destino é mantida e os pixels são redimensionados para suas dimensões. Modelos sem slots semanticamente identificáveis são ignorados, para não substituir por engano a textura da arma.
- Exporta o modelo editado ou o pack ZIP completo com um arquivo auxiliar de configurações.

### Origem X/Y/Z e FOV
- Controles de passo e movimento X/Y/Z geram uma diretiva `$origin` para uso com o QC original.
- O app **não altera diretamente a origem da geometria do MDL compilado**. Para aplicar `$origin`, é necessário usar o arquivo QC/SMD de origem e recompilar o modelo.
- FOV é salvo como metadado em `fulldesign_project_settings.txt`. Não é gravado dentro do BMP ou de uma tabela de textura MDL; o cliente Android precisa dar suporte à configuração para que ela tenha efeito no jogo.

## Limitações explícitas

- O visualizador 3D é uma primeira etapa: mostra a malha estática na pose padrão, usando o primeiro bodypart/modelo. Não reproduz sequências de animação, não permite selecionar bodygroups alternativos, nem oferece edição de esqueleto, hitboxes, attachments ou QC Source como o Paranoia 2 Model Viewer.
- A edição de origem via `$origin` depende de fontes QC/SMD e de um compilador GoldSrc compatível, que não está embutido no aplicativo.
- A substituição da textura é limitada a texturas embutidas que possam ser validadas no arquivo. Modelos concatenados, corrompidos, com dados externos ou variantes fora da especificação v10 podem ser recusados.
- A aplicação em lote de braço/luva é uma troca de **texturas**, não uma transferência de geometria, ossos ou animações. Ela depende de slots de textura com nomes reconhecíveis (por exemplo, `hands`, `gloves`, `arms`, `sleeve`, `luvas` ou `braco`). Modelos que juntam a arma e as mãos numa única textura, usam nomes genéricos ou guardam os braços como geometria separada são ignorados e precisam de mapeamento/edição específicos. A seleção de bodygroup alternativo ainda não está implementada.
- Nesta entrega, o editor de imagem ainda não tem histórico desfazer/refazer, recorte, rotação/espelhamento nem salvamento de sessão editável; a importação, ajustes disponíveis e exportação BMP permanecem funcionais.
- O arquivo auxiliar de FOV não garante aplicação automática no CS 1.6 Mobile, pois clientes diferentes podem usar comandos distintos ou ignorar o valor.

## Aplicar braço e luva em várias skins

1. Importe o ZIP do pack de skins.
2. Abra, pela lista do pack, um modelo `.mdl` que contenha a textura de braço.
3. Selecione a textura na lista e pressione **Usar textura selecionada como braço**.
4. Abra o modelo que contenha a textura de luva, selecione sua textura e pressione **Usar textura selecionada como luva**. Se uma única textura contiver toda a parte desejada, ela pode ser usada para ambos os papéis, se isso corresponder ao modelo.
5. Pressione **Aplicar textura de braço/luva em lote**, revise o resumo e confirme.
6. Confira o resultado e exporte **Pack ZIP modificado**.

O app só altera slots reconhecidos pelo nome; ele não adivinha a região de uma textura genérica e não copia geometrias de braço para dentro de modelos de arma. Os modelos ignorados permanecem inalterados no pack de saída.

## Testes

O projeto inclui testes unitários para `BmpEncoder` e `GoldSrcMdl`, cobrindo o cabeçalho, paletas indexadas, preservação do arquivo durante substituição de pixels e leitura de malha. Nesta atualização foram feitos checks estáticos de estrutura do código e compilação independente da classe de parser; os testes Android e a interface não puderam ser executados neste ambiente.

O APK **não foi compilado neste ambiente**, pois não há Gradle/Android SDK instalado. Faça o build e os testes no Codespaces/GitHub Actions antes de considerar a versão pronta para instalar.

## Compilar no Codespaces

Use JDK 17 ou 21 e Gradle 8.13 com Android SDK plataforma 36 e Build Tools 36.0.0. Na raiz do repositório, no Codespaces onde o JDK 21 está instalado nesse caminho:

```bash
export JAVA_HOME=/usr/local/sdkman/candidates/java/21.0.7-amzn
export PATH="$JAVA_HOME/bin:$PATH"
java -version
gradle testDebugUnitTest
gradle assembleDebug
```

Se o seu Codespace instalou o JDK 21 em outro caminho, ajuste apenas o `JAVA_HOME`. Este ZIP não inclui `gradlew`; use o comando `gradle` disponível no ambiente ou gere o wrapper no repositório.

Se seu repositório tiver o Gradle Wrapper configurado, pode usar `./gradlew` no lugar de `gradle`.

O APK de depuração deverá ser gerado em:

```text
app/build/outputs/apk/debug/app-debug.apk
```

O workflow `.github/workflows/android.yml` prepara Java, Gradle e Android SDK, roda os testes e compila o APK em cada push.

## Referências de formato

- [Valve Software — `studio.h` / estruturas de Studio MDL](https://github.com/ValveSoftware/halflife/blob/master/engine/studio.h)
- [GoldSrc MDL Format — documentação de cabeçalho, textura e paleta](https://github.com/skyrim/hlviewer.js/blob/master/docs/MDL_Format.md)
- [GoldSrc Model Export Tutorial — texturas indexadas de 8 bits](https://www.the303.org/tutorials/gold_mdl.htm)
