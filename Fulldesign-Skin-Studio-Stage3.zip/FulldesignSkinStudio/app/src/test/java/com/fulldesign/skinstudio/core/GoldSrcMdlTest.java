package com.fulldesign.skinstudio.core;

import org.junit.Test;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import static org.junit.Assert.*;

public class GoldSrcMdlTest {
    @Test public void readsTextureTableFromCorrectHeaderOffsets() throws Exception {
        byte[] model = sampleModel(false);
        GoldSrcMdl.Info info = GoldSrcMdl.inspect(model);
        assertEquals(1, info.textureCount);
        assertEquals(244, info.textureTableOffset);
        List<GoldSrcMdl.Texture> textures = GoldSrcMdl.textures(model);
        assertEquals(1, textures.size());
        assertEquals("sample", textures.get(0).name);
        assertTrue(textures.get(0).embedded);
        assertEquals(2, textures.get(0).width);
        assertEquals(2, textures.get(0).height);
    }

    @Test public void decodesIndexedPixelsUsingEmbeddedPalette() throws Exception {
        byte[] model = sampleModel(false);
        GoldSrcMdl.Texture texture = GoldSrcMdl.textures(model).get(0);
        int[] pixels = GoldSrcMdl.decodePixels(model, texture);
        assertEquals(0xFF000000, pixels[0]);
        assertEquals(0xFFFF0000, pixels[1]);
        assertEquals(0xFF00FF00, pixels[2]);
        assertEquals(0xFF0000FF, pixels[3]);
    }

    @Test public void replaceChangesOnlyPixelPlaneAndPreservesModelTail() throws Exception {
        byte[] model = sampleModel(false);
        GoldSrcMdl.Texture t = GoldSrcMdl.textures(model).get(0);
        int[] replacement = {0xFF0000FF, 0xFF00FF00, 0xFFFF0000, 0xFF000000};
        byte[] edited = GoldSrcMdl.replaceTexture(model, t.index, replacement, 2, 2, false);
        assertEquals((byte) 3, edited[t.pixelOffset]);
        assertEquals((byte) 2, edited[t.pixelOffset + 1]);
        assertEquals((byte) 1, edited[t.pixelOffset + 2]);
        assertEquals((byte) 0, edited[t.pixelOffset + 3]);
        for (int i = 0; i < model.length; i++) {
            if (i < t.pixelOffset || i >= t.pixelOffset + 4) assertEquals("changed byte at " + i, model[i], edited[i]);
        }
    }

    @Test public void maskedTextureRetainsTransparentIndex255() throws Exception {
        byte[] model = sampleModel(true);
        GoldSrcMdl.Texture t = GoldSrcMdl.textures(model).get(0);
        int[] input = {0x00FFFFFF, 0xFFFF0000, 0xFF00FF00, 0xFF0000FF};
        byte[] edited = GoldSrcMdl.replaceTexture(model, 0, input, 2, 2, false);
        assertEquals((byte) 255, edited[t.pixelOffset]);
        assertEquals(0x00000000, GoldSrcMdl.decodePixels(edited, GoldSrcMdl.textures(edited).get(0))[0]);
    }

    @Test public void parsesRealTriangleCommandsForStaticViewer() throws Exception {
        byte[] model = sampleMeshModel();
        GoldSrcMdl.ModelPreview preview = GoldSrcMdl.parseModelForPreview(model);
        assertEquals("triangle_model", preview.modelName);
        assertEquals(1, preview.parts.size());
        assertEquals(3, preview.parts.get(0).positions.length / 3);
        assertEquals(6, preview.parts.get(0).texCoords.length);
        assertEquals(0, preview.parts.get(0).textureIndex);
    }

    private static byte[] sampleMeshModel() {
        // Non-overlapping header, texture, bodypart, model, mesh, vertex and triangle-command regions.
        byte[] b = sampleModel(false);
        int bodyPart = b.length;
        b = java.util.Arrays.copyOf(b, bodyPart + 76 + 112 + 20 + 3 + 36 + 2 + 26 + 2);
        int modelOffset = bodyPart + 76;
        int meshOffset = modelOffset + 112;
        int vertexBonesOffset = meshOffset + 20;
        int verticesOffset = vertexBonesOffset + 3;
        int commandsOffset = verticesOffset + 36;
        copy(b, 8, 64, "triangle_model");
        putInt(b, 72, b.length);
        putInt(b, 204, 1); putInt(b, 208, bodyPart);
        putInt(b, bodyPart + 64, 1); putInt(b, bodyPart + 68, 1); putInt(b, bodyPart + 72, modelOffset);
        putInt(b, modelOffset + 72, 1); putInt(b, modelOffset + 76, meshOffset);
        putInt(b, modelOffset + 80, 3); putInt(b, modelOffset + 84, vertexBonesOffset); putInt(b, modelOffset + 88, verticesOffset);
        putInt(b, meshOffset, 1); putInt(b, meshOffset + 4, commandsOffset); putInt(b, meshOffset + 8, 0);
        putInt(b, 200, commandsOffset + 28); putShort(b, commandsOffset + 28, 0);
        b[vertexBonesOffset] = 0; b[vertexBonesOffset + 1] = 0; b[vertexBonesOffset + 2] = 0;
        putFloat(b, verticesOffset, -1); putFloat(b, verticesOffset + 4, 0); putFloat(b, verticesOffset + 8, 0);
        putFloat(b, verticesOffset + 12, 1); putFloat(b, verticesOffset + 16, 0); putFloat(b, verticesOffset + 20, 0);
        putFloat(b, verticesOffset + 24, 0); putFloat(b, verticesOffset + 28, 1); putFloat(b, verticesOffset + 32, 0);
        putShort(b, commandsOffset, 3);
        putShort(b, commandsOffset + 2, 0); putShort(b, commandsOffset + 4, 0); putShort(b, commandsOffset + 6, 0); putShort(b, commandsOffset + 8, 0);
        putShort(b, commandsOffset + 10, 1); putShort(b, commandsOffset + 12, 0); putShort(b, commandsOffset + 14, 1); putShort(b, commandsOffset + 16, 0);
        putShort(b, commandsOffset + 18, 2); putShort(b, commandsOffset + 20, 0); putShort(b, commandsOffset + 22, 0); putShort(b, commandsOffset + 24, 1);
        putShort(b, commandsOffset + 26, 0);
        putInt(b, 72, b.length);
        return b;
    }

    private static void putShort(byte[] data, int offset, int value) { data[offset] = (byte) value; data[offset + 1] = (byte) (value >>> 8); }
    private static void putFloat(byte[] data, int offset, float value) { putInt(data, offset, Float.floatToIntBits(value)); }

    @Test public void rejectsNonGoldSrcAndOutOfRangeTextureTable() throws Exception {
        byte[] notMdl = sampleModel(false); notMdl[0] = 'X';
        try { GoldSrcMdl.inspect(notMdl); fail("Expected invalid IDST rejection"); }
        catch (IOException expected) { assertTrue(expected.getMessage().contains("IDST")); }

        byte[] invalid = sampleModel(false); putInt(invalid, 184, invalid.length - 10);
        try { GoldSrcMdl.textures(invalid); fail("Expected table bounds rejection"); }
        catch (IOException expected) { assertTrue(expected.getMessage().contains("tabela")); }
    }

    private static byte[] sampleModel(boolean masked) {
        int table = 244, recordSize = 80, pixels = table + recordSize, width = 2, height = 2;
        int paletteCountOffset = pixels + width * height;
        int paletteOffset = paletteCountOffset + 2;
        byte[] b = new byte[paletteOffset + 256 * 3];
        b[0] = 'I'; b[1] = 'D'; b[2] = 'S'; b[3] = 'T';
        putInt(b, 4, 10); copy(b, 8, 64, "sample_model"); putInt(b, 72, b.length);
        putInt(b, 180, 1); putInt(b, 184, table); putInt(b, 188, pixels);
        putInt(b, 192, 1); putInt(b, 196, 1);
        copy(b, table, 64, "sample"); putInt(b, table + 64, masked ? GoldSrcMdl.TEXTURE_FLAG_MASKED : 0);
        putInt(b, table + 68, width); putInt(b, table + 72, height); putInt(b, table + 76, pixels);
        b[pixels] = 0; b[pixels + 1] = 1; b[pixels + 2] = 2; b[pixels + 3] = 3;
        b[paletteCountOffset] = 0; b[paletteCountOffset + 1] = 1;
        b[paletteOffset] = 0; b[paletteOffset + 1] = 0; b[paletteOffset + 2] = 0;
        b[paletteOffset + 3] = (byte) 255; b[paletteOffset + 4] = 0; b[paletteOffset + 5] = 0;
        b[paletteOffset + 6] = 0; b[paletteOffset + 7] = (byte) 255; b[paletteOffset + 8] = 0;
        b[paletteOffset + 9] = 0; b[paletteOffset + 10] = 0; b[paletteOffset + 11] = (byte) 255;
        return b;
    }

    private static void putInt(byte[] data, int offset, int value) {
        data[offset] = (byte) value; data[offset + 1] = (byte) (value >>> 8);
        data[offset + 2] = (byte) (value >>> 16); data[offset + 3] = (byte) (value >>> 24);
    }
    private static void copy(byte[] data, int offset, int capacity, String value) {
        byte[] bytes = value.getBytes(StandardCharsets.US_ASCII);
        System.arraycopy(bytes, 0, data, offset, Math.min(capacity - 1, bytes.length));
    }
}
