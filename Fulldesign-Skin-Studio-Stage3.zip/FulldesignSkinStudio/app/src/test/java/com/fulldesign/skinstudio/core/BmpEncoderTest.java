package com.fulldesign.skinstudio.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import org.junit.Test;

public class BmpEncoderTest {
    @Test public void indexedBmpHasRealEightBitPaletteAndCorrectOffsets() {
        int[] palette = new int[]{0xFFFF0000, 0xFF00FF00, 0xFF0000FF};
        byte[] indices = new byte[]{0, 1, 2, 0, 2, 1}; // 3 x 2 image
        byte[] bmp = BmpEncoder.encodeIndexed(3, 2, indices, palette);
        ByteBuffer b = ByteBuffer.wrap(bmp).order(ByteOrder.LITTLE_ENDIAN);
        assertEquals('B', b.get(0));
        assertEquals('M', b.get(1));
        assertEquals(bmp.length, b.getInt(2));
        assertEquals(1078, b.getInt(10));
        assertEquals(40, b.getInt(14));
        assertEquals(3, b.getInt(18));
        assertEquals(2, b.getInt(22));
        assertEquals(1, Short.toUnsignedInt(b.getShort(26)));
        assertEquals(8, Short.toUnsignedInt(b.getShort(28)));
        assertEquals(256, b.getInt(46));
        assertEquals(0, b.get(54) & 255); // red palette entry's blue byte
        assertEquals(0, b.get(55) & 255);
        assertEquals(255, b.get(56) & 255);
        assertTrue(bmp.length >= 1078 + 8); // each 3-pixel row is padded to 4 bytes
    }

    @Test public void rgb24BmpHasCorrectBitDepthAndBottomUpRows() {
        int[] pixels = new int[]{0xFFFF0000, 0xFF00FF00, 0xFF0000FF}; // 3 x 1
        byte[] bmp = BmpEncoder.encodeRgb24(3, 1, pixels);
        ByteBuffer b = ByteBuffer.wrap(bmp).order(ByteOrder.LITTLE_ENDIAN);
        assertEquals(54, b.getInt(10));
        assertEquals(24, Short.toUnsignedInt(b.getShort(28)));
        assertEquals(12, b.getInt(34)); // 9 bytes + 3 bytes padding
        assertEquals(0, b.get(54) & 255); // blue pixel BGR
        assertEquals(0, b.get(55) & 255);
        assertEquals(255, b.get(56) & 255);
        assertEquals(255, b.get(58) & 255); // green pixel's G channel
    }

    @Test(expected = IllegalArgumentException.class)
    public void invalidIndexCountIsRejected() {
        BmpEncoder.encodeIndexed(2, 2, new byte[]{0, 1}, new int[]{0xFF000000});
    }
}
