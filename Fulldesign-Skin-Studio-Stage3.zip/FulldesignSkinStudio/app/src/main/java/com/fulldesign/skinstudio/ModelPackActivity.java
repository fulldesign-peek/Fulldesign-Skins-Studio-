package com.fulldesign.skinstudio;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.fulldesign.skinstudio.core.GoldSrcMdl;
import com.fulldesign.skinstudio.core.ImageProcessor;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/** Integrated pack/model inspector. Only embedded GoldSrc texture pixels are edited in MDL files. */
public class ModelPackActivity extends Activity {
    private static final int REQ_MODEL = 6101, REQ_PACK = 6102, REQ_REPLACEMENT = 6103,
            REQ_SAVE_MODEL = 6104, REQ_SAVE_PACK = 6105, REQ_SAVE_SETTINGS = 6106, REQ_SAVE_QC = 6107;
    private static final long MAX_ZIP_TOTAL = 150L * 1024 * 1024;
    private static final long MAX_ZIP_ENTRY = 32L * 1024 * 1024;
    private final List<PackEntry> packEntries = new ArrayList<>();

    private LinearLayout root, packList, textureList, originPanel;
    private TextView status, modelInfo, selectedTextureInfo, replacementInfo, fovValue;
    private ImageView modelTexturePreview, replacementPreview;
    private MdlGlViewer modelViewer;
    private String viewerMessage = "Importe um modelo para abrir a visualização 3D.";
    private Bitmap replacementBitmap;
    private String replacementName = "replacement";
    private String loadedModelName = "model.mdl";
    private byte[] modelBytes;
    private Uri standaloneModelUri;
    private PackEntry activePackModel;
    private boolean packMode;
    private File workRoot;
    private GoldSrcMdl.Texture selectedTexture;
    private List<GoldSrcMdl.Texture> textures = new ArrayList<>();
    private EditText xValue, yValue, zValue, stepValue;
    private SeekBar fovBar;
    private int fov = 90;
    private int viewerRefreshToken;
    private boolean busy;
    private TextureTemplate armTextureTemplate;
    private TextureTemplate gloveTextureTemplate;
    private TextView armTemplateInfo, gloveTemplateInfo;

    private static final class TextureTemplate {
        final String modelEntryName;
        final String textureName;
        final int textureIndex;
        final byte[] modelBytes;
        TextureTemplate(String modelEntryName, String textureName, int textureIndex, byte[] modelBytes) {
            this.modelEntryName = modelEntryName; this.textureName = textureName; this.textureIndex = textureIndex; this.modelBytes = modelBytes;
        }
    }

    private static final class DecodedBatchTexture {
        final String textureName;
        final int width, height;
        final Bitmap bitmap;
        DecodedBatchTexture(String textureName, int width, int height, Bitmap bitmap) {
            this.textureName = textureName; this.width = width; this.height = height; this.bitmap = bitmap;
        }
        void recycle() { if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle(); }
    }

    private static final class PackEntry {
        final String name;
        final boolean directory;
        final File original;
        File modified;
        PackEntry(String name, boolean directory, File original) {
            this.name = name; this.directory = directory; this.original = original;
        }
        File exportFile() { return modified != null ? modified : original; }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8, 9, 17));
        getWindow().setNavigationBarColor(Color.rgb(8, 9, 17));
        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(10, 11, 18));
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        TextView brand = text("FULLDESIGN  /  SKIN STUDIO", 12, cyan(), true);
        root.addView(brand);
        LanguageManager.addHomeSelector(this, root, this::refreshLanguagePreservingEditor);
        root.addView(text("Pack Mixer & MDL", 27, Color.WHITE, true), margins(-1, -2, 0, 4, 0, 0));
        root.addView(text("Inspeção de modelos GoldSrc e edição de pixels das texturas embutidas.", 13, muted(), false), margins(-1, -2, 0, 0, 0, 12));

        LinearLayout loadCard = card();
        loadCard.addView(section("Importar arquivos"));
        loadCard.addView(action("ABRIR MODELO .MDL", () -> chooseModel()), margins(-1, dp(46), 0, 10, 0, 0));
        loadCard.addView(action("IMPORTAR PACK ZIP", () -> choosePack()), margins(-1, dp(46), 0, 8, 0, 0));
        loadCard.addView(action("ESCOLHER IMAGEM DE SUBSTITUIÇÃO", () -> chooseReplacement()), margins(-1, dp(46), 0, 8, 0, 0));
        replacementPreview = new ImageView(this);
        replacementPreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        replacementPreview.setBackground(bg(Color.rgb(7, 8, 13), 10, border(), 1));
        loadCard.addView(replacementPreview, margins(-1, dp(110), 0, 8, 0, 0));
        replacementInfo = text("Nenhuma imagem de substituição selecionada.", 12, muted(), false);
        loadCard.addView(replacementInfo, margins(-1, -2, 0, 5, 0, 0));
        root.addView(loadCard, margins(-1, -2, 0, 0, 0, 12));

        LinearLayout modelCard = card();
        modelCard.addView(section("Modelo selecionado"));
        modelInfo = text("Importe um .mdl ou um pack ZIP para inspecionar o cabeçalho e as texturas reais.", 12, muted(), false);
        modelInfo.setLineSpacing(dp(3), 1f);
        modelCard.addView(modelInfo, margins(-1, -2, 0, 7, 0, 0));
        modelCard.addView(text("VISUALIZADOR 3D · TOQUE E ARRASTE PARA GIRAR", 11, cyan(), true), margins(-1, -2, 0, 10, 0, 5));
        modelViewer = new MdlGlViewer(this);
        modelViewer.setBackgroundColor(Color.rgb(9, 12, 22));
        modelCard.addView(modelViewer, margins(-1, dp(260), 0, 0, 0, 8));
        modelCard.addView(action("CENTRALIZAR VISUALIZAÇÃO", () -> modelViewer.resetView()), margins(-1, dp(40), 0, 0, 0, 14));
        modelCard.addView(text("TEXTURAS EMBUTIDAS", 11, cyan(), true), margins(-1, -2, 0, 12, 0, 5));
        textureList = new LinearLayout(this); textureList.setOrientation(LinearLayout.VERTICAL);
        modelCard.addView(textureList);
        selectedTextureInfo = text("Selecione uma textura abaixo para ver os pixels decodificados do próprio .mdl.", 12, muted(), false);
        modelCard.addView(selectedTextureInfo, margins(-1, -2, 0, 10, 0, 0));
        modelTexturePreview = new ImageView(this);
        modelTexturePreview.setAdjustViewBounds(true);
        modelTexturePreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        modelTexturePreview.setBackground(bg(Color.rgb(7, 8, 13), 10, border(), 1));
        modelCard.addView(modelTexturePreview, margins(-1, dp(210), 0, 7, 0, 0));
        modelCard.addView(action("SUBSTITUIR TEXTURA SELECIONADA", () -> confirmReplaceTexture()), margins(-1, dp(48), 0, 10, 0, 0));
        modelCard.addView(action("USAR TEXTURA SELECIONADA COMO BRAÇO", () -> setBatchTextureTemplate(true)), margins(-1, dp(46), 0, 8, 0, 0));
        armTemplateInfo = text("Textura de braço de origem: Nenhuma textura definida", 11, muted(), false);
        modelCard.addView(armTemplateInfo, margins(-1, -2, 0, 2, 0, 0));
        modelCard.addView(action("USAR TEXTURA SELECIONADA COMO LUVA", () -> setBatchTextureTemplate(false)), margins(-1, dp(46), 0, 8, 0, 0));
        gloveTemplateInfo = text("Textura de luva de origem: Nenhuma textura definida", 11, muted(), false);
        modelCard.addView(gloveTemplateInfo, margins(-1, -2, 0, 2, 0, 0));
        modelCard.addView(text("Troca em lote opcional: dentro do ZIP, nomes de imagens devem corresponder exatamente aos nomes das texturas do MDL (sem extensão).", 11, muted(), false), margins(-1, -2, 0, 2, 0, 0));
        modelCard.addView(action("TROCAR TEXTURAS POR NOME NO PACK", () -> replaceMatchingTexturesFromPack()), margins(-1, dp(48), 0, 7, 0, 0));
        modelCard.addView(action("EXPORTAR MODELO .MDL", () -> saveModelDialog()), margins(-1, dp(48), 0, 8, 0, 0));
        root.addView(modelCard, margins(-1, -2, 0, 0, 0, 12));

        LinearLayout packCard = card();
        packCard.addView(section("Conteúdo do pack"));
        packCard.addView(text("Arquivos importados são extraídos para uma pasta de trabalho isolada. O ZIP de origem não é sobrescrito.", 12, muted(), false));
        packCard.addView(text("Use o modelo aberto e a textura selecionada como origem. O aplicativo aplica essa textura aos slots de textura com nomes reconhecíveis de braço, mão, manga ou luva nos outros modelos MDL do ZIP.", 12, muted(), false), margins(-1, -2, 0, 10, 0, 0));
        packCard.addView(action("APLICAR TEXTURA DE BRAÇO/LUVA EM LOTE", () -> confirmBatchApplyArmGloveTexture()), margins(-1, dp(50), 0, 0, 0, 12));
        packList = new LinearLayout(this); packList.setOrientation(LinearLayout.VERTICAL);
        packCard.addView(packList, margins(-1, -2, 0, 8, 0, 0));
        packCard.addView(action("EXPORTAR PACK ZIP MODIFICADO", () -> savePack()), margins(-1, dp(48), 0, 9, 0, 0));
        root.addView(packCard, margins(-1, -2, 0, 0, 0, 12));

        LinearLayout transformCard = card();
        transformCard.addView(section("Origem do modelo · X / Y / Z"));
        transformCard.addView(text("Os controles geram uma diretiva $origin para QC. Eles não alteram diretamente as coordenadas internas do MDL compilado: a aplicação do novo origin exige recompilar o modelo a partir do QC/SMD original.", 12, muted(), false));
        stepValue = numberInput("Passo (ex.: 1.0)", "1.0");
        transformCard.addView(stepValue, margins(-1, dp(46), 0, 10, 0, 0));
        xValue = numberInput("X", "0.0"); yValue = numberInput("Y", "0.0"); zValue = numberInput("Z", "0.0");
        addAxis(transformCard, "X", xValue, -1); addAxis(transformCard, "Y", yValue, 0); addAxis(transformCard, "Z", zValue, 1);
        TextWatcher originWatcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { syncViewerOrigin(); }
            @Override public void afterTextChanged(Editable s) { }
        };
        xValue.addTextChangedListener(originWatcher); yValue.addTextChangedListener(originWatcher); zValue.addTextChangedListener(originWatcher);
        transformCard.addView(action("EXPORTAR DIRETIVA QC (.TXT)", () -> exportOriginQc()), margins(-1, dp(46), 0, 12, 0, 0));
        root.addView(transformCard, margins(-1, -2, 0, 0, 0, 12));

        LinearLayout settingsCard = card();
        settingsCard.addView(section("FOV do projeto"));
        LinearLayout fovRow = new LinearLayout(this); fovRow.setGravity(Gravity.CENTER_VERTICAL);
        fovRow.addView(text("FOV (metadado de projeto)", 13, Color.WHITE, true), new LinearLayout.LayoutParams(0, -2, 1f));
        fovValue = text("90", 20, cyan(), true); fovRow.addView(fovValue); settingsCard.addView(fovRow);
        fovBar = new SeekBar(this); fovBar.setMax(60); fovBar.setProgress(30);
        fovBar.setProgressTintList(android.content.res.ColorStateList.valueOf(purple()));
        fovBar.setThumbTintList(android.content.res.ColorStateList.valueOf(cyan()));
        fovBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { fov = 60 + progress; fovValue.setText(String.valueOf(fov)); }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        settingsCard.addView(fovBar, margins(-1, dp(44), 0, 4, 0, 0));
        settingsCard.addView(text("O FOV será incluído em um arquivo auxiliar do projeto/ZIP. A textura BMP e o MDL não armazenam um comando universal de FOV; o cliente Android precisa aceitar a configuração para que ela tenha efeito no jogo.", 11, muted(), false), margins(-1, -2, 0, 3, 0, 0));
        settingsCard.addView(action("EXPORTAR CONFIGURAÇÕES DO PROJETO", () -> exportSettings()), margins(-1, dp(46), 0, 10, 0, 0));
        root.addView(settingsCard, margins(-1, -2, 0, 0, 0, 12));

        LinearLayout statusCard = card(); statusCard.addView(section("Status"));
        status = text("Pronto para importar um modelo ou pack.", 12, Color.rgb(220, 224, 239), false); status.setLineSpacing(dp(3), 1f);
        statusCard.addView(status);
        root.addView(statusCard, margins(-1, -2, 0, 0, 0, 0));
        return scroll;
    }

    private void refreshLanguagePreservingEditor() {
        String oldX = xValue == null ? "0.0" : xValue.getText().toString();
        String oldY = yValue == null ? "0.0" : yValue.getText().toString();
        String oldZ = zValue == null ? "0.0" : zValue.getText().toString();
        String oldStep = stepValue == null ? "1.0" : stepValue.getText().toString();
        int oldFov = fov;
        int oldTextureIndex = selectedTexture == null ? -1 : selectedTexture.index;
        setContentView(buildUi());
        xValue.setText(oldX); yValue.setText(oldY); zValue.setText(oldZ); stepValue.setText(oldStep);
        fov = Math.max(60, Math.min(120, oldFov));
        fovBar.setProgress(fov - 60);
        fovValue.setText(String.valueOf(fov));
        renderPackEntries();
        if (modelBytes != null) {
            loadModelBytes();
            if (oldTextureIndex >= 0) {
                GoldSrcMdl.Texture restore = findTexture(oldTextureIndex);
                if (restore != null) selectTexture(restore);
            }
        }
        if (armTemplateInfo != null) armTemplateInfo.setText(LanguageManager.translate(this,
                "Textura de braço de origem") + ": " + (armTextureTemplate == null ? LanguageManager.translate(this, "Nenhuma textura definida") : armTextureTemplate.textureName + " · " + armTextureTemplate.modelEntryName));
        if (gloveTemplateInfo != null) gloveTemplateInfo.setText(LanguageManager.translate(this,
                "Textura de luva de origem") + ": " + (gloveTextureTemplate == null ? LanguageManager.translate(this, "Nenhuma textura definida") : gloveTextureTemplate.textureName + " · " + gloveTextureTemplate.modelEntryName));
        syncViewerOrigin();
        setStatus(LanguageManager.translate(this, "Idioma alterado. O modelo, o pack e as texturas selecionadas foram preservados."));
    }

    private void chooseModel() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/octet-stream", "model/vnd.valve.mdl", "*/*"});
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_MODEL);
    }

    private void choosePack() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip", "application/x-zip-compressed", "application/octet-stream"});
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_PACK);
    }

    private void chooseReplacement() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_REPLACEMENT);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == REQ_MODEL) {
                packMode = false; activePackModel = null; standaloneModelUri = uri; loadedModelName = displayName(uri, "model.mdl");
                modelBytes = readUri(uri, 32 * 1024 * 1024); loadModelBytes();
            } else if (requestCode == REQ_PACK) {
                readZip(uri); packMode = true; standaloneModelUri = null; renderPackEntries();
                setStatus("Pack lido com validação de caminho e limites de tamanho. Selecione um .mdl na lista para abrir as texturas.");
            } else if (requestCode == REQ_REPLACEMENT) {
                replacementName = displayName(uri, "replacement_image");
                replacementBitmap = ImageProcessor.decode(this, uri);
                replacementPreview.setImageBitmap(replacementBitmap);
                replacementInfo.setText(LanguageManager.translate(this, replacementName + " · " + replacementBitmap.getWidth() + "×" + replacementBitmap.getHeight()));
                setStatus("Imagem de substituição carregada. As texturas serão ajustadas às dimensões do modelo e convertidas para a paleta já embutida.");
            } else if (requestCode == REQ_SAVE_MODEL) {
                if (modelBytes != null) writeUri(uri, modelBytes);
                setStatus("Modelo exportado. A geometria e os dados não editados foram preservados.");
            } else if (requestCode == REQ_SAVE_PACK) {
                writePack(uri); setStatus("Pack exportado sem sobrescrever o ZIP original.");
            } else if (requestCode == REQ_SAVE_SETTINGS) {
                writeUri(uri, settingsText().getBytes(StandardCharsets.UTF_8)); setStatus("Configurações de projeto exportadas em arquivo auxiliar.");
            } else if (requestCode == REQ_SAVE_QC) {
                if (pendingQc == null) throw new IOException("Nenhuma diretiva QC pendente.");
                writeUri(uri, pendingQc.getBytes(StandardCharsets.UTF_8));
                setStatus("Diretiva $origin exportada. Use-a no QC original e recompile o modelo para aplicar a mudança.");
                pendingQc = null;
            }
        } catch (Exception e) { setStatus("Falha: " + safeMessage(e)); }
    }

    private void loadModelBytes() {
        selectedTexture = null;
        textures = new ArrayList<>();
        textureList.removeAllViews();
        modelTexturePreview.setImageDrawable(null);
        try {
            GoldSrcMdl.Info info = GoldSrcMdl.inspect(modelBytes);
            textures = GoldSrcMdl.textures(modelBytes);
            selectedTexture = null;
            modelTexturePreview.setImageDrawable(null);
            selectedTextureInfo.setText(LanguageManager.translate(this, "Selecione uma textura abaixo para pré-visualizar ou substituir seus pixels."));
            modelInfo.setText(LanguageManager.translate(this, "Arquivo: " + loadedModelName + "\nNome interno: " + info.name + "\nFormato: GoldSrc Studio MDL v" + info.version
                    + "\nTamanho declarado: " + info.declaredLength + " bytes\nTabela de texturas: " + info.textureCount + " entrada(s)\nFamílias de skin: " + info.skinFamilyCount));
            textureList.removeAllViews();
            int embeddedCount = 0;
            for (GoldSrcMdl.Texture t : textures) {
                if (t.embedded) embeddedCount++;
                String label = t.name + "  ·  " + t.width + "×" + t.height + (t.embedded ? " · paleta " + t.paletteCount : " · dados internos indisponíveis");
                Button b = action(label, () -> selectTexture(t));
                b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                textureList.addView(b, margins(-1, dp(44), 0, 3, 0, 0));
            }
            if (textures.isEmpty()) textureList.addView(text("Este modelo declara zero texturas.", 12, muted(), false));
            refresh3DViewer();
            setStatus("Modelo validado. " + embeddedCount + " textura(s) embutida(s) disponível(is). " + viewerMessage);
        } catch (Exception e) { modelInfo.setText(LanguageManager.translate(this, "Não foi possível ler o modelo: " + safeMessage(e))); textureList.removeAllViews(); throw new IllegalArgumentException(safeMessage(e)); }
    }

    private void refresh3DViewer() {
        if (modelViewer == null || modelBytes == null) return;
        final int token = ++viewerRefreshToken;
        final byte[] snapshot = modelBytes.clone();
        final List<GoldSrcMdl.Texture> textureSnapshot = new ArrayList<>(textures);
        viewerMessage = "Preparando a malha 3D…";
        new Thread(() -> {
            java.util.HashMap<Integer, Bitmap> bitmaps = new java.util.HashMap<>();
            String outcome;
            GoldSrcMdl.ModelPreview preview = null;
            try {
                preview = GoldSrcMdl.parseModelForPreview(snapshot);
                java.util.HashSet<Integer> used = new java.util.HashSet<>();
                for (GoldSrcMdl.MeshPart part : preview.parts) used.add(part.textureIndex);
                long totalPixels = 0;
                for (GoldSrcMdl.Texture t : textureSnapshot) {
                    if (!t.embedded || !used.contains(t.index)) continue;
                    long pixelsCount = (long) t.width * t.height;
                    if (totalPixels + pixelsCount > 6L * 1024 * 1024) continue;
                    int[] argb = GoldSrcMdl.decodePixels(snapshot, t);
                    bitmaps.put(t.index, Bitmap.createBitmap(argb, t.width, t.height, Bitmap.Config.ARGB_8888));
                    totalPixels += pixelsCount;
                }
                outcome = "Malha real carregada na pose padrão (estática). Arraste para girar e use pinça para zoom.";
            } catch (Exception e) {
                for (Bitmap bitmap : bitmaps.values()) if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
                bitmaps.clear();
                outcome = "3D indisponível para este modelo: " + safeMessage(e);
            }
            final GoldSrcMdl.ModelPreview finishedPreview = preview;
            final String finishedOutcome = outcome;
            final java.util.HashMap<Integer, Bitmap> finishedBitmaps = bitmaps;
            runOnUiThread(() -> {
                if (token != viewerRefreshToken || isFinishing()) {
                    for (Bitmap bitmap : finishedBitmaps.values()) if (!bitmap.isRecycled()) bitmap.recycle();
                    return;
                }
                viewerMessage = finishedOutcome;
                if (finishedPreview != null) {
                    modelViewer.setModel(finishedPreview, finishedBitmaps);
                    modelViewer.setOrigin(parseFloat(number(xValue), 0f), parseFloat(number(yValue), 0f), parseFloat(number(zValue), 0f));
                } else modelViewer.setModel(null, java.util.Collections.emptyMap());
                setStatus("Visualizador 3D: " + viewerMessage);
            });
        }, "Fulldesign-MDL-preview").start();
    }

    private void syncViewerOrigin() {
        if (modelViewer != null) modelViewer.setOrigin(parseFloat(number(xValue), 0f), parseFloat(number(yValue), 0f), parseFloat(number(zValue), 0f));
    }

    private void selectTexture(GoldSrcMdl.Texture t) {
        try {
            if (!t.embedded) { selectedTexture = null; modelTexturePreview.setImageDrawable(null); selectedTextureInfo.setText(LanguageManager.translate(this, "Esta entrada não possui pixels de textura embutidos editáveis.")); return; }
            int[] pixels = GoldSrcMdl.decodePixels(modelBytes, t);
            Bitmap preview = Bitmap.createBitmap(pixels, t.width, t.height, Bitmap.Config.ARGB_8888);
            modelTexturePreview.setImageBitmap(preview);
            selectedTexture = t;
            selectedTextureInfo.setText(LanguageManager.translate(this, t.name + " · " + t.width + "×" + t.height + " · " + t.paletteCount + " cores · " + (t.isMasked() ? "textura mascarada" : "textura opaca")));
            setStatus("Textura real decodificada do .mdl. O visualizador 3D mostra a malha estática extraída do modelo.");
        } catch (Exception e) { setStatus("Falha ao decodificar a textura: " + safeMessage(e)); }
    }

    private void confirmReplaceTexture() {
        if (selectedTexture == null) { toast("Selecione uma textura embutida primeiro."); return; }
        if (replacementBitmap == null) { toast("Escolha a imagem de substituição primeiro."); return; }
        new AlertDialog.Builder(this).setTitle(LanguageManager.translate(this, "Substituir textura:") + " " + selectedTexture.name)
                .setMessage(LanguageManager.translate(this, "O app vai redimensionar a imagem para") + " " + selectedTexture.width + "×" + selectedTexture.height + LanguageManager.translate(this, ", mapear para a paleta existente e manter o restante do MDL intacto. Continuar?"))
                .setNegativeButton(LanguageManager.translate(this, "Cancelar"), null).setPositiveButton(LanguageManager.translate(this, "Substituir"), (d, w) -> replaceSelectedTexture()).show();
    }

    private void replaceSelectedTexture() {
        if (busy) return;
        busy = true; setStatus("Convertendo a imagem para a paleta original do MDL…");
        final GoldSrcMdl.Texture target = selectedTexture;
        final Bitmap incoming = replacementBitmap;
        final byte[] originalData = modelBytes;
        new Thread(() -> {
            byte[] changed = null; String error = null;
            try {
                Bitmap scaled = Bitmap.createScaledBitmap(incoming, target.width, target.height, true);
                int[] pixels = new int[target.width * target.height];
                scaled.getPixels(pixels, 0, target.width, 0, 0, target.width, target.height);
                if (scaled != incoming) scaled.recycle();
                changed = GoldSrcMdl.replaceTexture(originalData, target.index, pixels, target.width, target.height, true);
            } catch (Exception e) { error = safeMessage(e); }
            final byte[] output = changed; final String fail = error;
            runOnUiThread(() -> {
                busy = false;
                if (fail != null) { setStatus("Substituição cancelada: " + fail); return; }
                modelBytes = output;
                if (activePackModel != null) {
                    try {
                        File out = safeOutputFile(activePackModel.name);
                        File parent = out.getParentFile(); if (parent != null) parent.mkdirs();
                        try (OutputStream stream = new BufferedOutputStream(new FileOutputStream(out))) { stream.write(output); }
                        activePackModel.modified = out;
                    } catch (Exception e) { setStatus("Textura editada em memória, mas não foi possível salvar no pack de trabalho: " + safeMessage(e)); return; }
                }
                try { textures = GoldSrcMdl.textures(modelBytes); refresh3DViewer(); selectedTexture = findTexture(target.index); if (selectedTexture != null) selectTexture(selectedTexture); }
                catch (Exception e) { setStatus("Textura escrita, mas a releitura falhou: " + safeMessage(e)); return; }
                setStatus("Textura substituída e validada. Salve o .mdl ou exporte o ZIP para usar no jogo.");
            });
        }).start();
    }

    private GoldSrcMdl.Texture findTexture(int index) { for (GoldSrcMdl.Texture t : textures) if (t.index == index) return t; return null; }

    private void replaceMatchingTexturesFromPack() {
        if (!packMode || activePackModel == null || modelBytes == null) {
            toast("Importe um ZIP e abra um .mdl que esteja dentro dele primeiro.");
            return;
        }
        final java.util.HashMap<String, File> imagesByName = new java.util.HashMap<>();
        for (PackEntry entry : packEntries) {
            if (entry.directory || !isImage(entry.name.toLowerCase(Locale.ROOT))) continue;
            String baseName = baseName(entry.name).toLowerCase(Locale.ROOT);
            if (!baseName.isEmpty() && !imagesByName.containsKey(baseName)) imagesByName.put(baseName, entry.exportFile());
        }
        final List<GoldSrcMdl.Texture> matching = new ArrayList<>();
        for (GoldSrcMdl.Texture texture : textures) {
            if (texture.embedded && imagesByName.containsKey(texture.name.toLowerCase(Locale.ROOT))) matching.add(texture);
        }
        if (matching.isEmpty()) {
            toast("Nenhuma correspondência exata encontrada. O nome do arquivo precisa ser igual ao nome da textura do MDL.");
            return;
        }
        final byte[] source = modelBytes.clone();
        busy = true;
        setStatus("Trocando " + matching.size() + " textura(s) por correspondência de nome…");
        new Thread(() -> {
            byte[] changed = source;
            String error = null;
            int applied = 0;
            try {
                for (GoldSrcMdl.Texture texture : matching) {
                    File imageFile = imagesByName.get(texture.name.toLowerCase(Locale.ROOT));
                    Bitmap decoded = decodeLocalImage(imageFile, texture.width, texture.height);
                    if (decoded == null) throw new IOException("Não foi possível decodificar a imagem " + imageFile.getName() + ".");
                    Bitmap scaled = decoded.getWidth() == texture.width && decoded.getHeight() == texture.height
                            ? decoded : Bitmap.createScaledBitmap(decoded, texture.width, texture.height, true);
                    int[] pixels = new int[texture.width * texture.height];
                    scaled.getPixels(pixels, 0, texture.width, 0, 0, texture.width, texture.height);
                    changed = GoldSrcMdl.replaceTexture(changed, texture.index, pixels, texture.width, texture.height, true);
                    if (scaled != decoded) scaled.recycle();
                    decoded.recycle();
                    applied++;
                }
                File output = safeOutputFile(activePackModel.name);
                File parent = output.getParentFile();
                if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("Não foi possível preparar a pasta de saída do modelo.");
                try (OutputStream stream = new BufferedOutputStream(new FileOutputStream(output))) { stream.write(changed); }
            } catch (Exception e) { error = safeMessage(e); }
            final byte[] outputBytes = changed;
            final String failure = error;
            final int changedCount = applied;
            runOnUiThread(() -> {
                busy = false;
                if (failure != null) { setStatus("Troca em lote interrompida: " + failure); return; }
                modelBytes = outputBytes;
                try { activePackModel.modified = safeOutputFile(activePackModel.name); }
                catch (IOException e) { setStatus("Modelo trocado, mas não foi possível registrar o arquivo no pack: " + safeMessage(e)); return; }
                loadModelBytes();
                setStatus("Troca em lote concluída: " + changedCount + " textura(s) substituída(s) por nome. Confira o preview e exporte o ZIP para aplicar no jogo.");
            });
        }, "Fulldesign-batch-textures").start();
    }

    private void setBatchTextureTemplate(boolean arm) {
        if (!packMode || activePackModel == null || modelBytes == null || selectedTexture == null || !selectedTexture.embedded) {
            toast("Importe um ZIP, abra um modelo de dentro dele e selecione uma textura embutida.");
            return;
        }
        TextureTemplate template = new TextureTemplate(activePackModel.name, selectedTexture.name,
                selectedTexture.index, modelBytes.clone());
        if (arm) {
            armTextureTemplate = template;
            if (armTemplateInfo != null) armTemplateInfo.setText(LanguageManager.translate(this,
                    "Textura de braço de origem") + ": " + template.textureName + " · " + template.modelEntryName);
        } else {
            gloveTextureTemplate = template;
            if (gloveTemplateInfo != null) gloveTemplateInfo.setText(LanguageManager.translate(this,
                    "Textura de luva de origem") + ": " + template.textureName + " · " + template.modelEntryName);
        }
        toast((arm ? "Textura de braço definida: " : "Textura de luva definida: ") + template.textureName);
    }

    private void confirmBatchApplyArmGloveTexture() {
        if (!packMode || packEntries.isEmpty() || (armTextureTemplate == null && gloveTextureTemplate == null)) {
            toast("Selecione um pack ZIP e defina pelo menos uma textura de origem como braço ou luva.");
            return;
        }
        final TextureTemplate arm = armTextureTemplate;
        final TextureTemplate glove = gloveTextureTemplate;
        String armLabel = arm == null ? "não definida" : arm.textureName + " (" + arm.modelEntryName + ")";
        String gloveLabel = glove == null ? "não definida" : glove.textureName + " (" + glove.modelEntryName + ")";
        new AlertDialog.Builder(this)
                .setTitle(LanguageManager.translate(this, "Aplicação de braço/luva em lote"))
                .setMessage(LanguageManager.translate(this, "Textura de braço de origem") + ": " + armLabel + "\n" +
                        LanguageManager.translate(this, "Textura de luva de origem") + ": " + gloveLabel + "\n\n" +
                        LanguageManager.translate(this, "O aplicativo procurará outros arquivos MDL no ZIP e substituirá somente slots de textura com nomes que indiquem braços, mãos, mangas ou luvas. Cada modelo mantém sua própria paleta e dimensões; modelos sem slots reconhecíveis serão ignorados." ) + "\n\n" +
                        LanguageManager.translate(this, "A função altera pixels de texturas embutidas, não transfere a geometria dos braços. Modelos que não tenham slots de braço/luva identificáveis serão ignorados."))
                .setNegativeButton(LanguageManager.translate(this, "Cancelar"), null)
                .setPositiveButton(LanguageManager.translate(this, "Aplicar em lote"), (d, which) -> runBatchArmGloveTexture(arm, glove))
                .show();
    }

    private void runBatchArmGloveTexture(TextureTemplate armTemplate, TextureTemplate gloveTemplate) {
        busy = true;
        setStatus("Preparando aplicação em lote de braço/luva…");
        new Thread(() -> {
            int changedModels = 0;
            int changedTextures = 0;
            int skippedModels = 0;
            int failedTextures = 0;
            String error = null;
            DecodedBatchTexture armSource = null;
            DecodedBatchTexture gloveSource = null;
            try {
                if (armTemplate != null) armSource = decodeBatchTemplate(armTemplate);
                if (gloveTemplate != null) gloveSource = decodeBatchTemplate(gloveTemplate);
                java.util.HashSet<String> sourceModelNames = new java.util.HashSet<>();
                if (armTemplate != null) sourceModelNames.add(armTemplate.modelEntryName);
                if (gloveTemplate != null) sourceModelNames.add(gloveTemplate.modelEntryName);

                for (PackEntry entry : packEntries) {
                    if (entry.directory || !entry.name.toLowerCase(Locale.ROOT).endsWith(".mdl") || sourceModelNames.contains(entry.name)) continue;
                    byte[] targetBytes;
                    List<GoldSrcMdl.Texture> targetTextures;
                    try {
                        targetBytes = readFile(entry.exportFile(), (int) MAX_ZIP_ENTRY);
                        targetTextures = GoldSrcMdl.textures(targetBytes);
                    } catch (Exception invalidModel) {
                        skippedModels++;
                        continue;
                    }
                    byte[] changed = targetBytes;
                    int perModel = 0;
                    for (GoldSrcMdl.Texture target : targetTextures) {
                        if (!target.embedded) continue;
                        if ((long) target.width * target.height > 4_194_304L) { failedTextures++; continue; }
                        boolean armSlot = isArmTextureSlot(target.name);
                        boolean handSlot = isHandTextureSlot(target.name);
                        boolean gloveSlot = isGloveTextureSlot(target.name);
                        boolean namedSlot = armSlot || handSlot || gloveSlot;
                        if (!namedSlot) continue;

                        DecodedBatchTexture chosen;
                        if (gloveSlot || (handSlot && gloveSource != null)) {
                            chosen = gloveSource != null ? gloveSource : armSource;
                        } else {
                            chosen = armSource != null ? armSource : gloveSource;
                        }
                        if (chosen == null) continue;
                        Bitmap scaled = null;
                        try {
                            Bitmap textureBitmap;
                            if (target.width == chosen.width && target.height == chosen.height) {
                                textureBitmap = chosen.bitmap;
                            } else {
                                scaled = Bitmap.createScaledBitmap(chosen.bitmap, target.width, target.height, true);
                                textureBitmap = scaled;
                            }
                            int[] pixels = new int[target.width * target.height];
                            textureBitmap.getPixels(pixels, 0, target.width, 0, 0, target.width, target.height);
                            changed = GoldSrcMdl.replaceTexture(changed, target.index, pixels, target.width, target.height, true);
                            perModel++;
                        } catch (Exception textureFailure) {
                            failedTextures++;
                        } finally {
                            if (scaled != null && !scaled.isRecycled()) scaled.recycle();
                        }
                    }
                    if (perModel > 0) {
                        File output = safeOutputFile(entry.name);
                        File parent = output.getParentFile();
                        if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("Não foi possível criar a pasta de saída de " + entry.name);
                        try (OutputStream stream = new BufferedOutputStream(new FileOutputStream(output))) { stream.write(changed); }
                        entry.modified = output;
                        changedModels++;
                        changedTextures += perModel;
                    } else {
                        skippedModels++;
                    }
                }
            } catch (Exception e) {
                error = safeMessage(e);
            } finally {
                if (armSource != null) armSource.recycle();
                if (gloveSource != null) gloveSource.recycle();
            }
            final int modelsDone = changedModels;
            final int texturesDone = changedTextures;
            final int skipped = skippedModels;
            final int failures = failedTextures;
            final String failure = error;
            runOnUiThread(() -> {
                busy = false;
                if (failure != null) {
                    setStatus("Aplicação em lote interrompida: " + failure + ". Os arquivos originais do ZIP continuam preservados.");
                    return;
                }
                renderPackEntries();
                if (modelsDone == 0) {
                    setStatus("Nenhuma textura compatível de braço/luva foi encontrada nos outros modelos. Nenhum outro modelo foi alterado. Tente selecionar texturas de mãos/luvas e confirme se os modelos possuem slots separados para elas.");
                    return;
                }
                setStatus("Aplicação em lote concluída: " + texturesDone + " textura(s) em " + modelsDone + " modelo(s). Ignorados: " + skipped + "; texturas incompatíveis: " + failures + ". Exporte o ZIP e teste no cliente Android.");
            });
        }, "Fulldesign-arm-glove-batch").start();
    }

    private DecodedBatchTexture decodeBatchTemplate(TextureTemplate template) throws IOException {
        List<GoldSrcMdl.Texture> list = GoldSrcMdl.textures(template.modelBytes);
        GoldSrcMdl.Texture source = null;
        for (GoldSrcMdl.Texture t : list) if (t.index == template.textureIndex) { source = t; break; }
        if (source == null || !source.embedded) throw new IOException("A textura de origem não está embutida: " + template.textureName);
        long pixels = (long) source.width * source.height;
        if (pixels > 4_194_304L) throw new IOException("A textura " + template.textureName + " é grande demais para processar em lote com segurança (limite de 4 MP por textura de origem).");
        int[] argb = GoldSrcMdl.decodePixels(template.modelBytes, source);
        Bitmap bitmap = Bitmap.createBitmap(argb, source.width, source.height, Bitmap.Config.ARGB_8888);
        return new DecodedBatchTexture(source.name, source.width, source.height, bitmap);
    }

    private boolean isArmTextureSlot(String name) {
        String n = normalizeTextureName(name);
        return n.matches(".*(arm|arms|sleeve|forearm|braco|bracos|manga|brazo|brazos|рукав).*");
    }

    private boolean isHandTextureSlot(String name) {
        String n = normalizeTextureName(name);
        return n.matches(".*(hand|hands|finger|fist|wrist|mao|maos|mano|manos|dedo|dedos|vhand|vhands|кист|ладон).*");
    }

    private boolean isGloveTextureSlot(String name) {
        String n = normalizeTextureName(name);
        return n.matches(".*(glove|gloves|luva|luvas|guante|guantes|перчат).*");
    }

    private String normalizeTextureName(String name) {
        if (name == null) return "";
        String normalized = Normalizer.normalize(name.toLowerCase(Locale.ROOT), Normalizer.Form.NFD);
        return normalized.replaceAll("\\p{M}+", "").replaceAll("[^a-z0-9а-яё]", "");
    }

    private Bitmap decodeLocalImage(File file, int targetWidth, int targetHeight) {
        if (file == null || !file.isFile()) return null;
        BitmapFactory.Options bounds = new BitmapFactory.Options(); bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;
        int sample = 1;
        while (bounds.outWidth / (sample * 2) >= targetWidth * 2 && bounds.outHeight / (sample * 2) >= targetHeight * 2) sample *= 2;
        BitmapFactory.Options options = new BitmapFactory.Options(); options.inSampleSize = sample; options.inScaled = false;
        Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), options);
        return bitmap;
    }

    private String baseName(String path) {
        String name = path == null ? "" : path.replace('\\', '/');
        int slash = name.lastIndexOf('/'); if (slash >= 0) name = name.substring(slash + 1);
        int dot = name.lastIndexOf('.'); if (dot > 0) name = name.substring(0, dot);
        return name.trim();
    }

    private void readZip(Uri uri) throws IOException {
        packMode = false;
        viewerRefreshToken++;
        if (modelViewer != null) modelViewer.setModel(null, java.util.Collections.emptyMap());
        activePackModel = null;
        standaloneModelUri = null;
        modelBytes = null;
        selectedTexture = null;
        textures = new ArrayList<>();
        packEntries.clear();
        File base = new File(getCacheDir(), "fulldesign_pack_mixer"); deleteTree(base);
        armTextureTemplate = null;
        gloveTextureTemplate = null;
        if (armTemplateInfo != null) armTemplateInfo.setText(LanguageManager.translate(this, "Textura de braço de origem") + ": " + LanguageManager.translate(this, "Nenhuma textura definida"));
        if (gloveTemplateInfo != null) gloveTemplateInfo.setText(LanguageManager.translate(this, "Textura de luva de origem") + ": " + LanguageManager.translate(this, "Nenhuma textura definida"));
        if (!base.mkdirs() && !base.isDirectory()) throw new IOException("Não foi possível criar a pasta temporária.");
        workRoot = base;
        long total = 0; int count = 0; byte[] buffer = new byte[8192];
        java.util.HashSet<String> seenNames = new java.util.HashSet<>();
        InputStream raw = getContentResolver().openInputStream(uri);
        if (raw == null) throw new IOException("Não foi possível abrir o ZIP.");
        try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(raw))) {
            ZipEntry entry;
            while ((entry = zin.getNextEntry()) != null) {
                if (++count > 3000) throw new IOException("O pack contém mais de 3000 entradas.");
                String name = sanitizeEntry(entry.getName());
                if (name == null || name.isEmpty()) { zin.closeEntry(); continue; }
                if (!seenNames.add(name)) { zin.closeEntry(); continue; }
                File out = safeOutputFile(name);
                if (entry.isDirectory()) {
                    if (!out.exists() && !out.mkdirs()) throw new IOException("Não foi possível criar uma pasta do pack.");
                    packEntries.add(new PackEntry(name, true, out));
                } else {
                    File parent = out.getParentFile(); if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("Não foi possível preparar a pasta do arquivo.");
                    long perEntry = 0;
                    try (OutputStream os = new BufferedOutputStream(new FileOutputStream(out))) {
                        int n; while ((n = zin.read(buffer)) != -1) {
                            perEntry += n; total += n;
                            if (perEntry > MAX_ZIP_ENTRY || total > MAX_ZIP_TOTAL) throw new IOException("Limite do pack excedido: 32 MB por arquivo e 150 MB descompactados.");
                            os.write(buffer, 0, n);
                        }
                    }
                    packEntries.add(new PackEntry(name, false, out));
                }
                zin.closeEntry();
            }
        }
        if (packEntries.isEmpty()) throw new IOException("O ZIP não contém entradas válidas.");
    }

    private void renderPackEntries() {
        packList.removeAllViews();
        packList.addView(text("Entradas: " + packEntries.size() + " · MDL: " + countExt(".mdl") + " · imagens externas: " + countImages(), 12, cyan(), true), margins(-1, -2, 0, 10, 0, 0));
        int shown = 0;
        for (PackEntry item : packEntries) {
            if (item.directory) continue;
            String lower = item.name.toLowerCase(Locale.ROOT);
            if (!lower.endsWith(".mdl") && !isImage(lower)) continue;
            if (shown++ >= 120) { packList.addView(text("A lista está limitada a 120 arquivos visíveis. O ZIP de saída preservará todas as entradas.", 11, muted(), false)); break; }
            LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            String type = lower.endsWith(".mdl") ? "MDL" : "IMG";
            row.addView(text(type, 10, cyan(), true), margins(dp(36), dp(32), 0, 0, 8, 0));
            TextView name = text(item.name, 11, Color.WHITE, false); name.setMaxLines(2); row.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
            if (lower.endsWith(".mdl")) {
                Button open = action("ABRIR", () -> { try { activePackModel = item; packMode = true; standaloneModelUri = null; loadedModelName = item.name; modelBytes = readFile(item.exportFile(), (int) MAX_ZIP_ENTRY); loadModelBytes(); } catch (Exception e) { setStatus("Falha ao abrir " + item.name + ": " + safeMessage(e)); } });
                row.addView(open, margins(dp(76), dp(36), 4, 0, 0, 0));
            }
            packList.addView(row, margins(-1, -2, 0, 3, 0, 3));
        }
        if (packEntries.isEmpty()) packList.addView(text("Nenhum arquivo encontrado no pack.", 12, muted(), false));
    }

    private void saveModelDialog() {
        if (modelBytes == null) { toast("Carregue um modelo .mdl primeiro."); return; }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/octet-stream");
        String base = loadedModelName.toLowerCase(Locale.ROOT).endsWith(".mdl") ? loadedModelName.substring(0, loadedModelName.length() - 4) : loadedModelName;
        i.putExtra(Intent.EXTRA_TITLE, base + "_fulldesign.mdl"); startActivityForResult(i, REQ_SAVE_MODEL);
    }

    private void savePack() {
        if (!packMode || packEntries.isEmpty()) { toast("Importe um pack ZIP primeiro."); return; }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/zip");
        i.putExtra(Intent.EXTRA_TITLE, "fulldesign_pack_modificado.zip"); startActivityForResult(i, REQ_SAVE_PACK);
    }

    private void writePack(Uri uri) throws IOException {
        OutputStream raw = getContentResolver().openOutputStream(uri);
        if (raw == null) throw new IOException("Não foi possível criar o ZIP de saída.");
        try (ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(raw))) {
            byte[] buffer = new byte[8192];
            for (PackEntry entry : packEntries) {
                if (!entry.directory && "fulldesign_project_settings.txt".equals(entry.name)) continue;
                ZipEntry z = new ZipEntry(entry.name); out.putNextEntry(z);
                if (!entry.directory) {
                    try (InputStream in = new BufferedInputStream(new FileInputStream(entry.exportFile()))) {
                        int n; while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                    }
                }
                out.closeEntry();
            }
            ZipEntry config = new ZipEntry("fulldesign_project_settings.txt"); out.putNextEntry(config);
            out.write(settingsText().getBytes(StandardCharsets.UTF_8)); out.closeEntry();
        }
    }

    private void exportOriginQc() {
        if (loadedModelName == null || loadedModelName.trim().isEmpty()) { toast("Importe um modelo para nomear a diretiva QC."); return; }
        String qc = "// Fulldesign Skin Studio - diretiva de origem\n// Esta diretiva precisa ser usada no QC original e o modelo precisa ser recompilado.\n$origin "
                + number(xValue) + " " + number(yValue) + " " + number(zValue) + "\n";
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("text/plain");
        String n = loadedModelName.toLowerCase(Locale.ROOT).endsWith(".mdl") ? loadedModelName.substring(0, loadedModelName.length() - 4) : loadedModelName;
        i.putExtra(Intent.EXTRA_TITLE, n + "_origin_qc.txt");
        try { pendingQc = qc; startActivityForResult(i, REQ_SAVE_QC); }
        catch (Exception e) { setStatus("Não foi possível abrir o seletor de saída: " + safeMessage(e)); }
    }
    private String pendingQc;

    private void exportSettings() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TITLE, "fulldesign_project_settings.txt"); startActivityForResult(i, REQ_SAVE_SETTINGS);
    }

    private String settingsText() {
        return "Fulldesign Skin Studio project settings\n" + "fov_metadata=" + fov + "\n" + "origin_x=" + number(xValue) + "\n"
                + "origin_y=" + number(yValue) + "\n" + "origin_z=" + number(zValue) + "\n"
                + "note=FOV and model origin are project metadata; the mobile client may not apply these values automatically.\n";
    }

    @Override protected void onPause() { if (modelViewer != null) modelViewer.onPause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); if (modelViewer != null) modelViewer.onResume(); }
    @Override public void onBackPressed() { super.onBackPressed(); }

    private void addAxis(LinearLayout parent, String axis, EditText value, int axisIndex) {
        LinearLayout line = new LinearLayout(this); line.setGravity(Gravity.CENTER_VERTICAL);
        line.addView(text(axis, 14, Color.WHITE, true), margins(dp(24), -2, 0, 0, 8, 0));
        line.addView(action("−" + axis, () -> adjustAxis(value, -1)), new LinearLayout.LayoutParams(0, dp(38), 1f));
        LinearLayout.LayoutParams plus = new LinearLayout.LayoutParams(0, dp(38), 1f); plus.leftMargin = dp(5);
        line.addView(action("+" + axis, () -> adjustAxis(value, 1)), plus);
        parent.addView(line, margins(-1, dp(42), 0, 4, 0, 0));
        parent.addView(value, margins(-1, dp(42), 0, 2, 0, 7));
    }

    private void adjustAxis(EditText field, int sign) {
        float value = parseFloat(field.getText().toString(), 0f);
        float step = parseFloat(stepValue.getText().toString(), 1f);
        if (step < 0) step = -step;
        if (step == 0) step = 1f;
        field.setText(String.format(Locale.US, "%.3f", value + sign * step));
    }

    private EditText numberInput(String hint, String initial) {
        EditText input = new EditText(this); input.setSingleLine(true); input.setText(initial); input.setHint(hint);
        input.setTextColor(Color.WHITE); input.setHintTextColor(muted()); input.setTextSize(14); input.setSelectAllOnFocus(true);
        input.setPadding(dp(12), 0, dp(12), 0); input.setBackground(bg(Color.rgb(17, 20, 31), 8, border(), 1)); return input;
    }

    private String number(EditText field) { return String.format(Locale.US, "%.3f", parseFloat(field == null ? "0" : field.getText().toString(), 0f)); }
    private float parseFloat(String s, float fallback) { try { return Float.parseFloat(s.trim().replace(',', '.')); } catch (Exception ignored) { return fallback; } }

    private File safeOutputFile(String relativeName) throws IOException {
        if (workRoot == null) throw new IOException("A área de trabalho não foi inicializada.");
        File output = new File(workRoot, relativeName).getCanonicalFile();
        String base = workRoot.getCanonicalPath() + File.separator;
        if (!output.getCanonicalPath().startsWith(base)) throw new IOException("Caminho de saída inválido.");
        return output;
    }

    private String sanitizeEntry(String name) {
        if (name == null) return null;
        String n = name.replace('\\', '/');
        if (n.startsWith("/") || n.matches("^[A-Za-z]:.*")) return null;
        String[] parts = n.split("/");
        for (String p : parts) if (p.equals("..")) return null;
        n = n.replaceAll("/+", "/");
        return n.trim().isEmpty() ? null : n;
    }

    private int countExt(String ext) { int n = 0; for (PackEntry e : packEntries) if (!e.directory && e.name.toLowerCase(Locale.ROOT).endsWith(ext)) n++; return n; }
    private int countImages() { int n = 0; for (PackEntry e : packEntries) if (!e.directory && isImage(e.name.toLowerCase(Locale.ROOT))) n++; return n; }
    private boolean isImage(String name) { return name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".jpeg") || name.endsWith(".bmp"); }

    private String displayName(Uri uri, String fallback) {
        try (android.database.Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) { int i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME); if (i >= 0) return c.getString(i); }
        } catch (Exception ignored) { }
        return fallback;
    }

    private byte[] readUri(Uri uri, int max) throws IOException {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IOException("Não foi possível abrir o arquivo.");
            return readStream(in, max);
        }
    }
    private byte[] readFile(File file, int max) throws IOException { try (InputStream in = new FileInputStream(file)) { return readStream(in, max); } }
    private byte[] readStream(InputStream in, int max) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buffer = new byte[8192]; int n; long total = 0;
        while ((n = in.read(buffer)) != -1) { total += n; if (total > max) throw new IOException("Arquivo maior que o limite permitido."); out.write(buffer, 0, n); }
        return out.toByteArray();
    }
    private void writeUri(Uri uri, byte[] bytes) throws IOException {
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new IOException("Não foi possível gravar no destino escolhido."); out.write(bytes); out.flush();
        }
    }
    private void deleteTree(File file) { if (file == null || !file.exists()) return; if (file.isDirectory()) { File[] children = file.listFiles(); if (children != null) for (File child : children) deleteTree(child); } file.delete(); }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private int cyan() { return Color.rgb(78, 192, 255); }
    private int purple() { return Color.rgb(123, 92, 255); }
    private int muted() { return Color.rgb(158, 166, 188); }
    private int border() { return Color.rgb(47, 53, 75); }
    private TextView text(String value, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(LanguageManager.translate(this, value)); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD); return t; }
    private TextView section(String value) { TextView t = text(LanguageManager.translate(this, value).toUpperCase(Locale.ROOT), 11, cyan(), true); t.setLetterSpacing(.06f); t.setPadding(0, 0, 0, dp(9)); return t; }
    private LinearLayout card() { LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(14), dp(14), dp(14), dp(14)); c.setBackground(bg(Color.rgb(17, 19, 30), 16, border(), 1)); return c; }
    private Button action(String title, Runnable action) { Button b = new Button(this); b.setText(LanguageManager.translate(this, title)); b.setAllCaps(false); b.setTextSize(12); b.setTextColor(Color.WHITE); b.setBackground(bg(Color.rgb(75, 61, 163), 9, Color.rgb(114, 102, 221), 1)); b.setOnClickListener(v -> { if (!busy) action.run(); }); return b; }
    private GradientDrawable bg(int color, int radius, int strokeColor, int strokeWidth) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); if (strokeWidth > 0) d.setStroke(dp(strokeWidth), strokeColor); return d; }
    private LinearLayout.LayoutParams margins(int width, int height, int left, int top, int right, int bottom) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(width, height); p.setMargins(dp(left), dp(top), dp(right), dp(bottom)); return p; }
    private void setStatus(String s) { if (status != null) status.setText(LanguageManager.translate(this, s)); }
    private void toast(String s) { Toast.makeText(this, LanguageManager.translate(this, s), Toast.LENGTH_LONG).show(); }
    private String safeMessage(Throwable e) { return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage(); }
}
