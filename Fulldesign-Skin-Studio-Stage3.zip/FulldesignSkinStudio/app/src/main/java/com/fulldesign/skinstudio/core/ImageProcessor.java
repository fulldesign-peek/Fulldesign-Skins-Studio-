package com.fulldesign.skinstudio.core;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/** Real image decoding, editing, resizing and palette quantization for the first Skin Studio release. */
public final class ImageProcessor {
    public static final int MAX_WORKING_DIMENSION = 4096;
    public static final long MAX_WORKING_PIXELS = 4_000_000L;
    private static final int MAX_INPUT_BYTES = 64 * 1024 * 1024;
    private static final int HISTOGRAM_LEVELS = 32;
    private static final int HISTOGRAM_SIZE = HISTOGRAM_LEVELS * HISTOGRAM_LEVELS * HISTOGRAM_LEVELS;

    private ImageProcessor() {}

    public static final class QuantizedImage {
        public final int width;
        public final int height;
        public final byte[] indices;
        public final int[] paletteArgb;
        public final boolean hasReservedMask;

        public QuantizedImage(int width, int height, byte[] indices, int[] paletteArgb, boolean hasReservedMask) {
            this.width = width;
            this.height = height;
            this.indices = indices;
            this.paletteArgb = paletteArgb;
            this.hasReservedMask = hasReservedMask;
        }
    }

    public static Bitmap decode(Context context, Uri uri) throws IOException {
        ContentResolver resolver = context.getContentResolver();
        byte[] data;
        try (InputStream input = resolver.openInputStream(uri)) {
            if (input == null) throw new IOException("Não foi possível abrir o arquivo selecionado.");
            data = readLimited(input, MAX_INPUT_BYTES);
        }
        if (data.length < 2) throw new IOException("Arquivo vazio ou incompleto.");
        if (data[0] == 'B' && data[1] == 'M') return decodeBmp(data);

        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw new IOException("Formato de imagem não suportado. Use PNG, JPG, JPEG ou BMP válido.");
        }
        int sample = sampleSizeFor(bounds.outWidth, bounds.outHeight);
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = sample;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        options.inScaled = false;
        Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length, options);
        if (bitmap == null) throw new IOException("Não foi possível decodificar esta imagem.");
        return bitmap.copy(Bitmap.Config.ARGB_8888, false);
    }

    private static byte[] readLimited(InputStream input, int maxBytes) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[32 * 1024];
        int total = 0;
        int read;
        while ((read = input.read(buffer)) != -1) {
            total += read;
            if (total > maxBytes) throw new IOException("Arquivo maior que 64 MB. Reduza o tamanho antes de importar.");
            out.write(buffer, 0, read);
        }
        return out.toByteArray();
    }

    private static int sampleSizeFor(int width, int height) {
        int sample = 1;
        while ((width / sample > MAX_WORKING_DIMENSION || height / sample > MAX_WORKING_DIMENSION
                || ((long) width / sample) * ((long) height / sample) > MAX_WORKING_PIXELS) && sample < 128) {
            sample *= 2;
        }
        return sample;
    }

    /** Reads uncompressed Windows BMP with 8-bit indexed, 24-bit RGB or 32-bit BGRA pixels. */
    private static Bitmap decodeBmp(byte[] data) throws IOException {
        if (data.length < 54) throw new IOException("Cabeçalho BMP incompleto.");
        ByteBuffer b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        if (b.get(0) != 'B' || b.get(1) != 'M') throw new IOException("Assinatura BMP inválida.");
        long pixelOffsetLong = Integer.toUnsignedLong(b.getInt(10));
        long dibSizeLong = Integer.toUnsignedLong(b.getInt(14));
        if (dibSizeLong < 40 || 14L + dibSizeLong > data.length) throw new IOException("Cabeçalho BMP não suportado.");
        int width = b.getInt(18);
        int signedHeight = b.getInt(22);
        int planes = Short.toUnsignedInt(b.getShort(26));
        int bits = Short.toUnsignedInt(b.getShort(28));
        long compression = Integer.toUnsignedLong(b.getInt(30));
        if (width <= 0 || signedHeight == 0 || signedHeight == Integer.MIN_VALUE || Math.abs((long) signedHeight) > 100000
                || width > 100000 || planes != 1 || compression != 0 || !(bits == 8 || bits == 24 || bits == 32)) {
            throw new IOException("BMP incompatível. São aceitos BMP sem compressão de 8, 24 ou 32 bits.");
        }
        int height = Math.abs(signedHeight);
        int sample = sampleSizeFor(width, height);
        int outW = Math.max(1, (width + sample - 1) / sample);
        int outH = Math.max(1, (height + sample - 1) / sample);
        int[] pixels = new int[outW * outH];
        int colorsUsed = b.getInt(46);
        int paletteCount = bits == 8 ? (colorsUsed > 0 ? Math.min(colorsUsed, 256) : 256) : 0;
        int paletteOffset = (int) (14L + dibSizeLong);
        int[] palette = new int[Math.max(1, paletteCount)];
        if (bits == 8) {
            if (paletteOffset + paletteCount * 4L > data.length || pixelOffsetLong < paletteOffset + paletteCount * 4L) {
                throw new IOException("Paleta BMP incompleta.");
            }
            for (int i = 0; i < paletteCount; i++) {
                int off = paletteOffset + i * 4;
                int blue = data[off] & 255, green = data[off + 1] & 255, red = data[off + 2] & 255;
                palette[i] = Color.rgb(red, green, blue);
            }
        }
        if (pixelOffsetLong > data.length) throw new IOException("Offset de pixels fora do arquivo BMP.");
        int pixelOffset = (int) pixelOffsetLong;
        long strideLong = (((long) width * bits + 31L) / 32L) * 4L;
        if (strideLong * height > data.length - (long) pixelOffset) throw new IOException("Dados de pixels incompletos.");
        int stride = (int) strideLong;
        boolean topDown = signedHeight < 0;
        boolean foundNonZeroAlpha = false;
        if (bits == 32) {
            for (int y = 0; y < height && !foundNonZeroAlpha; y++) {
                int row = pixelOffset + y * stride;
                for (int x = 0; x < width; x++) {
                    if ((data[row + x * 4 + 3] & 255) != 0) { foundNonZeroAlpha = true; break; }
                }
            }
        }
        for (int oy = 0; oy < outH; oy++) {
            int sy = Math.min(height - 1, oy * sample);
            int sourceY = topDown ? sy : height - 1 - sy;
            int row = pixelOffset + sourceY * stride;
            for (int ox = 0; ox < outW; ox++) {
                int sx = Math.min(width - 1, ox * sample);
                int color;
                if (bits == 8) {
                    int index = data[row + sx] & 255;
                    if (index >= paletteCount) throw new IOException("Índice de paleta BMP fora do limite.");
                    color = palette[index];
                } else if (bits == 24) {
                    int off = row + sx * 3;
                    color = Color.rgb(data[off + 2] & 255, data[off + 1] & 255, data[off] & 255);
                } else {
                    int off = row + sx * 4;
                    int alpha = foundNonZeroAlpha ? (data[off + 3] & 255) : 255;
                    color = Color.argb(alpha, data[off + 2] & 255, data[off + 1] & 255, data[off] & 255);
                }
                pixels[oy * outW + ox] = color;
            }
        }
        return Bitmap.createBitmap(pixels, outW, outH, Bitmap.Config.ARGB_8888);
    }

    public static Bitmap resize(Bitmap source, int width, int height) {
        if (source.getWidth() == width && source.getHeight() == height) return source.copy(Bitmap.Config.ARGB_8888, false);
        return Bitmap.createScaledBitmap(source, width, height, true).copy(Bitmap.Config.ARGB_8888, false);
    }

    public static Bitmap reconstruct(QuantizedImage image) {
        int[] pixels = new int[image.indices.length];
        for (int i = 0; i < pixels.length; i++) pixels[i] = image.paletteArgb[image.indices[i] & 255];
        return Bitmap.createBitmap(pixels, image.width, image.height, Bitmap.Config.ARGB_8888);
    }

    public static Bitmap rgb24Preview(Bitmap source) {
        int width = source.getWidth(), height = source.getHeight();
        int[] pixels = new int[width * height];
        source.getPixels(pixels, 0, width, 0, 0, width, height);
        for (int i = 0; i < pixels.length; i++) {
            int c = pixels[i];
            pixels[i] = Color.rgb(Color.red(c), Color.green(c), Color.blue(c));
        }
        return Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888);
    }

    /** Applies the user's basic color adjustments to a new bitmap, preserving the original. */
    public static Bitmap adjust(Bitmap source, int brightness, int contrast, int saturation, int hue, int sharpness) {
        int width = source.getWidth(), height = source.getHeight();
        int count = width * height;
        int[] src = new int[count];
        int[] dst = new int[count];
        source.getPixels(src, 0, width, 0, 0, width, height);
        double contrastFactor = (259.0 * (contrast + 255.0)) / (255.0 * (259.0 - contrast));
        float saturationFactor = Math.max(0f, (100f + saturation) / 100f);
        float hueOffset = hue / 360f;
        float[] hsv = new float[3];
        int brightnessOffset = Math.round(brightness * 2.55f);
        for (int i = 0; i < count; i++) {
            int pixel = src[i];
            int alpha = Color.alpha(pixel);
            int r = clamp((int) Math.round(contrastFactor * (Color.red(pixel) - 128) + 128) + brightnessOffset);
            int g = clamp((int) Math.round(contrastFactor * (Color.green(pixel) - 128) + 128) + brightnessOffset);
            int b = clamp((int) Math.round(contrastFactor * (Color.blue(pixel) - 128) + 128) + brightnessOffset);
            Color.colorToHSV(Color.rgb(r, g, b), hsv);
            hsv[0] = (hsv[0] + hueOffset * 360f + 360f) % 360f;
            hsv[1] = Math.min(1f, hsv[1] * saturationFactor);
            dst[i] = Color.HSVToColor(alpha, hsv);
        }
        Bitmap adjusted = Bitmap.createBitmap(dst, width, height, Bitmap.Config.ARGB_8888);
        if (sharpness <= 0 || width < 3 || height < 3) return adjusted;
        return sharpen(adjusted, sharpness / 100f * 0.7f);
    }

    private static Bitmap sharpen(Bitmap source, float amount) {
        int width = source.getWidth(), height = source.getHeight();
        int[] src = new int[width * height];
        int[] out = new int[src.length];
        source.getPixels(src, 0, width, 0, 0, width, height);
        System.arraycopy(src, 0, out, 0, src.length);
        for (int y = 1; y < height - 1; y++) {
            for (int x = 1; x < width - 1; x++) {
                int i = y * width + x;
                int c = src[i], up = src[i - width], down = src[i + width], left = src[i - 1], right = src[i + 1];
                int r = channel(Color.red(c), Color.red(up), Color.red(down), Color.red(left), Color.red(right), amount);
                int g = channel(Color.green(c), Color.green(up), Color.green(down), Color.green(left), Color.green(right), amount);
                int b = channel(Color.blue(c), Color.blue(up), Color.blue(down), Color.blue(left), Color.blue(right), amount);
                out[i] = Color.argb(Color.alpha(c), r, g, b);
            }
        }
        return Bitmap.createBitmap(out, width, height, Bitmap.Config.ARGB_8888);
    }

    private static int channel(int center, int up, int down, int left, int right, float amount) {
        return clamp(Math.round(center * (1f + 4f * amount) - amount * (up + down + left + right)));
    }

    private static int clamp(int value) { return Math.max(0, Math.min(255, value)); }

    /** Median-cut palette generation + optional Floyd–Steinberg dithering. */
    public static QuantizedImage quantize(Bitmap bitmap, boolean dithering,
                                          boolean alphaToMask, boolean pureBlueToMask) {
        int width = bitmap.getWidth(), height = bitmap.getHeight();
        int count = width * height;
        int[] pixels = new int[count];
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height);
        boolean reserveMask = alphaToMask || pureBlueToMask;
        int colorLimit = reserveMask ? 255 : 256;

        int[] histCount = new int[HISTOGRAM_SIZE];
        long[] sumR = new long[HISTOGRAM_SIZE];
        long[] sumG = new long[HISTOGRAM_SIZE];
        long[] sumB = new long[HISTOGRAM_SIZE];
        int sampleStep = Math.max(1, (int) Math.ceil(count / 200000.0));
        for (int i = 0; i < count; i += sampleStep) {
            int pixel = pixels[i];
            if ((alphaToMask && Color.alpha(pixel) < 128) || (pureBlueToMask && isPureBlue(pixel))) continue;
            int r = Color.red(pixel), g = Color.green(pixel), b = Color.blue(pixel);
            int key = histKey(r, g, b);
            histCount[key]++;
            sumR[key] += r; sumG[key] += g; sumB[key] += b;
        }
        List<ColorPoint> points = new ArrayList<>();
        for (int key = 0; key < HISTOGRAM_SIZE; key++) {
            if (histCount[key] == 0) continue;
            int r = (int) (sumR[key] / histCount[key]);
            int g = (int) (sumG[key] / histCount[key]);
            int b = (int) (sumB[key] / histCount[key]);
            points.add(new ColorPoint(r, g, b, histCount[key]));
        }
        List<List<ColorPoint>> boxes = new ArrayList<>();
        if (!points.isEmpty()) boxes.add(points);
        while (boxes.size() < colorLimit) {
            int chosen = -1;
            double bestScore = -1;
            int chosenChannel = 0;
            for (int i = 0; i < boxes.size(); i++) {
                List<ColorPoint> box = boxes.get(i);
                if (box.size() < 2) continue;
                int[] range = ranges(box);
                int channel = range[1] > range[0] ? 1 : 0;
                if (range[2] > range[channel]) channel = 2;
                int maxRange = range[channel];
                long totalWeight = 0;
                for (ColorPoint point : box) totalWeight += point.weight;
                double score = maxRange * Math.sqrt((double) totalWeight);
                if (score > bestScore) { bestScore = score; chosen = i; chosenChannel = channel; }
            }
            if (chosen < 0) break;
            List<ColorPoint> box = boxes.remove(chosen);
            final int channel = chosenChannel;
            box.sort(Comparator.comparingInt(p -> channel == 0 ? p.r : channel == 1 ? p.g : p.b));
            long half = 0;
            for (ColorPoint point : box) half += point.weight;
            half = Math.max(1, (half + 1) / 2);
            long running = 0;
            int split = 1;
            for (int i = 0; i < box.size() - 1; i++) {
                running += box.get(i).weight;
                split = i + 1;
                if (running >= half) break;
            }
            split = Math.max(1, Math.min(box.size() - 1, split));
            boxes.add(new ArrayList<>(box.subList(0, split)));
            boxes.add(new ArrayList<>(box.subList(split, box.size())));
        }

        int[] palette = new int[256];
        int paletteCount = 0;
        for (List<ColorPoint> box : boxes) {
            long total = 0, r = 0, g = 0, b = 0;
            for (ColorPoint point : box) {
                total += point.weight;
                r += (long) point.r * point.weight;
                g += (long) point.g * point.weight;
                b += (long) point.b * point.weight;
            }
            if (total > 0 && paletteCount < colorLimit) {
                palette[paletteCount++] = Color.rgb((int) (r / total), (int) (g / total), (int) (b / total));
            }
        }
        if (paletteCount == 0) { palette[0] = Color.BLACK; paletteCount = 1; }
        int maskIndex = 255;
        if (reserveMask) palette[maskIndex] = Color.rgb(0, 0, 255);
        int fillColor = palette[paletteCount - 1];
        for (int i = paletteCount; i < colorLimit; i++) palette[i] = fillColor;
        if (!reserveMask && paletteCount < 256) {
            for (int i = paletteCount; i < 256; i++) palette[i] = fillColor;
        }

        int[] lookup = new int[HISTOGRAM_SIZE];
        Arrays.fill(lookup, -1);
        for (int key = 0; key < HISTOGRAM_SIZE; key++) {
            int r = ((key >>> 10) & 31) * 8 + 4;
            int g = ((key >>> 5) & 31) * 8 + 4;
            int b = (key & 31) * 8 + 4;
            lookup[key] = nearestPalette(r, g, b, palette, colorLimit);
        }
        byte[] indices = new byte[count];
        if (dithering) {
            mapWithDithering(pixels, width, height, indices, palette, lookup, alphaToMask, pureBlueToMask);
        } else {
            for (int i = 0; i < count; i++) {
                int pixel = pixels[i];
                if (reserveMask && ((alphaToMask && Color.alpha(pixel) < 128) || (pureBlueToMask && isPureBlue(pixel)))) {
                    indices[i] = (byte) 255;
                } else {
                    indices[i] = (byte) lookup[histKey(Color.red(pixel), Color.green(pixel), Color.blue(pixel))];
                }
            }
        }
        return new QuantizedImage(width, height, indices, palette, reserveMask);
    }

    private static void mapWithDithering(int[] pixels, int width, int height, byte[] indices,
                                         int[] palette, int[] lookup, boolean alphaToMask, boolean pureBlueToMask) {
        float[] curR = new float[width + 2], curG = new float[width + 2], curB = new float[width + 2];
        float[] nextR = new float[width + 2], nextG = new float[width + 2], nextB = new float[width + 2];
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int i = y * width + x;
                int pixel = pixels[i];
                if ((alphaToMask && Color.alpha(pixel) < 128) || (pureBlueToMask && isPureBlue(pixel))) {
                    indices[i] = (byte) 255;
                    continue;
                }
                int pos = x + 1;
                int r = clamp(Math.round(Color.red(pixel) + curR[pos]));
                int g = clamp(Math.round(Color.green(pixel) + curG[pos]));
                int b = clamp(Math.round(Color.blue(pixel) + curB[pos]));
                int index = lookup[histKey(r, g, b)];
                indices[i] = (byte) index;
                int color = palette[index];
                float er = r - Color.red(color), eg = g - Color.green(color), eb = b - Color.blue(color);
                curR[pos + 1] += er * 7f / 16f; curG[pos + 1] += eg * 7f / 16f; curB[pos + 1] += eb * 7f / 16f;
                nextR[pos - 1] += er * 3f / 16f; nextG[pos - 1] += eg * 3f / 16f; nextB[pos - 1] += eb * 3f / 16f;
                nextR[pos] += er * 5f / 16f; nextG[pos] += eg * 5f / 16f; nextB[pos] += eb * 5f / 16f;
                nextR[pos + 1] += er / 16f; nextG[pos + 1] += eg / 16f; nextB[pos + 1] += eb / 16f;
            }
            float[] tmp = curR; curR = nextR; nextR = tmp; Arrays.fill(nextR, 0f);
            tmp = curG; curG = nextG; nextG = tmp; Arrays.fill(nextG, 0f);
            tmp = curB; curB = nextB; nextB = tmp; Arrays.fill(nextB, 0f);
        }
    }

    private static int nearestPalette(int r, int g, int b, int[] palette, int count) {
        int best = 0;
        long bestDistance = Long.MAX_VALUE;
        for (int i = 0; i < count; i++) {
            int color = palette[i];
            int dr = r - Color.red(color), dg = g - Color.green(color), db = b - Color.blue(color);
            long distance = (long) dr * dr * 3L + (long) dg * dg * 4L + (long) db * db * 2L;
            if (distance < bestDistance) { bestDistance = distance; best = i; }
        }
        return best;
    }

    private static int[] ranges(List<ColorPoint> box) {
        int minR = 255, minG = 255, minB = 255, maxR = 0, maxG = 0, maxB = 0;
        for (ColorPoint p : box) {
            minR = Math.min(minR, p.r); maxR = Math.max(maxR, p.r);
            minG = Math.min(minG, p.g); maxG = Math.max(maxG, p.g);
            minB = Math.min(minB, p.b); maxB = Math.max(maxB, p.b);
        }
        return new int[]{maxR - minR, maxG - minG, maxB - minB};
    }

    private static int histKey(int r, int g, int b) { return ((r >>> 3) << 10) | ((g >>> 3) << 5) | (b >>> 3); }
    private static boolean isPureBlue(int pixel) { return Color.red(pixel) == 0 && Color.green(pixel) == 0 && Color.blue(pixel) == 255; }

    private static final class ColorPoint {
        final int r, g, b;
        final int weight;
        ColorPoint(int r, int g, int b, int weight) { this.r = r; this.g = g; this.b = b; this.weight = weight; }
    }
}
