package com.fulldesign.skinstudio.core;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Safe reader/editor for embedded indexed textures in GoldSrc Studio MDL v10 files. */
public final class GoldSrcMdl {
    public static final int HEADER_SIZE = 244;
    public static final int TEXTURE_RECORD_SIZE = 80;
    public static final int TEXTURE_FLAG_MASKED = 0x40;
    private static final int MAX_MODEL_BYTES = 32 * 1024 * 1024;
    private static final int MAX_TEXTURES = 256;
    private static final int MAX_TEXTURE_DIMENSION = 1024;

    private GoldSrcMdl() {}

    public static final class Info {
        public final String name;
        public final int version;
        public final int declaredLength;
        public final int textureCount;
        public final int textureTableOffset;
        public final int textureDataOffset;
        public final int skinReferenceCount;
        public final int skinFamilyCount;

        private Info(String name, int version, int declaredLength, int textureCount,
                     int textureTableOffset, int textureDataOffset, int skinReferenceCount,
                     int skinFamilyCount) {
            this.name = name;
            this.version = version;
            this.declaredLength = declaredLength;
            this.textureCount = textureCount;
            this.textureTableOffset = textureTableOffset;
            this.textureDataOffset = textureDataOffset;
            this.skinReferenceCount = skinReferenceCount;
            this.skinFamilyCount = skinFamilyCount;
        }
    }

    public static final class Texture {
        public final int index;
        public final String name;
        public final int flags;
        public final int width;
        public final int height;
        public final int recordOffset;
        public final int pixelOffset;
        public final int paletteOffset;
        public final int paletteCount;
        public final boolean embedded;

        private Texture(int index, String name, int flags, int width, int height, int recordOffset,
                        int pixelOffset, int paletteOffset, int paletteCount, boolean embedded) {
            this.index = index;
            this.name = name;
            this.flags = flags;
            this.width = width;
            this.height = height;
            this.recordOffset = recordOffset;
            this.pixelOffset = pixelOffset;
            this.paletteOffset = paletteOffset;
            this.paletteCount = paletteCount;
            this.embedded = embedded;
        }

        public boolean isMasked() { return (flags & TEXTURE_FLAG_MASKED) != 0; }
    }

    public static Info inspect(byte[] data) throws IOException {
        checkModel(data);
        String name = cString(data, 8, 64);
        int length = readInt(data, 72);
        if (length < HEADER_SIZE || length > data.length) {
            // A few exporters leave the length stale; use the real file boundary only if
            // the header's data tables still fit. The metadata remains explicitly reported.
            length = data.length;
        }
        int count = readInt(data, 180);        // studiohdr_t::numtextures
        int table = readInt(data, 184);        // studiohdr_t::textureindex
        int dataOffset = readInt(data, 188);   // studiohdr_t::texturedataindex
        int skinRefs = readInt(data, 192);
        int skinFamilies = readInt(data, 196);
        if (count < 0 || count > MAX_TEXTURES) throw new IOException("Quantidade de texturas fora do limite do formato.");
        if (count > 0 && !rangeFits(table, (long) count * TEXTURE_RECORD_SIZE, Math.min(length, data.length))) {
            throw new IOException("A tabela de texturas aponta para fora do arquivo. Verifique se o .mdl é GoldSrc v10 e está completo.");
        }
        if (skinRefs < 0 || skinRefs > 4096 || skinFamilies < 0 || skinFamilies > 256) {
            throw new IOException("Tabela de skins inválida no cabeçalho.");
        }
        return new Info(name.isEmpty() ? "modelo sem nome" : name, readInt(data, 4), length,
                count, table, dataOffset, skinRefs, skinFamilies);
    }

    public static List<Texture> textures(byte[] data) throws IOException {
        Info info = inspect(data);
        if (info.textureCount == 0) return Collections.emptyList();
        List<Texture> textures = new ArrayList<>(info.textureCount);
        for (int i = 0; i < info.textureCount; i++) {
            int record = info.textureTableOffset + i * TEXTURE_RECORD_SIZE;
            String name = cString(data, record, 64);
            int flags = readInt(data, record + 64);
            int width = readInt(data, record + 68);
            int height = readInt(data, record + 72);
            int pixels = readInt(data, record + 76);
            if (name.isEmpty()) name = "texture_" + (i + 1);
            if (width <= 0 || height <= 0 || width > MAX_TEXTURE_DIMENSION || height > MAX_TEXTURE_DIMENSION) {
                throw new IOException("Dimensões inválidas na textura '" + name + "'.");
            }
            long pixelBytes = (long) width * height;
            if (pixels < HEADER_SIZE || !rangeFits(pixels, pixelBytes + 2, Math.min(info.declaredLength, data.length))) {
                // Keep the record visible for diagnosis (some models refer to external textures),
                // but do not offer pixel editing for it.
                textures.add(new Texture(i, name, flags, width, height, record, pixels, -1, 0, false));
                continue;
            }
            int paletteAt = pixels + (int) pixelBytes;
            int paletteCount = readU16(data, paletteAt);
            if (paletteCount < 1 || paletteCount > 256
                    || !rangeFits(paletteAt + 2, (long) paletteCount * 3, Math.min(info.declaredLength, data.length))) {
                textures.add(new Texture(i, name, flags, width, height, record, pixels, -1, 0, false));
                continue;
            }
            textures.add(new Texture(i, name, flags, width, height, record, pixels,
                    paletteAt + 2, paletteCount, true));
        }
        return Collections.unmodifiableList(textures);
    }

    /** Returns ARGB pixels from the selected embedded texture, honouring GoldSrc masked index 255. */
    public static int[] decodePixels(byte[] data, Texture texture) throws IOException {
        requireTexture(data, texture);
        int[] palette = readPalette(data, texture);
        int count = texture.width * texture.height;
        int[] pixels = new int[count];
        for (int i = 0; i < count; i++) {
            int idx = data[texture.pixelOffset + i] & 255;
            if (texture.isMasked() && idx == 255) {
                pixels[i] = 0x00000000;
            } else {
                if (idx >= palette.length) throw new IOException("A textura usa um índice que não existe na paleta.");
                pixels[i] = palette[idx] | 0xFF000000;
            }
        }
        return pixels;
    }

    /**
     * Replaces only the selected embedded texture's indexed pixel plane. Header, geometry, UVs,
     * animation, skin tables and the original palette are retained byte-for-byte.
     * Input pixels must already be resized to the MDL texture dimensions.
     */
    public static byte[] replaceTexture(byte[] source, int textureIndex, int[] argb,
                                        int width, int height, boolean dither) throws IOException {
        if (argb == null || width <= 0 || height <= 0 || (long) width * height != argb.length) {
            throw new IOException("Pixels da imagem de substituição inválidos.");
        }
        List<Texture> textures = textures(source);
        Texture target = null;
        for (Texture candidate : textures) if (candidate.index == textureIndex) { target = candidate; break; }
        if (target == null) throw new IOException("Índice de textura não encontrado no modelo.");
        requireTexture(source, target);
        if (target.width != width || target.height != height) {
            throw new IOException("A imagem deve ser redimensionada para " + target.width + "×" + target.height + " antes da substituição.");
        }
        if (target.isMasked() && target.paletteCount < 256) {
            throw new IOException("Esta textura está marcada como mascarada, mas não possui 256 entradas de paleta. A edição foi cancelada para preservar a transparência.");
        }
        int[] palette = readPalette(source, target);
        int usableColors = target.isMasked() ? Math.min(255, palette.length) : palette.length;
        if (usableColors < 1) throw new IOException("A paleta da textura está vazia.");
        byte[] edited = source.clone();
        byte[] lookup = buildLookup(palette, usableColors);
        byte[] indices = dither
                ? quantizeDither(argb, width, height, palette, lookup, usableColors, target.isMasked())
                : quantizeNearest(argb, lookup, target.isMasked());
        System.arraycopy(indices, 0, edited, target.pixelOffset, indices.length);
        // Revalidate the complete output before it is returned for saving.
        textures(edited);
        return edited;
    }

    private static byte[] quantizeNearest(int[] pixels, byte[] lookup, boolean masked) {
        byte[] result = new byte[pixels.length];
        for (int i = 0; i < pixels.length; i++) {
            if (masked && ((pixels[i] >>> 24) & 255) < 128) { result[i] = (byte) 255; continue; }
            result[i] = lookup[lookupIndex((pixels[i] >>> 16) & 255, (pixels[i] >>> 8) & 255, pixels[i] & 255)];
        }
        return result;
    }

    private static byte[] quantizeDither(int[] pixels, int width, int height, int[] palette,
                                         byte[] lookup, int colors, boolean masked) {
        byte[] result = new byte[pixels.length];
        float[] current = new float[(width + 2) * 3];
        float[] next = new float[(width + 2) * 3];
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int i = y * width + x;
                int c = pixels[i];
                if (masked && ((c >>> 24) & 255) < 128) {
                    result[i] = (byte) 255;
                    continue;
                }
                int at = (x + 1) * 3;
                int r = clamp(Math.round(((c >>> 16) & 255) + current[at]));
                int g = clamp(Math.round(((c >>> 8) & 255) + current[at + 1]));
                int b = clamp(Math.round((c & 255) + current[at + 2]));
                int nearest = lookup[lookupIndex(r, g, b)] & 255;
                result[i] = (byte) nearest;
                int p = palette[nearest];
                float er = r - ((p >>> 16) & 255), eg = g - ((p >>> 8) & 255), eb = b - (p & 255);
                spread(current, at + 3, er, eg, eb, 7f / 16f);
                spread(next, at - 3, er, eg, eb, 3f / 16f);
                spread(next, at, er, eg, eb, 5f / 16f);
                spread(next, at + 3, er, eg, eb, 1f / 16f);
            }
            current = next;
            next = new float[(width + 2) * 3];
        }
        return result;
    }

    private static byte[] buildLookup(int[] palette, int colors) {
        // 32³-entry 5-bit RGB cache avoids hundreds of palette distance checks per pixel on phones.
        byte[] lookup = new byte[32 * 32 * 32];
        for (int r = 0; r < 32; r++) for (int g = 0; g < 32; g++) for (int b = 0; b < 32; b++) {
            int rgb = (Math.min(255, (r << 3) + 4) << 16)
                    | (Math.min(255, (g << 3) + 4) << 8) | Math.min(255, (b << 3) + 4);
            lookup[(r << 10) | (g << 5) | b] = (byte) closest(rgb, palette, colors);
        }
        return lookup;
    }

    private static int lookupIndex(int r, int g, int b) {
        return ((r >>> 3) << 10) | ((g >>> 3) << 5) | (b >>> 3);
    }

    private static void spread(float[] row, int at, float r, float g, float b, float weight) {
        if (at < 0 || at + 2 >= row.length) return;
        row[at] += r * weight; row[at + 1] += g * weight; row[at + 2] += b * weight;
    }

    private static int closest(int c, int[] palette, int length) {
        int r = (c >>> 16) & 255, g = (c >>> 8) & 255, b = c & 255;
        long bestDistance = Long.MAX_VALUE;
        int best = 0;
        for (int i = 0; i < length; i++) {
            int p = palette[i];
            long dr = r - ((p >>> 16) & 255), dg = g - ((p >>> 8) & 255), db = b - (p & 255);
            long distance = dr * dr * 3 + dg * dg * 4 + db * db * 2;
            if (distance < bestDistance) { bestDistance = distance; best = i; }
        }
        return best;
    }


    /** A draw-ready, triangle-expanded mesh part for a static (bind/default) pose preview. */
    public static final class MeshPart {
        public final int textureIndex;
        public final float[] positions;
        public final float[] texCoords;
        private MeshPart(int textureIndex, float[] positions, float[] texCoords) {
            this.textureIndex = textureIndex; this.positions = positions; this.texCoords = texCoords;
        }
    }

    public static final class ModelPreview {
        public final String modelName;
        public final List<MeshPart> parts;
        public final float centerX, centerY, centerZ, maxExtent;
        private ModelPreview(String modelName, List<MeshPart> parts, float cx, float cy, float cz, float extent) {
            this.modelName = modelName; this.parts = Collections.unmodifiableList(parts);
            this.centerX = cx; this.centerY = cy; this.centerZ = cz; this.maxExtent = extent;
        }
    }

    /**
     * Parses the first body part/model and its default bone pose for a genuine textured 3D preview.
     * Animation sequence playback, alternative bodygroups and attachment editing are not performed.
     */
    public static ModelPreview parseModelForPreview(byte[] data) throws IOException {
        Info info = inspect(data);
        int boneCount = readInt(data, 140), boneTable = readInt(data, 144);
        int bodyPartCount = readInt(data, 204), bodyPartTable = readInt(data, 208);
        if (boneCount < 0 || boneCount > 128 || (boneCount > 0 && !rangeFits(boneTable, (long) boneCount * 112, info.declaredLength)))
            throw new IOException("Tabela de ossos incompleta para o visualizador 3D.");
        if (bodyPartCount < 1 || bodyPartCount > 32 || !rangeFits(bodyPartTable, (long) bodyPartCount * 76, info.declaredLength))
            throw new IOException("O modelo não contém uma tabela de bodyparts válida.");
        int bodyPart = bodyPartTable;
        int modelCount = readInt(data, bodyPart + 64);
        int modelTable = readInt(data, bodyPart + 72);
        if (modelCount < 1 || modelCount > 32 || !rangeFits(modelTable, (long) modelCount * 112, info.declaredLength))
            throw new IOException("A tabela de submodelos está incompleta.");
        int model = modelTable; // first bodygroup option
        int meshCount = readInt(data, model + 72), meshTable = readInt(data, model + 76);
        int vertexCount = readInt(data, model + 80), boneForVertexOffset = readInt(data, model + 84), vertexOffset = readInt(data, model + 88);
        if (meshCount < 1 || meshCount > 256 || !rangeFits(meshTable, (long) meshCount * 20, info.declaredLength))
            throw new IOException("Nenhuma tabela de malhas válida foi encontrada.");
        if (vertexCount < 1 || vertexCount > 65535
                || !rangeFits(vertexOffset, (long) vertexCount * 12, info.declaredLength)
                || !rangeFits(boneForVertexOffset, vertexCount, info.declaredLength))
            throw new IOException("Tabela de vértices incompleta ou excessiva.");

        float[][] boneMatrices = buildDefaultBoneMatrices(data, boneCount, boneTable, info.declaredLength);
        float[] worldVertices = new float[vertexCount * 3];
        for (int i = 0; i < vertexCount; i++) {
            int bone = data[boneForVertexOffset + i] & 255;
            if (boneCount == 0) bone = -1;
            if (bone >= boneCount) throw new IOException("Um vértice referencia um osso que não existe.");
            float x = readFloat(data, vertexOffset + i * 12);
            float y = readFloat(data, vertexOffset + i * 12 + 4);
            float z = readFloat(data, vertexOffset + i * 12 + 8);
            int at = i * 3;
            if (bone >= 0) {
                float[] m = boneMatrices[bone];
                worldVertices[at] = m[0] * x + m[1] * y + m[2] * z + m[3];
                worldVertices[at + 1] = m[4] * x + m[5] * y + m[6] * z + m[7];
                worldVertices[at + 2] = m[8] * x + m[9] * y + m[10] * z + m[11];
            } else {
                worldVertices[at] = x; worldVertices[at + 1] = y; worldVertices[at + 2] = z;
            }
        }

        int skinRefs = readInt(data, 192), skinFamilies = readInt(data, 196), skinTable = readInt(data, 200);
        List<Texture> textureList = textures(data);
        List<MeshPart> parts = new ArrayList<>();
        float minX = Float.POSITIVE_INFINITY, minY = minX, minZ = minX;
        float maxX = Float.NEGATIVE_INFINITY, maxY = maxX, maxZ = maxX;
        int totalOutputVertices = 0;
        for (int mi = 0; mi < meshCount; mi++) {
            int mesh = meshTable + mi * 20;
            int triCount = readInt(data, mesh), triOffset = readInt(data, mesh + 4), skinRef = readInt(data, mesh + 8);
            if (triCount < 0 || triCount > 32768) throw new IOException("Contagem de triângulos inválida na malha.");
            int textureId;
            if (skinRefs > 0 && skinFamilies > 0) {
                if (skinRef < 0 || skinRef >= skinRefs || !rangeFits(skinTable, (long) skinRefs * skinFamilies * 2, info.declaredLength))
                    throw new IOException("Referência de skin fora da tabela.");
                textureId = readU16(data, skinTable + skinRef * 2); // skin family 0
            } else textureId = skinRef;
            if (textureId < 0 || textureId >= info.textureCount) throw new IOException("A malha aponta para um índice de textura inválido.");
            Texture tex = null;
            for (Texture candidate : textureList) if (candidate.index == textureId) { tex = candidate; break; }
            if (tex == null || tex.width < 1 || tex.height < 1) throw new IOException("Não foi possível determinar as dimensões da textura da malha.");
            if (triOffset < HEADER_SIZE || triOffset >= info.declaredLength) throw new IOException("Comandos de triângulo fora do arquivo.");
            FloatBuilder outPos = new FloatBuilder(Math.max(24, triCount * 9));
            FloatBuilder outUv = new FloatBuilder(Math.max(16, triCount * 6));
            int cursor = triOffset, safety = 0;
            while (true) {
                if (++safety > 100000 || !rangeFits(cursor, 2, info.declaredLength)) throw new IOException("Lista de comandos de triângulo incompleta.");
                int command = (short) readU16(data, cursor); cursor += 2;
                if (command == 0) break;
                int commandVertices = Math.abs(command);
                if (commandVertices < 3 || commandVertices > 4096 || !rangeFits(cursor, (long) commandVertices * 8, info.declaredLength))
                    throw new IOException("Comando de triângulo inválido.");
                int[] vi = new int[commandVertices]; short[] ss = new short[commandVertices]; short[] tt = new short[commandVertices];
                for (int j = 0; j < commandVertices; j++) {
                    vi[j] = (short) readU16(data, cursor); ss[j] = (short) readU16(data, cursor + 4); tt[j] = (short) readU16(data, cursor + 6); cursor += 8;
                    if (vi[j] < 0 || vi[j] >= vertexCount) throw new IOException("Índice de vértice fora da malha.");
                }
                if (command > 0) {
                    for (int j = 0; j < commandVertices - 2; j++) {
                        if ((j & 1) == 0) { addCommandVertex(outPos, outUv, vi[j], ss[j], tt[j], worldVertices, tex); addCommandVertex(outPos, outUv, vi[j + 1], ss[j + 1], tt[j + 1], worldVertices, tex); addCommandVertex(outPos, outUv, vi[j + 2], ss[j + 2], tt[j + 2], worldVertices, tex); }
                        else { addCommandVertex(outPos, outUv, vi[j + 1], ss[j + 1], tt[j + 1], worldVertices, tex); addCommandVertex(outPos, outUv, vi[j], ss[j], tt[j], worldVertices, tex); addCommandVertex(outPos, outUv, vi[j + 2], ss[j + 2], tt[j + 2], worldVertices, tex); }
                    }
                } else {
                    for (int j = 1; j < commandVertices - 1; j++) {
                        addCommandVertex(outPos, outUv, vi[0], ss[0], tt[0], worldVertices, tex);
                        addCommandVertex(outPos, outUv, vi[j], ss[j], tt[j], worldVertices, tex);
                        addCommandVertex(outPos, outUv, vi[j + 1], ss[j + 1], tt[j + 1], worldVertices, tex);
                    }
                }
                if (outPos.size() / 3 > 300000) throw new IOException("Visualizador recusou uma malha excessivamente grande.");
            }
            if (outPos.size() == 0) continue;
            float[] positions = outPos.toArray(), uv = outUv.toArray();
            for (int j = 0; j < positions.length; j += 3) {
                minX = Math.min(minX, positions[j]); maxX = Math.max(maxX, positions[j]);
                minY = Math.min(minY, positions[j + 1]); maxY = Math.max(maxY, positions[j + 1]);
                minZ = Math.min(minZ, positions[j + 2]); maxZ = Math.max(maxZ, positions[j + 2]);
            }
            parts.add(new MeshPart(textureId, positions, uv));
            totalOutputVertices += positions.length / 3;
        }
        if (parts.isEmpty() || totalOutputVertices == 0 || !Float.isFinite(minX) || !Float.isFinite(minY) || !Float.isFinite(minZ))
            throw new IOException("Não foi possível decodificar triângulos para o visualizador 3D.");
        float extent = Math.max(maxX - minX, Math.max(maxY - minY, maxZ - minZ));
        if (!(extent > 0f) || !Float.isFinite(extent)) extent = 1f;
        return new ModelPreview(info.name, parts, (minX + maxX) * .5f, (minY + maxY) * .5f, (minZ + maxZ) * .5f, extent);
    }

    private static float[][] buildDefaultBoneMatrices(byte[] data, int count, int table, int length) throws IOException {
        float[][] out = new float[count][12];
        boolean[] done = new boolean[count], visiting = new boolean[count];
        for (int i = 0; i < count; i++) computeBone(i, data, count, table, length, out, done, visiting);
        return out;
    }

    private static void computeBone(int i, byte[] data, int count, int table, int length,
                                    float[][] out, boolean[] done, boolean[] visiting) throws IOException {
        if (done[i]) return;
        if (visiting[i]) throw new IOException("Ciclo inválido na hierarquia de ossos.");
        visiting[i] = true;
        int base = table + i * 112;
        if (!rangeFits(base, 112, length)) throw new IOException("Dados de osso incompletos.");
        int parent = readInt(data, base + 32);
        if (parent < -1 || parent >= count || parent == i) throw new IOException("Relação pai/filho de osso inválida.");
        float x = readFloat(data, base + 64), y = readFloat(data, base + 68), z = readFloat(data, base + 72);
        float ax = readFloat(data, base + 76), ay = readFloat(data, base + 80), az = readFloat(data, base + 84);
        float sx = (float) Math.sin(ax * .5), cx = (float) Math.cos(ax * .5);
        float sy = (float) Math.sin(ay * .5), cy = (float) Math.cos(ay * .5);
        float sz = (float) Math.sin(az * .5), cz = (float) Math.cos(az * .5);
        // GoldSrc AngleQuaternion ordering: X=pitch, Y=yaw, Z=roll.
        float qx = sz * cx * cy - cz * sx * sy;
        float qy = cz * sx * cy + sz * cx * sy;
        float qz = cz * cx * sy - sz * sx * cy;
        float qw = cz * cx * cy + sz * sx * sy;
        float[] local = new float[12];
        local[0] = 1 - 2 * (qy * qy + qz * qz); local[1] = 2 * (qx * qy - qz * qw); local[2] = 2 * (qx * qz + qy * qw); local[3] = x;
        local[4] = 2 * (qx * qy + qz * qw); local[5] = 1 - 2 * (qx * qx + qz * qz); local[6] = 2 * (qy * qz - qx * qw); local[7] = y;
        local[8] = 2 * (qx * qz - qy * qw); local[9] = 2 * (qy * qz + qx * qw); local[10] = 1 - 2 * (qx * qx + qy * qy); local[11] = z;
        if (parent >= 0) {
            computeBone(parent, data, count, table, length, out, done, visiting);
            float[] p = out[parent], m = new float[12];
            for (int row = 0; row < 3; row++) for (int col = 0; col < 3; col++)
                m[row * 4 + col] = p[row * 4] * local[col] + p[row * 4 + 1] * local[4 + col] + p[row * 4 + 2] * local[8 + col];
            m[3] = p[0] * x + p[1] * y + p[2] * z + p[3];
            m[7] = p[4] * x + p[5] * y + p[6] * z + p[7];
            m[11] = p[8] * x + p[9] * y + p[10] * z + p[11];
            out[i] = m;
        } else out[i] = local;
        visiting[i] = false; done[i] = true;
    }

    private static void addCommandVertex(FloatBuilder positions, FloatBuilder uv, int vertex, short s, short t,
                                         float[] vertices, Texture texture) {
        int p = vertex * 3;
        positions.add(vertices[p]); positions.add(vertices[p + 1]); positions.add(vertices[p + 2]);
        uv.add((float) s / texture.width); uv.add(1f - (float) t / texture.height);
    }

    private static float readFloat(byte[] data, int offset) throws IOException {
        int bits = readInt(data, offset);
        float value = Float.intBitsToFloat(bits);
        if (!Float.isFinite(value) || Math.abs(value) > 1000000f) throw new IOException("Valor numérico inválido no modelo.");
        return value;
    }

    private static final class FloatBuilder {
        private float[] values; private int size;
        FloatBuilder(int initial) { values = new float[Math.max(12, initial)]; }
        int size() { return size; }
        void add(float value) { if (size >= values.length) { float[] n = new float[Math.max(values.length * 2, size + 1)]; System.arraycopy(values, 0, n, 0, size); values = n; } values[size++] = value; }
        float[] toArray() { float[] out = new float[size]; System.arraycopy(values, 0, out, 0, size); return out; }
    }

    private static int[] readPalette(byte[] data, Texture texture) throws IOException {
        requireTexture(data, texture);
        int[] palette = new int[texture.paletteCount];
        for (int i = 0; i < palette.length; i++) {
            int off = texture.paletteOffset + i * 3;
            palette[i] = ((data[off] & 255) << 16) | ((data[off + 1] & 255) << 8) | (data[off + 2] & 255);
        }
        return palette;
    }

    private static void requireTexture(byte[] data, Texture texture) throws IOException {
        if (texture == null || !texture.embedded) throw new IOException("Esta textura não possui dados embutidos editáveis no arquivo.");
        if (data == null || texture.pixelOffset < 0 || texture.paletteOffset < 0
                || !rangeFits(texture.pixelOffset, (long) texture.width * texture.height, data.length)
                || !rangeFits(texture.paletteOffset, (long) texture.paletteCount * 3, data.length)) {
            throw new IOException("Dados de textura incompletos.");
        }
    }

    private static void checkModel(byte[] data) throws IOException {
        if (data == null || data.length < HEADER_SIZE || data.length > MAX_MODEL_BYTES) {
            throw new IOException("Arquivo .mdl vazio, incompleto ou maior que 32 MB.");
        }
        if (data[0] != 'I' || data[1] != 'D' || data[2] != 'S' || data[3] != 'T') {
            throw new IOException("Assinatura inválida: esperado IDST, formato GoldSrc Studio MDL.");
        }
        int version = readInt(data, 4);
        if (version != 10) throw new IOException("Versão MDL " + version + " não suportada. Esta etapa aceita GoldSrc Studio MDL v10.");
    }

    private static int readInt(byte[] d, int off) throws IOException {
        if (!rangeFits(off, 4, d.length)) throw new IOException("Cabeçalho .mdl incompleto.");
        return (d[off] & 255) | ((d[off + 1] & 255) << 8) | ((d[off + 2] & 255) << 16) | (d[off + 3] << 24);
    }

    private static int readU16(byte[] d, int off) throws IOException {
        if (!rangeFits(off, 2, d.length)) throw new IOException("Paleta incompleta.");
        return (d[off] & 255) | ((d[off + 1] & 255) << 8);
    }

    private static String cString(byte[] d, int off, int max) throws IOException {
        if (!rangeFits(off, max, d.length)) throw new IOException("Campo de texto incompleto no cabeçalho .mdl.");
        int n = 0; while (n < max && d[off + n] != 0) n++;
        return new String(d, off, n, StandardCharsets.US_ASCII).trim();
    }

    private static boolean rangeFits(long off, long size, long length) {
        return off >= 0 && size >= 0 && off <= length && size <= length - off;
    }

    private static int clamp(int v) { return Math.max(0, Math.min(255, v)); }
}
