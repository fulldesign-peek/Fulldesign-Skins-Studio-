package com.fulldesign.skinstudio;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Lightweight in-app localization. Language names are shown in their native spelling. */
public final class LanguageManager {
    public static final String PT = "pt", ES = "es", RU = "ru", EN = "en";
    private static final String PREFS = "fulldesign_preferences";
    private static final String LANGUAGE_KEY = "language";
    private static final Map<String, String[]> DICT = new LinkedHashMap<>();

    static {
        add("Idioma do aplicativo", "Idioma de la aplicación", "Язык приложения", "App language");
        add("Selecione o idioma", "Selecciona el idioma", "Выберите язык", "Select language");
        add("Skin Studio", "Skin Studio", "Skin Studio", "Skin Studio");
        add("ETAPA 1 · EDITOR E CONVERSOR DE TEXTURAS", "ETAPA 1 · EDITOR Y CONVERSOR DE TEXTURAS", "ЭТАП 1 · РЕДАКТОР И КОНВЕРТЕР ТЕКСТУР", "STEP 1 · TEXTURE EDITOR AND CONVERTER");
        add("Abrir Pack Mixer / Editor MDL", "Abrir Pack Mixer / Editor MDL", "Открыть Pack Mixer / редактор MDL", "Open Pack Mixer / MDL Editor");
        add("Importar imagem (PNG, JPG, BMP)", "Importar imagen (PNG, JPG, BMP)", "Импортировать изображение (PNG, JPG, BMP)", "Import image (PNG, JPG, BMP)");
        add("PRÉ-VISUALIZAÇÃO", "VISTA PREVIA", "ПРЕДПРОСМОТР", "PREVIEW");
        add("ORIGINAL", "ORIGINAL", "ОРИГИНАЛ", "ORIGINAL");
        add("ATUAL / CONVERTIDA", "ACTUAL / CONVERTIDA", "ТЕКУЩЕЕ / КОНВЕРТИРОВАННОЕ", "CURRENT / CONVERTED");
        add("Editor de imagem", "Editor de imagen", "Редактор изображений", "Image editor");
        add("Os ajustes são aplicados em uma cópia da imagem original.", "Los ajustes se aplican a una copia de la imagen original.", "Изменения применяются к копии исходного изображения.", "Adjustments are applied to a copy of the original image.");
        add("Brilho", "Brillo", "Яркость", "Brightness");
        add("Contraste", "Contraste", "Контраст", "Contrast");
        add("Saturação", "Saturación", "Насыщенность", "Saturation");
        add("Matiz", "Tono", "Оттенок", "Hue");
        add("Nitidez", "Nitidez", "Резкость", "Sharpness");
        add("Aplicar ajustes", "Aplicar ajustes", "Применить изменения", "Apply adjustments");
        add("Descartar ajustes", "Descartar ajustes", "Сбросить изменения", "Discard adjustments");
        add("Conversor BMP", "Conversor BMP", "Конвертер BMP", "BMP converter");
        add("Escolha a profundidade de cor e a resolução de saída.", "Elige la profundidad de color y la resolución de salida.", "Выберите глубину цвета и разрешение вывода.", "Choose color depth and output resolution.");
        add("Formato de destino", "Formato de destino", "Формат вывода", "Output format");
        add("BMP indexado · 8 bits · até 256 cores", "BMP indexado · 8 bits · hasta 256 colores", "Индексированный BMP · 8 бит · до 256 цветов", "Indexed BMP · 8-bit · up to 256 colors");
        add("BMP RGB · 24 bits · sem paleta", "BMP RGB · 24 bits · sin paleta", "RGB BMP · 24 бит · без палитры", "RGB BMP · 24-bit · no palette");
        add("Resolução", "Resolución", "Разрешение", "Resolution");
        add("Manter dimensões", "Mantener dimensiones", "Сохранить размеры", "Keep dimensions");
        add("Usar dithering Floyd–Steinberg", "Usar tramado Floyd–Steinberg", "Использовать дизеринг Floyd–Steinberg", "Use Floyd–Steinberg dithering");
        add("Pixels transparentes → índice 255 (azul)", "Píxeles transparentes → índice 255 (azul)", "Прозрачные пиксели → индекс 255 (синий)", "Transparent pixels → index 255 (blue)");
        add("Azul puro RGB(0,0,255) → índice 255", "Azul puro RGB(0,0,255) → índice 255", "Чистый синий RGB(0,0,255) → индекс 255", "Pure blue RGB(0,0,255) → index 255");
        add("A máscara é opcional. O app não transforma azul em transparência sem sua autorização.", "La máscara es opcional. La app no convierte el azul en transparencia sin tu autorización.", "Маска необязательна. Приложение не делает синий прозрачным без вашего разрешения.", "The mask is optional. The app does not turn blue into transparency without permission.");
        add("Nome do arquivo (ex.: ak47_skin)", "Nombre de archivo (ej.: ak47_skin)", "Имя файла (например, ak47_skin)", "File name (e.g. ak47_skin)");
        add("Converter e exportar BMP", "Convertir y exportar BMP", "Преобразовать и экспортировать BMP", "Convert and export BMP");
        add("Status e validação", "Estado y validación", "Статус и проверка", "Status and validation");
        add("Importe uma imagem para começar.", "Importa una imagen para comenzar.", "Импортируйте изображение, чтобы начать.", "Import an image to begin.");
        add("Funciona offline · Arquivos originais não são sobrescritos", "Funciona sin conexión · Los archivos originales no se sobrescriben", "Работает офлайн · Исходные файлы не перезаписываются", "Works offline · Original files are not overwritten");
        add("Nenhuma imagem importada", "No se ha importado ninguna imagen", "Изображение не импортировано", "No image imported");
        add("Pronto para importar um modelo ou pack.", "Listo para importar un modelo o paquete.", "Готово к импорту модели или пакета.", "Ready to import a model or pack.");
        add("Pack Mixer & MDL", "Pack Mixer y MDL", "Pack Mixer и MDL", "Pack Mixer & MDL");
        add("Inspeção de modelos GoldSrc e edição de pixels das texturas embutidas.", "Inspección de modelos GoldSrc y edición de píxeles de texturas integradas.", "Проверка моделей GoldSrc и редактирование пикселей встроенных текстур.", "Inspect GoldSrc models and edit embedded texture pixels.");
        add("Importar arquivos", "Importar archivos", "Импорт файлов", "Import files");
        add("ABRIR MODELO .MDL", "ABRIR MODELO .MDL", "ОТКРЫТЬ МОДЕЛЬ .MDL", "OPEN .MDL MODEL");
        add("IMPORTAR PACK ZIP", "IMPORTAR PAQUETE ZIP", "ИМПОРТИРОВАТЬ ZIP-ПАКЕТ", "IMPORT ZIP PACK");
        add("ESCOLHER IMAGEM DE SUBSTITUIÇÃO", "ELEGIR IMAGEN DE REEMPLAZO", "ВЫБРАТЬ ИЗОБРАЖЕНИЕ ДЛЯ ЗАМЕНЫ", "CHOOSE REPLACEMENT IMAGE");
        add("Nenhuma imagem de substituição selecionada.", "No se ha seleccionado una imagen de reemplazo.", "Изображение для замены не выбрано.", "No replacement image selected.");
        add("Modelo selecionado", "Modelo seleccionado", "Выбранная модель", "Selected model");
        add("VISUALIZADOR 3D · TOQUE E ARRASTE PARA GIRAR", "VISOR 3D · TOCA Y ARRASTRA PARA GIRAR", "3D-ПРОСМОТР · КОСНИТЕСЬ И ПЕРЕТАЩИТЕ ДЛЯ ПОВОРОТА", "3D VIEWER · TOUCH AND DRAG TO ROTATE");
        add("CENTRALIZAR VISUALIZAÇÃO", "CENTRAR VISTA", "ЦЕНТРИРОВАТЬ ВИД", "CENTER VIEW");
        add("TEXTURAS EMBUTIDAS", "TEXTURAS INTEGRADAS", "ВСТРОЕННЫЕ ТЕКСТУРЫ", "EMBEDDED TEXTURES");
        add("SUBSTITUIR TEXTURA SELECIONADA", "REEMPLAZAR TEXTURA SELECCIONADA", "ЗАМЕНИТЬ ВЫБРАННУЮ ТЕКСТУРУ", "REPLACE SELECTED TEXTURE");
        add("TROCAR TEXTURAS POR NOME NO PACK", "REEMPLAZAR TEXTURAS POR NOMBRE EN EL PAQUETE", "ЗАМЕНИТЬ ТЕКСТУРЫ ПО ИМЕНИ В ПАКЕТЕ", "REPLACE TEXTURES BY NAME IN PACK");
        add("EXPORTAR MODELO .MDL", "EXPORTAR MODELO .MDL", "ЭКСПОРТ МОДЕЛИ .MDL", "EXPORT .MDL MODEL");
        add("Conteúdo do pack", "Contenido del paquete", "Содержимое пакета", "Pack contents");
        add("Arquivos importados são extraídos para uma pasta de trabalho isolada. O ZIP de origem não é sobrescrito.", "Los archivos importados se extraen a una carpeta de trabajo aislada. El ZIP original no se sobrescribe.", "Импортированные файлы извлекаются в отдельную рабочую папку. Исходный ZIP не перезаписывается.", "Imported files are extracted to an isolated work folder. The source ZIP is not overwritten.");
        add("EXPORTAR PACK ZIP MODIFICADO", "EXPORTAR PAQUETE ZIP MODIFICADO", "ЭКСПОРТИРОВАТЬ ИЗМЕНЁННЫЙ ZIP-ПАКЕТ", "EXPORT MODIFIED ZIP PACK");
        add("Origem do modelo · X / Y / Z", "Origen del modelo · X / Y / Z", "Начало координат модели · X / Y / Z", "Model origin · X / Y / Z");
        add("Passo (ex.: 1.0)", "Paso (ej.: 1.0)", "Шаг (например, 1.0)", "Step (e.g. 1.0)");
        add("EXPORTAR DIRETIVA QC (.TXT)", "EXPORTAR DIRECTIVA QC (.TXT)", "ЭКСПОРТ ДИРЕКТИВЫ QC (.TXT)", "EXPORT QC DIRECTIVE (.TXT)");
        add("FOV do projeto", "FOV del proyecto", "FOV проекта", "Project FOV");
        add("FOV (metadado de projeto)", "FOV (metadato del proyecto)", "FOV (метаданные проекта)", "FOV (project metadata)");
        add("EXPORTAR CONFIGURAÇÕES DO PROJETO", "EXPORTAR CONFIGURACIÓN DEL PROYECTO", "ЭКСПОРТИРОВАТЬ НАСТРОЙКИ ПРОЕКТА", "EXPORT PROJECT SETTINGS");
        add("Status", "Estado", "Статус", "Status");
        add("Pronto para importar um modelo ou pack.", "Listo para importar un modelo o paquete.", "Готово к импорту модели или пакета.", "Ready to import a model or pack.");
        add("Texturas embutidas", "Texturas integradas", "Встроенные текстуры", "Embedded textures");
        add("textura mascarada", "textura enmascarada", "текстура с маской", "masked texture");
        add("textura opaca", "textura opaca", "непрозрачная текстура", "opaque texture");
        add("TROCA EM LOTE: APLICAR TEXTURA DE BRAÇO/LUVA EM SKINS COMPATÍVEIS", "LOTE: APLICAR TEXTURA DE BRAZO/GUANTE A SKINS COMPATIBLES", "ПАКЕТНО: ПРИМЕНИТЬ ТЕКСТУРУ РУК/ПЕРЧАТОК К СОВМЕСТИМЫМ СКИНАМ", "BATCH: APPLY ARM/GLOVE TEXTURE TO COMPATIBLE SKINS");
        add("Aplicar textura de braço/luva em lote", "Aplicar textura de brazo/guante en lote", "Пакетное применение текстуры рук/перчаток", "Batch apply arm/glove texture");
        add("Aplicação em lote concluída", "Aplicación por lotes completada", "Пакетное применение завершено", "Batch application completed");
        add("IDIOMA", "IDIOMA", "ЯЗЫК", "LANGUAGE");
        add("Aplicação de braço/luva em lote", "Aplicación de brazo/guante por lotes", "Пакетное применение рук/перчаток", "Batch arm/glove application");
        add("Use o modelo aberto e a textura selecionada como origem. O aplicativo aplica essa textura aos slots de textura com nomes reconhecíveis de braço, mão, manga ou luva nos outros modelos MDL do ZIP.", "Usa el modelo abierto y la textura seleccionada como origen. La aplicación aplica esa textura a las ranuras reconocibles de brazo, mano, manga o guante en otros modelos MDL del ZIP.", "Использует открытую модель и выбранную текстуру как источник. Приложение применяет её к распознаваемым текстурам рук, кистей, рукавов или перчаток в других MDL-файлах ZIP.", "Uses the open model and selected texture as the source. The app applies it to recognizable arm, hand, sleeve, or glove texture slots in other MDL models in the ZIP.");
        add("APLICAR TEXTURA DE BRAÇO/LUVA EM LOTE", "APLICAR TEXTURA DE BRAZO/GUANTE POR LOTES", "ПАКЕТНО ПРИМЕНИТЬ ТЕКСТУРУ РУК/ПЕРЧАТОК", "BATCH APPLY ARM/GLOVE TEXTURE");
        add("A função altera pixels de texturas embutidas, não transfere a geometria dos braços. Modelos que não tenham slots de braço/luva identificáveis serão ignorados.", "La función cambia píxeles de texturas integradas, no transfiere la geometría de los brazos. Se omitirán los modelos sin ranuras identificables de brazo/guante.", "Функция меняет пиксели встроенных текстур, а не переносит геометрию рук. Модели без распознаваемых текстур рук/перчаток будут пропущены.", "This changes embedded texture pixels; it does not transfer arm geometry. Models without identifiable arm/glove texture slots are skipped.");
        add("Selecione um pack ZIP e abra nele um modelo MDL. Depois selecione a textura de origem na lista de texturas.", "Selecciona un paquete ZIP y abre un modelo MDL dentro de él. Después, elige la textura de origen en la lista.", "Выберите ZIP-пакет и откройте в нём MDL-модель. Затем выберите исходную текстуру в списке.", "Import a ZIP pack and open an MDL inside it. Then select the source texture in the texture list.");
        add("Nenhuma textura compatível de braço/luva foi encontrada nos outros modelos. Nenhum outro modelo foi alterado.", "No se encontraron texturas compatibles de brazo/guante en los demás modelos. No se modificó ningún otro modelo.", "В других моделях не найдены совместимые текстуры рук/перчаток. Другие модели не изменены.", "No compatible arm/glove textures were found in other models. No other models were changed.");
        add("USAR TEXTURA SELECIONADA COMO BRAÇO", "USAR TEXTURA SELECCIONADA COMO BRAZO", "ИСПОЛЬЗОВАТЬ ВЫБРАННУЮ ТЕКСТУРУ КАК РУКУ", "USE SELECTED TEXTURE AS ARM");
        add("USAR TEXTURA SELECIONADA COMO LUVA", "USAR TEXTURA SELECCIONADA COMO GUANTE", "ИСПОЛЬЗОВАТЬ ВЫБРАННУЮ ТЕКСТУРУ КАК ПЕРЧАТКУ", "USE SELECTED TEXTURE AS GLOVE");
        add("Textura de braço de origem", "Textura de brazo de origen", "Исходная текстура руки", "Source arm texture");
        add("Textura de luva de origem", "Textura de guante de origen", "Исходная текстура перчатки", "Source glove texture");
        add("Nenhuma textura definida", "No se ha definido ninguna textura", "Текстура не назначена", "No texture assigned");
        add("Pack importado", "Paquete importado", "Пакет импортирован", "Pack imported");
        add("Idioma alterado. As imagens e ajustes atuais foram preservados.", "Idioma cambiado. Se conservaron las imágenes y los ajustes actuales.", "Язык изменён. Текущие изображения и настройки сохранены.", "Language changed. Current images and adjustments were preserved.");
        add("Idioma alterado. O modelo, o pack e as texturas selecionadas foram preservados.", "Idioma cambiado. Se conservaron el modelo, el paquete y las texturas seleccionadas.", "Язык изменён. Модель, пакет и выбранные текстуры сохранены.", "Language changed. The model, pack, and selected textures were preserved.");
        add("Aplicação de braço/luva em lote", "Aplicación de brazo/guante por lotes", "Пакетное применение рук/перчаток", "Batch arm/glove application");
        add("O aplicativo procurará outros arquivos MDL no ZIP e substituirá somente slots de textura com nomes que indiquem braços, mãos, mangas ou luvas. Cada modelo mantém sua própria paleta e dimensões; modelos sem slots reconhecíveis serão ignorados.", "La aplicación buscará otros archivos MDL en el ZIP y reemplazará solo ranuras de textura cuyos nombres indiquen brazos, manos, mangas o guantes. Cada modelo conserva su propia paleta y dimensiones; se omitirán modelos sin ranuras reconocibles.", "Приложение найдёт другие MDL-файлы в ZIP и заменит только текстуры, названия которых указывают на руки, кисти, рукава или перчатки. Каждый модельный файл сохранит свою палитру и размеры; модели без распознаваемых слотов будут пропущены.", "The app will search other MDL files in the ZIP and replace only texture slots whose names indicate arms, hands, sleeves, or gloves. Each model keeps its own palette and dimensions; models without recognized slots are skipped.");
        add("Importe um ZIP, abra um modelo de dentro dele e selecione uma textura embutida.", "Importa un ZIP, abre un modelo de ese paquete y selecciona una textura integrada.", "Импортируйте ZIP, откройте модель из него и выберите встроенную текстуру.", "Import a ZIP, open a model from it, and select an embedded texture.");
        add("Selecione um pack ZIP e defina pelo menos uma textura de origem como braço ou luva.", "Selecciona un paquete ZIP y define al menos una textura de origen como brazo o guante.", "Выберите ZIP-пакет и назначьте хотя бы одну исходную текстуру как руку или перчатку.", "Import a ZIP pack and assign at least one source texture as an arm or glove.");
        add("Textura de braço definida: ", "Textura de brazo definida: ", "Текстура руки назначена: ", "Arm texture assigned: ");
        add("Textura de luva definida: ", "Textura de guante asignada: ", "Текстура перчатки назначена: ", "Glove texture assigned: ");
        add("Cancelar", "Cancelar", "Отмена", "Cancel");
        add("Aplicar em lote", "Aplicar por lotes", "Применить пакетно", "Apply batch");
        add("não definida", "no definida", "не назначена", "not set");
        add("FULLDESIGN  /  SKIN STUDIO", "FULLDESIGN  /  SKIN STUDIO", "FULLDESIGN  /  SKIN STUDIO", "FULLDESIGN  /  SKIN STUDIO");
        add("Inspeção de modelos GoldSrc e edição de pixels das texturas embutidas.", "Inspección de modelos GoldSrc y edición de píxeles de texturas integradas.", "Проверка моделей GoldSrc и редактирование пикселей встроенных текстур.", "Inspect GoldSrc models and edit embedded texture pixels.");
        add("Importe um .mdl ou um pack ZIP para inspecionar o cabeçalho e as texturas reais.", "Importa un .mdl o un paquete ZIP para inspeccionar la cabecera y las texturas reales.", "Импортируйте .mdl или ZIP-пакет для проверки заголовка и реальных текстур.", "Import an .mdl or ZIP pack to inspect the header and real textures.");
        add("Selecione uma textura abaixo para ver os pixels decodificados do próprio .mdl.", "Selecciona una textura abajo para ver los píxeles decodificados del propio .mdl.", "Выберите текстуру ниже, чтобы увидеть пиксели, декодированные из самого .mdl.", "Select a texture below to view pixels decoded from the .mdl itself.");
        add("Nenhuma imagem de substituição selecionada.", "No se ha seleccionado una imagen de reemplazo.", "Изображение для замены не выбрано.", "No replacement image selected.");
        add("Troca em lote opcional: dentro do ZIP, nomes de imagens devem corresponder exatamente aos nomes das texturas do MDL (sem extensão).", "Reemplazo por lotes opcional: dentro del ZIP, los nombres de imagen deben coincidir exactamente con los nombres de textura MDL (sin extensión).", "Необязательная пакетная замена: имена изображений в ZIP должны точно совпадать с именами текстур MDL без расширения.", "Optional batch replacement: image names in the ZIP must exactly match MDL texture names without the extension.");
        add("Os controles geram uma diretiva $origin para QC. Eles não alteram diretamente as coordenadas internas do MDL compilado: a aplicação do novo origin exige recompilar o modelo a partir do QC/SMD original.", "Los controles generan una directiva $origin para QC. No cambian directamente las coordenadas internas del MDL compilado: aplicar el nuevo origen requiere recompilar el modelo desde el QC/SMD original.", "Эти элементы создают директиву $origin для QC. Они не изменяют координаты скомпилированного MDL напрямую: для применения нового начала координат нужно пересобрать модель из исходного QC/SMD.", "These controls create a $origin directive for QC. They do not directly change coordinates in a compiled MDL; applying the new origin requires recompiling from the original QC/SMD.");
        add("O FOV será incluído em um arquivo auxiliar do projeto/ZIP. A textura BMP e o MDL não armazenam um comando universal de FOV; o cliente Android precisa aceitar a configuração para que ela tenha efeito no jogo.", "El FOV se incluirá en un archivo auxiliar del proyecto/ZIP. La textura BMP y el MDL no almacenan un comando universal de FOV; el cliente Android debe aceptar la configuración para que tenga efecto en el juego.", "FOV будет включён во вспомогательный файл проекта/ZIP. Текстура BMP и MDL не хранят универсальную команду FOV; Android-клиент должен поддерживать эту настройку, чтобы она влияла на игру.", "FOV is included in a project/ZIP sidecar file. BMP textures and MDL files do not store a universal FOV command; the Android client must support the setting for it to affect the game.");
        add("Este modelo declara zero texturas.", "Este modelo declara cero texturas.", "В этой модели указано ноль текстур.", "This model declares zero textures.");
        add("Entradas: ", "Entradas: ", "Элементы: ", "Entries: ");
        add("A lista está limitada a 120 arquivos visíveis. O ZIP de saída preservará todas as entradas.", "La lista está limitada a 120 archivos visibles. El ZIP de salida conservará todas las entradas.", "Список ограничен 120 видимыми файлами. В выходном ZIP сохранятся все элементы.", "The list is limited to 120 visible files. The output ZIP will preserve all entries.");
        add("Nenhum arquivo encontrado no pack.", "No se encontraron archivos en el paquete.", "В пакете не найдено файлов.", "No files found in the pack.");
        add("O modelo não contém uma tabela de bodyparts válida.", "El modelo no contiene una tabla válida de bodyparts.", "Модель не содержит допустимую таблицу bodyparts.", "The model does not contain a valid bodyparts table.");
        add("Imagem de substituição carregada.", "Imagen de reemplazo cargada.", "Изображение для замены загружено.", "Replacement image loaded.");
        add("Pronto para importar um modelo ou pack.", "Listo para importar un modelo o paquete.", "Готово к импорту модели или пакета.", "Ready to import a model or pack.");
        add("FOV do projeto", "FOV del proyecto", "FOV проекта", "Project FOV");
        add("Status", "Estado", "Статус", "Status");
        add("Modelo selecionado", "Modelo seleccionado", "Выбранная модель", "Selected model");
        add("Conteúdo do pack", "Contenido del paquete", "Содержимое пакета", "Pack contents");
        add("Importar arquivos", "Importar archivos", "Импорт файлов", "Import files");
        add("Origem do modelo", "Origen del modelo", "Начало координат модели", "Model origin");
        add("Cancelar", "Cancelar", "Отмена", "Cancel");
        add("Substituir", "Reemplazar", "Заменить", "Replace");
        add("Continuar?", "¿Continuar?", "Продолжить?", "Continue?");
        add("Lendo e validando a imagem…", "Leyendo y validando la imagen…", "Чтение и проверка изображения…", "Reading and validating image…");
        add("Imagem importada. Ajuste a imagem ou converta para BMP.", "Imagen importada. Ajusta la imagen o conviértela a BMP.", "Изображение импортировано. Отредактируйте его или преобразуйте в BMP.", "Image imported. Adjust it or convert it to BMP.");
        add("Falha na importação:", "Error al importar:", "Ошибка импорта:", "Import failed:");
        add("Importe uma imagem antes de aplicar os ajustes.", "Importa una imagen antes de aplicar los ajustes.", "Импортируйте изображение перед применением изменений.", "Import an image before applying adjustments.");
        add("Aplicando ajustes à cópia…", "Aplicando ajustes a la copia…", "Применение изменений к копии…", "Applying adjustments to copy…");
        add("Ajustes aplicados. A imagem original foi mantida intacta.", "Ajustes aplicados. La imagen original se mantuvo intacta.", "Изменения применены. Исходное изображение не изменено.", "Adjustments applied. The original image remains unchanged.");
        add("Não foi possível aplicar os ajustes:", "No se pudieron aplicar los ajustes:", "Не удалось применить изменения:", "Could not apply adjustments:");
        add("Nenhuma imagem carregada.", "No hay ninguna imagen cargada.", "Изображение не загружено.", "No image loaded.");
        add("Ajustes descartados. Exibindo a imagem original.", "Ajustes descartados. Mostrando la imagen original.", "Изменения отменены. Показано исходное изображение.", "Adjustments discarded. Showing the original image.");
        add("Importe uma imagem antes de converter.", "Importa una imagen antes de convertir.", "Импортируйте изображение перед преобразованием.", "Import an image before converting.");
        add("Validando dimensões e convertendo a textura…", "Validando dimensiones y convirtiendo la textura…", "Проверка размеров и преобразование текстуры…", "Validating dimensions and converting texture…");
        add("Conversão concluída.", "Conversión completada.", "Преобразование завершено.", "Conversion complete.");
        add("Falha na conversão:", "Error de conversión:", "Ошибка преобразования:", "Conversion failed:");
        add("Não há arquivo convertido para salvar.", "No hay ningún archivo convertido para guardar.", "Нет преобразованного файла для сохранения.", "There is no converted file to save.");
        add("Salvando o arquivo…", "Guardando el archivo…", "Сохранение файла…", "Saving file…");
        add("Arquivo salvo com sucesso:", "Archivo guardado correctamente:", "Файл успешно сохранён:", "File saved successfully:");
        add("Falha ao salvar o arquivo:", "Error al guardar el archivo:", "Не удалось сохранить файл:", "Failed to save file:");
        add("Pack lido com validação de caminho e limites de tamanho. Selecione um .mdl na lista para abrir as texturas.", "Paquete leído con validación de rutas y límites de tamaño. Selecciona un .mdl de la lista para abrir sus texturas.", "Пакет прочитан с проверкой путей и ограничений размера. Выберите .mdl в списке, чтобы открыть текстуры.", "Pack read with path and size validation. Select an .mdl in the list to open its textures.");
        add("Modelo exportado. A geometria e os dados não editados foram preservados.", "Modelo exportado. Se conservaron la geometría y los datos no editados.", "Модель экспортирована. Геометрия и неизменённые данные сохранены.", "Model exported. Geometry and unedited data were preserved.");
        add("Pack exportado sem sobrescrever o ZIP original.", "Paquete exportado sin sobrescribir el ZIP original.", "Пакет экспортирован без перезаписи исходного ZIP.", "Pack exported without overwriting the source ZIP.");
        add("Configurações de projeto exportadas em arquivo auxiliar.", "Configuración del proyecto exportada en un archivo auxiliar.", "Настройки проекта экспортированы во вспомогательный файл.", "Project settings exported to a sidecar file.");
        add("Diretiva $origin exportada.", "Directiva $origin exportada.", "Директива $origin экспортирована.", "$origin directive exported.");
        add("Modelo validado.", "Modelo validado.", "Модель проверена.", "Model validated.");
        add("Visualizador 3D:", "Visor 3D:", "3D-просмотр:", "3D viewer:");
        add("Textura real decodificada do .mdl. O visualizador 3D mostra a malha estática extraída do modelo.", "Textura real decodificada del .mdl. El visor 3D muestra la malla estática extraída del modelo.", "Реальная текстура декодирована из .mdl. 3D-просмотр показывает статическую сетку модели.", "Real texture decoded from .mdl. The 3D viewer shows the static mesh extracted from the model.");
        add("Falha ao decodificar a textura:", "Error al decodificar la textura:", "Ошибка декодирования текстуры:", "Failed to decode texture:");
        add("Selecione uma textura embutida primeiro.", "Selecciona primero una textura integrada.", "Сначала выберите встроенную текстуру.", "Select an embedded texture first.");
        add("Escolha a imagem de substituição primeiro.", "Elige primero la imagen de reemplazo.", "Сначала выберите изображение для замены.", "Choose a replacement image first.");
        add("Convertendo a imagem para a paleta original do MDL…", "Convirtiendo la imagen a la paleta original del MDL…", "Преобразование изображения в исходную палитру MDL…", "Converting image to the original MDL palette…");
        add("Substituição cancelada:", "Reemplazo cancelado:", "Замена отменена:", "Replacement cancelled:");
        add("Textura substituída e validada. Salve o .mdl ou exporte o ZIP para usar no jogo.", "Textura reemplazada y validada. Guarda el .mdl o exporta el ZIP para usarlo en el juego.", "Текстура заменена и проверена. Сохраните .mdl или экспортируйте ZIP для использования в игре.", "Texture replaced and validated. Save the .mdl or export the ZIP to use it in-game.");
        add("Importe um ZIP e abra um .mdl que esteja dentro dele primeiro.", "Primero importa un ZIP y abre un .mdl que esté dentro.", "Сначала импортируйте ZIP и откройте содержащийся в нём .mdl.", "First import a ZIP and open an .mdl contained in it.");
        add("Nenhuma correspondência exata encontrada.", "No se encontró ninguna coincidencia exacta.", "Точное совпадение не найдено.", "No exact match found.");
        add("Falha ao abrir", "Error al abrir", "Ошибка открытия", "Failed to open");
        add("Carregue um modelo .mdl primeiro.", "Primero carga un modelo .mdl.", "Сначала загрузите модель .mdl.", "Load an .mdl model first.");
        add("Importe um pack ZIP primeiro.", "Primero importa un paquete ZIP.", "Сначала импортируйте ZIP-пакет.", "Import a ZIP pack first.");
        add("Importe um modelo para nomear a diretiva QC.", "Importa un modelo para nombrar la directiva QC.", "Импортируйте модель, чтобы указать имя для директивы QC.", "Import a model to name the QC directive.");
        add("Substituir textura:", "Reemplazar textura:", "Заменить текстуру:", "Replace texture:");
        add("O app vai redimensionar a imagem para", "La app cambiará el tamaño de la imagen a", "Приложение изменит размер изображения до", "The app will resize the image to");
        add(", mapear para a paleta existente e manter o restante do MDL intacto. Continuar?", ", asignarla a la paleta existente y mantener intacto el resto del MDL. ¿Continuar?", ", сопоставит её с существующей палитрой и сохранит остальные данные MDL. Продолжить?", ", map it to the existing palette, and keep the rest of the MDL intact. Continue?");
        add("Arquivo: ", "Archivo: ", "Файл: ", "File: ");
        add("Nome interno: ", "Nombre interno: ", "Внутреннее имя: ", "Internal name: ");
        add("Formato: GoldSrc Studio MDL v", "Formato: GoldSrc Studio MDL v", "Формат: GoldSrc Studio MDL v", "Format: GoldSrc Studio MDL v");
        add("Tamanho declarado: ", "Tamaño declarado: ", "Заявленный размер: ", "Declared size: ");
        add("bytes", "bytes", "байт", "bytes");
        add("Tabela de texturas: ", "Tabla de texturas: ", "Таблица текстур: ", "Texture table: ");
        add("entrada(s)", "entrada(s)", "записей", "entry/entries");
        add("Famílias de skin: ", "Familias de skin: ", "Семейства скинов: ", "Skin families: ");
        add(" · referências de skin: ", " · referencias de skin: ", " · ссылок на скины: ", " · skin references: ");
        add("cores · ", "colores · ", "цветов · ", "colors · ");
        add("Esta entrada não possui pixels de textura embutidos editáveis.", "Esta entrada no contiene píxeles de textura integrados editables.", "Эта запись не содержит доступных для редактирования встроенных пикселей текстуры.", "This entry has no editable embedded texture pixels.");
        add("Selecione uma textura abaixo para pré-visualizar ou substituir seus pixels.", "Selecciona una textura abajo para previsualizar o reemplazar sus píxeles.", "Выберите текстуру ниже для просмотра или замены её пикселей.", "Select a texture below to preview or replace its pixels.");
        add("Não foi possível ler o modelo:", "No se pudo leer el modelo:", "Не удалось прочитать модель:", "Could not read model:");
        add("O visualizador 3D mostra a malha estática extraída do modelo.", "El visor 3D muestra la malla estática extraída del modelo.", "3D-просмотр показывает статическую сетку, извлечённую из модели.", "The 3D viewer displays the static mesh extracted from the model.");
        add("Preparando a malha 3D…", "Preparando la malla 3D…", "Подготовка 3D-сетки…", "Preparing 3D mesh…");
        add("ABRIR", "ABRIR", "ОТКРЫТЬ", "OPEN");
        add("Preparando aplicação em lote de braço/luva…", "Preparando la aplicación por lotes de brazo/guante…", "Подготовка пакетного применения рук/перчаток…", "Preparing batch arm/glove application…");
        add("Aplicação em lote interrompida:", "Aplicación por lotes interrumpida:", "Пакетное применение прервано:", "Batch application interrupted:");
        add("Troca em lote concluída:", "Reemplazo por lotes completado:", "Пакетная замена завершена:", "Batch replacement complete:");
        add("Troca em lote interrompida:", "Reemplazo por lotes interrumpido:", "Пакетная замена прервана:", "Batch replacement interrupted:");
        add("Convertendo a imagem para a paleta original do MDL…", "Convirtiendo la imagen a la paleta original del MDL…", "Преобразование изображения в исходную палитру MDL…", "Converting image to the original MDL palette…");
        add("Falha:", "Error:", "Ошибка:", "Error:");
        add("Textura de braço definida: ", "Textura de brazo definida: ", "Текстура руки назначена: ", "Arm texture assigned: ");
        add("Textura de luva definida: ", "Textura de guante asignada: ", "Текстура перчатки назначена: ", "Glove texture assigned: ");
    }

    private LanguageManager() { }

    private static void add(String pt, String es, String ru, String en) { DICT.put(pt, new String[]{pt, es, ru, en}); }

    public static String language(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(LANGUAGE_KEY, PT);
    }

    public static void setLanguage(Context context, String code) {
        if (!PT.equals(code) && !ES.equals(code) && !RU.equals(code) && !EN.equals(code)) code = PT;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(LANGUAGE_KEY, code).apply();
    }

    public static String[] nativeLanguageNames() { return new String[]{"Português", "Español", "Русский", "English"}; }
    public static String[] codes() { return new String[]{PT, ES, RU, EN}; }
    public static int indexOf(String code) {
        if (ES.equals(code)) return 1;
        if (RU.equals(code)) return 2;
        if (EN.equals(code)) return 3;
        return 0;
    }

    /** Translate exact labels and known phrases embedded in longer status messages. */
    public static String translate(Context context, String source) {
        if (source == null || source.isEmpty()) return source;
        String code = language(context);
        if (PT.equals(code)) return source;
        int column = ES.equals(code) ? 1 : RU.equals(code) ? 2 : 3;
        List<String> keys = new ArrayList<>(DICT.keySet());
        Collections.sort(keys, Comparator.comparingInt(String::length).reversed());
        String out = source;
        for (String key : keys) {
            String translated = DICT.get(key)[column];
            if (!key.equals(translated) && out.contains(key)) out = out.replace(key, translated);
        }
        return out;
    }

    public static void addHomeSelector(Activity activity, LinearLayout parent, Runnable onChanged) {
        TextView label = new TextView(activity);
        label.setText(translate(activity, "Idioma do aplicativo"));
        label.setTextColor(Color.rgb(164, 169, 188));
        label.setTextSize(12);
        label.setPadding(0, dp(activity, 10), 0, dp(activity, 3));
        parent.addView(label, new LinearLayout.LayoutParams(-1, -2));

        Spinner selector = new Spinner(activity);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(activity, android.R.layout.simple_spinner_item, nativeLanguageNames());
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        selector.setAdapter(adapter);
        selector.setSelection(indexOf(language(activity)), false);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(22, 25, 38));
        bg.setCornerRadius(dp(activity, 8));
        bg.setStroke(dp(activity, 1), Color.rgb(49, 56, 76));
        selector.setBackground(bg);
        parent.addView(selector, new LinearLayout.LayoutParams(-1, dp(activity, 44)));
        selector.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> p, View view, int position, long id) {
                String selected = codes()[position];
                if (!selected.equals(language(activity))) {
                    setLanguage(activity, selected);
                    if (onChanged != null) onChanged.run();
                }
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
    }

    private static int dp(Context context, float value) { return Math.round(value * context.getResources().getDisplayMetrics().density); }
}
