package com.fulldesign.skinstudio.core;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

/** Writes standard, uncompressed Windows BMP files. Input pixel arrays are top-down. */
public final class BmpEncoder {
    private static final int FILE_HEADER_SIZE = 14;
    private static final int INFO_HEADER_SIZE = 40;
    private static final int PALETTE_ENTRIES = 256;

    private BmpEncoder() {}

    /**
     * Encodes 8-bit indexed BMP (BI_RGB) with a full 256-entry RGBQUAD palette.
     * indices[y * width + x] is an unsigned palette index.
     */
    public static byte[] encodeIndexed(int width, int height, byte[] indices, int[] paletteArgb) {
        validateDimensions(width, height);
        if (indices == null || indices.length != checkedPixelCount(width, height)) {
            throw new IllegalArgumentException("Quantidade de índices não corresponde às dimensões.");
        }
        if (paletteArgb == null || paletteArgb.length == 0 || paletteArgb.length > PALETTE_ENTRIES) {
            throw new IllegalArgumentException("A paleta deve conter entre 1 e 256 cores.");
        }

        int rowStride = alignedStride(width, 1);
        int imageBytes = checkedImageBytes(rowStride, height);
        int pixelOffset = FILE_HEADER_SIZE + INFO_HEADER_SIZE + PALETTE_ENTRIES * 4;
        int fileBytes = checkedFileBytes(pixelOffset, imageBytes);
        ByteBuffer out = ByteBuffer.allocate(fileBytes).order(ByteOrder.LITTLE_ENDIAN);
        writeHeaders(out, width, height, 8, imageBytes, pixelOffset, PALETTE_ENTRIES);

        for (int i = 0; i < PALETTE_ENTRIES; i++) {
            int color = i < paletteArgb.length ? paletteArgb[i] : 0xFF000000;
            out.put((byte) (color & 0xFF));
            out.put((byte) ((color >>> 8) & 0xFF));
            out.put((byte) ((color >>> 16) & 0xFF));
            out.put((byte) 0);
        }

        byte[] padding = new byte[rowStride - width];
        for (int y = height - 1; y >= 0; y--) {
            out.put(indices, y * width, width);
            out.put(padding);
        }
        return out.array();
    }

    /** Encodes a 24-bit uncompressed BMP. pixelsArgb is top-down ARGB. */
    public static byte[] encodeRgb24(int width, int height, int[] pixelsArgb) {
        validateDimensions(width, height);
        if (pixelsArgb == null || pixelsArgb.length != checkedPixelCount(width, height)) {
            throw new IllegalArgumentException("Quantidade de pixels não corresponde às dimensões.");
        }
        int rowStride = alignedStride(width, 3);
        int imageBytes = checkedImageBytes(rowStride, height);
        int pixelOffset = FILE_HEADER_SIZE + INFO_HEADER_SIZE;
        int fileBytes = checkedFileBytes(pixelOffset, imageBytes);
        ByteBuffer out = ByteBuffer.allocate(fileBytes).order(ByteOrder.LITTLE_ENDIAN);
        writeHeaders(out, width, height, 24, imageBytes, pixelOffset, 0);
        byte[] padding = new byte[rowStride - width * 3];
        for (int y = height - 1; y >= 0; y--) {
            int start = y * width;
            for (int x = 0; x < width; x++) {
                int color = pixelsArgb[start + x];
                out.put((byte) (color & 0xFF));
                out.put((byte) ((color >>> 8) & 0xFF));
                out.put((byte) ((color >>> 16) & 0xFF));
            }
            out.put(padding);
        }
        return out.array();
    }

    private static void writeHeaders(ByteBuffer out, int width, int height, int bitsPerPixel,
                                     int imageBytes, int pixelOffset, int colorsUsed) {
        out.put((byte) 'B').put((byte) 'M');
        out.putInt(pixelOffset + imageBytes);
        out.putShort((short) 0).putShort((short) 0);
        out.putInt(pixelOffset);
        out.putInt(INFO_HEADER_SIZE);
        out.putInt(width);
        out.putInt(height); // positive height means bottom-up rows
        out.putShort((short) 1);
        out.putShort((short) bitsPerPixel);
        out.putInt(0); // BI_RGB, no compression
        out.putInt(imageBytes);
        out.putInt(2835).putInt(2835); // 72 DPI, expressed as pixels per metre
        out.putInt(colorsUsed);
        out.putInt(0);
    }

    private static void validateDimensions(int width, int height) {
        if (width <= 0 || height <= 0 || width > 16384 || height > 16384) {
            throw new IllegalArgumentException("Dimensões BMP inválidas ou excessivas.");
        }
    }

    private static int checkedPixelCount(int width, int height) {
        long count = (long) width * height;
        if (count > Integer.MAX_VALUE) throw new IllegalArgumentException("Imagem grande demais.");
        return (int) count;
    }

    private static int alignedStride(int width, int bytesPerPixel) {
        long raw = (long) width * bytesPerPixel;
        long stride = (raw + 3L) & ~3L;
        if (stride > Integer.MAX_VALUE) throw new IllegalArgumentException("Linha BMP grande demais.");
        return (int) stride;
    }

    private static int checkedImageBytes(int stride, int height) {
        long bytes = (long) stride * height;
        if (bytes > Integer.MAX_VALUE) throw new IllegalArgumentException("Arquivo BMP grande demais.");
        return (int) bytes;
    }

    private static int checkedFileBytes(int pixelOffset, int imageBytes) {
        long bytes = (long) pixelOffset + imageBytes;
        if (bytes > Integer.MAX_VALUE) throw new IllegalArgumentException("Arquivo BMP grande demais.");
        return (int) bytes;
    }
}
