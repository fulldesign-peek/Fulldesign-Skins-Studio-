package com.fulldesign.skinstudio;

import android.content.Context;
import android.graphics.Bitmap;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.opengl.Matrix;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;

import com.fulldesign.skinstudio.core.GoldSrcMdl;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** OpenGL ES 2 viewer for real GoldSrc MDL triangle strips/fans in the parsed default pose. */
public final class MdlGlViewer extends GLSurfaceView {
    private final ViewerRenderer renderer;
    private final ScaleGestureDetector scaleDetector;
    private float lastX, lastY;
    private boolean dragging;

    public MdlGlViewer(Context context) {
        super(context);
        setEGLContextClientVersion(2);
        setPreserveEGLContextOnPause(true);
        renderer = new ViewerRenderer();
        setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector detector) {
                renderer.zoom = clamp(renderer.zoom / detector.getScaleFactor(), .55f, 3.5f);
                requestRender();
                return true;
            }
        });
    }

    public void setModel(GoldSrcMdl.ModelPreview model, Map<Integer, Bitmap> textures) {
        renderer.setModel(model, textures);
        requestRender();
    }

    public void setOrigin(float x, float y, float z) {
        renderer.originX = x; renderer.originY = y; renderer.originZ = z;
        requestRender();
    }

    public void resetView() { renderer.yaw = 18f; renderer.pitch = -6f; renderer.zoom = 1.0f; requestRender(); }

    @Override public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
            lastX = event.getX(); lastY = event.getY(); dragging = true; return true;
        }
        if (action == MotionEvent.ACTION_POINTER_DOWN) { dragging = false; return true; }
        if (action == MotionEvent.ACTION_MOVE && event.getPointerCount() == 1 && dragging && !scaleDetector.isInProgress()) {
            float dx = event.getX() - lastX, dy = event.getY() - lastY;
            renderer.yaw += dx * .55f;
            renderer.pitch = clamp(renderer.pitch + dy * .45f, -85f, 85f);
            lastX = event.getX(); lastY = event.getY(); requestRender(); return true;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            dragging = false;
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
            return true;
        }
        return true;
    }

    private static float clamp(float x, float min, float max) { return Math.max(min, Math.min(max, x)); }

    private static final class GpuPart {
        final int textureIndex, vertexCount;
        final FloatBuffer vertices, uvs;
        GpuPart(GoldSrcMdl.MeshPart part) {
            textureIndex = part.textureIndex; vertexCount = part.positions.length / 3;
            vertices = floats(part.positions); uvs = floats(part.texCoords);
        }
        private static FloatBuffer floats(float[] values) {
            FloatBuffer b = ByteBuffer.allocateDirect(values.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
            b.put(values).position(0); return b;
        }
    }

    private static final class ViewerRenderer implements Renderer {
        private static final String VERTEX_SHADER =
                "attribute vec3 aPosition; attribute vec2 aTexCoord; uniform mat4 uMvp; varying vec2 vTexCoord;" +
                "void main(){ gl_Position=uMvp*vec4(aPosition,1.0); vTexCoord=aTexCoord; }";
        private static final String FRAGMENT_SHADER =
                "precision mediump float; uniform sampler2D uTexture; varying vec2 vTexCoord;" +
                "void main(){ gl_FragColor=texture2D(uTexture,vTexCoord); }";
        private volatile GoldSrcMdl.ModelPreview pendingModel;
        private volatile Map<Integer, Bitmap> pendingTextures = new HashMap<>();
        private volatile long pendingRevision;
        private long loadedRevision = -1;
        private int program, aPosition, aTexCoord, uMvp, uTexture;
        private final float[] projection = new float[16], view = new float[16], modelMatrix = new float[16], mvp = new float[16];
        private List<GpuPart> parts;
        private final Map<Integer, Integer> glTextures = new HashMap<>();
        private GoldSrcMdl.ModelPreview model;
        volatile float yaw = 18f, pitch = -6f, zoom = 1.0f, fov = 45f;
        volatile float originX, originY, originZ;
        private int width = 1, height = 1;

        synchronized void setModel(GoldSrcMdl.ModelPreview model, Map<Integer, Bitmap> textures) {
            this.pendingModel = model;
            this.pendingTextures = new HashMap<>(textures);
            pendingRevision++;
        }

        @Override public void onSurfaceCreated(javax.microedition.khronos.opengles.GL10 gl, javax.microedition.khronos.egl.EGLConfig config) {
            GLES20.glClearColor(.035f, .045f, .075f, 1f);
            GLES20.glEnable(GLES20.GL_DEPTH_TEST);
            GLES20.glEnable(GLES20.GL_BLEND);
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
            program = createProgram(VERTEX_SHADER, FRAGMENT_SHADER);
            aPosition = GLES20.glGetAttribLocation(program, "aPosition");
            aTexCoord = GLES20.glGetAttribLocation(program, "aTexCoord");
            uMvp = GLES20.glGetUniformLocation(program, "uMvp");
            uTexture = GLES20.glGetUniformLocation(program, "uTexture");
            loadedRevision = -1;
        }

        @Override public void onSurfaceChanged(javax.microedition.khronos.opengles.GL10 gl, int w, int h) {
            width = Math.max(1, w); height = Math.max(1, h); GLES20.glViewport(0, 0, width, height);
            Matrix.perspectiveM(projection, 0, fov, (float) width / height, .05f, 100f);
        }

        @Override public void onDrawFrame(javax.microedition.khronos.opengles.GL10 gl) {
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
            if (loadedRevision != pendingRevision) uploadModel();
            if (model == null || parts == null || parts.isEmpty() || program == 0) return;
            Matrix.perspectiveM(projection, 0, fov, (float) width / height, .05f, 100f);
            Matrix.setIdentityM(view, 0);
            Matrix.translateM(view, 0, 0f, 0f, -3.4f * zoom);
            Matrix.setIdentityM(modelMatrix, 0);
            float scale = 1.65f / Math.max(.0001f, model.maxExtent);
            Matrix.scaleM(modelMatrix, 0, scale, scale, scale);
            Matrix.rotateM(modelMatrix, 0, -90f, 1f, 0f, 0f); // GoldSrc models use Z-up; viewer uses Y-up.
            Matrix.rotateM(modelMatrix, 0, yaw, 0f, 1f, 0f);
            Matrix.rotateM(modelMatrix, 0, pitch, 1f, 0f, 0f);
            Matrix.translateM(modelMatrix, 0,
                    -model.centerX + originX, -model.centerY + originY, -model.centerZ + originZ);
            float[] pv = new float[16]; Matrix.multiplyMM(pv, 0, projection, 0, view, 0);
            Matrix.multiplyMM(mvp, 0, pv, 0, modelMatrix, 0);
            GLES20.glUseProgram(program);
            GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0);
            GLES20.glUniform1i(uTexture, 0);
            for (GpuPart part : parts) {
                Integer texture = glTextures.get(part.textureIndex);
                if (texture == null) texture = glTextures.get(-1);
                if (texture == null) continue;
                GLES20.glActiveTexture(GLES20.GL_TEXTURE0); GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture);
                part.vertices.position(0); GLES20.glEnableVertexAttribArray(aPosition);
                GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, 0, part.vertices);
                part.uvs.position(0); GLES20.glEnableVertexAttribArray(aTexCoord);
                GLES20.glVertexAttribPointer(aTexCoord, 2, GLES20.GL_FLOAT, false, 0, part.uvs);
                GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, part.vertexCount);
            }
            GLES20.glDisableVertexAttribArray(aPosition); GLES20.glDisableVertexAttribArray(aTexCoord);
        }

        private void uploadModel() {
            loadedRevision = pendingRevision;
            model = pendingModel;
            for (int id : glTextures.values()) { int[] one = {id}; GLES20.glDeleteTextures(1, one, 0); }
            glTextures.clear();
            if (model == null) { parts = null; return; }
            parts = new java.util.ArrayList<>();
            for (GoldSrcMdl.MeshPart p : model.parts) parts.add(new GpuPart(p));
            Map<Integer, Bitmap> images = pendingTextures;
            for (Map.Entry<Integer, Bitmap> entry : images.entrySet()) {
                int[] ids = new int[1]; GLES20.glGenTextures(1, ids, 0); int id = ids[0];
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, entry.getValue(), 0);
                glTextures.put(entry.getKey(), id);
            }
            if (!glTextures.containsKey(-1)) {
                Bitmap white = Bitmap.createBitmap(new int[]{0xFFFFFFFF}, 1, 1, Bitmap.Config.ARGB_8888);
                int[] ids = new int[1]; GLES20.glGenTextures(1, ids, 0); GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0]);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST);
                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, white, 0); white.recycle(); glTextures.put(-1, ids[0]);
            }
        }

        private int createProgram(String vs, String fs) {
            int vertex = compileShader(GLES20.GL_VERTEX_SHADER, vs), fragment = compileShader(GLES20.GL_FRAGMENT_SHADER, fs);
            int p = GLES20.glCreateProgram(); GLES20.glAttachShader(p, vertex); GLES20.glAttachShader(p, fragment); GLES20.glLinkProgram(p);
            int[] ok = new int[1]; GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0);
            GLES20.glDeleteShader(vertex); GLES20.glDeleteShader(fragment);
            if (ok[0] == 0) { String log = GLES20.glGetProgramInfoLog(p); GLES20.glDeleteProgram(p); throw new RuntimeException("Falha ao ligar shader do visualizador: " + log); }
            return p;
        }
        private int compileShader(int type, String source) {
            int shader = GLES20.glCreateShader(type); GLES20.glShaderSource(shader, source); GLES20.glCompileShader(shader);
            int[] ok = new int[1]; GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, ok, 0);
            if (ok[0] == 0) { String log = GLES20.glGetShaderInfoLog(shader); GLES20.glDeleteShader(shader); throw new RuntimeException("Falha ao compilar shader: " + log); }
            return shader;
        }
    }
}
