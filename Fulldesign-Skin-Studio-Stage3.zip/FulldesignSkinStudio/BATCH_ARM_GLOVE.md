# Aplicação em lote de braço e luva

## Preparar as texturas de origem

1. Importe o ZIP que contém suas skins.
2. Abra um modelo MDL que tenha uma textura de braço ou mãos.
3. Selecione a textura desejada e escolha **Usar textura selecionada como braço**.
4. Abra um MDL que tenha a textura de luva, selecione-a e escolha **Usar textura selecionada como luva**.
5. Volte ao cartão **Conteúdo do pack** e pressione **Aplicar textura de braço/luva em lote**.
6. Confirme e veja o resumo do resultado; depois exporte o ZIP.

## Comportamento seguro

- O app só substitui texturas embutidas em MDLs com slots cujo nome indica braço, mão, manga ou luva. Modelos sem correspondência são ignorados em vez de sobrescritos às cegas.
- A paleta original de cada modelo de destino é preservada; a imagem é redimensionada para as dimensões daquele slot e quantizada para a paleta existente.
- O ZIP original selecionado no Android não é sobrescrito; alterações ficam na pasta temporária e só saem ao exportar.
- O recurso muda pixels de textura. Não substitui a malha 3D, os ossos, as animações ou os bodygroups do braço. Se um modelo combina arma e mãos numa única textura ou usa nomes genéricos, precisa de mapeamento específico antes de ser compatível.
- A textura de origem é limitada a 4 megapixels nesta operação para reduzir o risco de falta de memória em celulares.
