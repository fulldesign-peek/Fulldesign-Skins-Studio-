#!/usr/bin/env bash
set -euo pipefail

if ! command -v gradle >/dev/null 2>&1; then
  echo "Erro: Gradle não encontrado. Instale Gradle 8.13 ou abra o projeto no Android Studio." >&2
  exit 2
fi
if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "Aviso: ANDROID_HOME/ANDROID_SDK_ROOT não definido. Confira o SDK no Android Studio." >&2
fi
gradle testDebugUnitTest
exec gradle assembleDebug
