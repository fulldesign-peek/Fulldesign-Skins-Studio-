package com.fulldesign.skinstudio;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.fulldesign.skinstudio.core.BmpEncoder;
import com.fulldesign.skinstudio.core.ImageProcessor;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** First functional Android milestone: image import, real adjustments, BMP conversion and export. */
public class MainActivity extends Activity {
    private static final int REQUEST_IMPORT_IMAGE = 1001;
    private static final int REQUEST_CREATE_BMP = 1002;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private Bitmap originalBitmap;
    private Bitmap workingBitmap;
    private String sourceName = "skin";
    private byte[] pendingExport;
    private String pendingExportName = "skin_8bit.bmp";

    private ImageView originalPreview;
    private ImageView preview;
    private TextView status;
    private TextView imageInfo;
    private Button applyButton;
    private Button exportButton;
    private SeekBar brightnessBar, contrastBar, saturationBar, hueBar, sharpnessBar;
    private TextView brightnessValue, contrastValue, saturationValue, hueValue, sharpnessValue;
    private Spinner sizeSpinner, formatSpinner;
    private CheckBox ditheringCheck, transparentMaskCheck, blueMaskCheck;
    private EditText filenameInput;
    private ImageView brandLogo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8, 9, 17));
        getWindow().setNavigationBarColor(Color.rgb(8, 9, 17));
        setContentView(buildInterface());
        updateImageInfo();
    }

    private View buildInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(10, 11, 18));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(16), dp(18), dp(28));
        scroll.addView(page, new ScrollView.LayoutParams(-1, -2));

        // Large official FULLDESIGN artwork. Its opacity follows the scroll position.
        brandLogo = new ImageView(this);
        brandLogo.setImageResource(com.fulldesign.skinstudio.R.drawable.fulldesign_skin_studio_logo);
        brandLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        brandLogo.setAdjustViewBounds(true);
        brandLogo.setContentDescription("FULLDESIGN Skin Studio");
        brandLogo.setAlpha(1f);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(-1, dp(250));
        logoParams.bottomMargin = dp(8);
        page.addView(brandLogo, logoParams);
        LanguageManager.addHomeSelector(this, page, this::refreshForLanguage);
        TextView title = text("Skin Studio", 28, Color.WHITE, true);
        title.setPadding(0, dp(1), 0, dp(2));
        page.addView(title);
        TextView intro = text("ETAPA 1 · EDITOR E CONVERSOR DE TEXTURAS", 11, Color.rgb(164, 169, 188), true);
        intro.setLetterSpacing(0.035f);
        page.addView(intro);

        scroll.setOnScrollChangeListener((View v, int scrollX, int scrollY, int oldX, int oldY) -> {
            if (brandLogo != null) {
                float fadeDistance = Math.max(dp(160), brandLogo.getHeight());
                float alpha = 1f - Math.min(1f, Math.max(0f, scrollY / fadeDistance));
                brandLogo.setAlpha(alpha);
            }
        });

        Button modelToolsButton = button("Abrir Pack Mixer / Editor MDL", false);
        modelToolsButton.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, ModelPackActivity.class)));
        page.addView(modelToolsButton, topMargin(-1, dp(46), 14));

        Button importButton = button("Importar imagem (PNG, JPG, BMP)", true);
        importButton.setOnClickListener(v -> chooseImage());
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, dp(50));
        buttonParams.topMargin = dp(18);
        page.addView(importButton, buttonParams);

        LinearLayout previewPanel = panel();
        TextView previewTitle = text("PRÉ-VISUALIZAÇÃO", 12, Color.rgb(135, 200, 255), true);
        previewPanel.addView(previewTitle);
        LinearLayout previewRow = new LinearLayout(this);
        previewRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView originalLabel = text("ORIGINAL", 10, Color.rgb(166, 172, 190), true);
        TextView currentLabel = text("ATUAL / CONVERTIDA", 10, Color.rgb(83, 192, 255), true);
        LinearLayout originalColumn = new LinearLayout(this);
        originalColumn.setOrientation(LinearLayout.VERTICAL);
        originalColumn.addView(originalLabel, topMargin(-1, -2, 0));
        originalPreview = new ImageView(this);
        originalPreview.setAdjustViewBounds(true);
        originalPreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        originalPreview.setBackground(roundRect(Color.rgb(6, 7, 11), 8, Color.rgb(42, 47, 65), 1));
        originalColumn.addView(originalPreview, new LinearLayout.LayoutParams(-1, dp(190)));
        LinearLayout currentColumn = new LinearLayout(this);
        currentColumn.setOrientation(LinearLayout.VERTICAL);
        currentColumn.addView(currentLabel, topMargin(-1, -2, 0));
        preview = new ImageView(this);
        preview.setAdjustViewBounds(true);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setBackground(roundRect(Color.rgb(6, 7, 11), 8, Color.rgb(42, 47, 65), 1));
        currentColumn.addView(preview, new LinearLayout.LayoutParams(-1, dp(190)));
        LinearLayout.LayoutParams leftParams = new LinearLayout.LayoutParams(0, -2, 1f);
        leftParams.rightMargin = dp(6);
        LinearLayout.LayoutParams rightParams = new LinearLayout.LayoutParams(0, -2, 1f);
        rightParams.leftMargin = dp(6);
        previewRow.addView(originalColumn, leftParams);
        previewRow.addView(currentColumn, rightParams);
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(-1, -2);
        imageParams.topMargin = dp(10);
        previewPanel.addView(previewRow, imageParams);
        imageInfo = text("Nenhuma imagem importada", 12, Color.rgb(166, 172, 190), false);
        imageInfo.setPadding(0, dp(9), 0, 0);
        previewPanel.addView(imageInfo);
        page.addView(previewPanel, topMargin(-1, -2, 14));

        LinearLayout editPanel = panel();
        editPanel.addView(sectionTitle("Editor de imagem"));
        editPanel.addView(text("Os ajustes são aplicados em uma cópia da imagem original.", 12, Color.rgb(166, 172, 190), false), topMargin(-1, -2, 8));
        SliderControl brightness = addSlider(editPanel, "Brilho", -100, 100, 0);
        brightnessBar = brightness.seekBar; brightnessValue = brightness.value;
        SliderControl contrast = addSlider(editPanel, "Contraste", -100, 100, 0);
        contrastBar = contrast.seekBar; contrastValue = contrast.value;
        SliderControl saturation = addSlider(editPanel, "Saturação", -100, 100, 0);
        saturationBar = saturation.seekBar; saturationValue = saturation.value;
        SliderControl hue = addSlider(editPanel, "Matiz", -180, 180, 0);
        hueBar = hue.seekBar; hueValue = hue.value;
        SliderControl sharpness = addSlider(editPanel, "Nitidez", 0, 100, 0);
        sharpnessBar = sharpness.seekBar; sharpnessValue = sharpness.value;
        applyButton = button("Aplicar ajustes", true);
        applyButton.setOnClickListener(v -> applyAdjustments());
        editPanel.addView(applyButton, topMargin(-1, dp(46), 12));
        Button resetButton = button("Descartar ajustes", false);
        resetButton.setOnClickListener(v -> resetAdjustments());
        editPanel.addView(resetButton, topMargin(-1, dp(44), 8));
        page.addView(editPanel, topMargin(-1, -2, 14));

        LinearLayout convertPanel = panel();
        convertPanel.addView(sectionTitle("Conversor BMP"));
        convertPanel.addView(text("Escolha a profundidade de cor e a resolução de saída.", 12, Color.rgb(166, 172, 190), false), topMargin(-1, -2, 10));
        convertPanel.addView(text("Formato de destino", 13, Color.WHITE, true));
        formatSpinner = spinner(new String[]{"BMP indexado · 8 bits · até 256 cores", "BMP RGB · 24 bits · sem paleta"});
        convertPanel.addView(formatSpinner, topMargin(-1, dp(48), 5));
        convertPanel.addView(text("Resolução", 13, Color.WHITE, true), topMargin(-1, -2, 12));
        sizeSpinner = spinner(new String[]{"Manter dimensões", "64 × 64", "128 × 128", "256 × 256", "512 × 512", "1024 × 1024"});
        convertPanel.addView(sizeSpinner, topMargin(-1, dp(48), 5));
        ditheringCheck = checkbox("Usar dithering Floyd–Steinberg", true);
        convertPanel.addView(ditheringCheck, topMargin(-1, -2, 10));
        transparentMaskCheck = checkbox("Pixels transparentes → índice 255 (azul)", false);
        convertPanel.addView(transparentMaskCheck, topMargin(-1, -2, 4));
        blueMaskCheck = checkbox("Azul puro RGB(0,0,255) → índice 255", false);
        convertPanel.addView(blueMaskCheck, topMargin(-1, -2, 8));
        convertPanel.addView(text("A máscara é opcional. O app não transforma azul em transparência sem sua autorização.", 11, Color.rgb(167, 173, 190), false));
        filenameInput = new EditText(this);
        filenameInput.setSingleLine(true);
        filenameInput.setTextColor(Color.WHITE);
        filenameInput.setHintTextColor(Color.rgb(120, 126, 145));
        filenameInput.setHint("Nome do arquivo (ex.: ak47_skin)");
        filenameInput.setTextSize(14);
        filenameInput.setPadding(dp(12), 0, dp(12), 0);
        filenameInput.setBackground(roundRect(Color.rgb(17, 20, 31), 8, Color.rgb(49, 56, 76), 1));
        convertPanel.addView(filenameInput, topMargin(-1, dp(48), 14));
        exportButton = button("Converter e exportar BMP", true);
        exportButton.setOnClickListener(v -> convertAndExport());
        convertPanel.addView(exportButton, topMargin(-1, dp(50), 10));
        page.addView(convertPanel, topMargin(-1, -2, 14));

        LinearLayout statusPanel = panel();
        statusPanel.addView(sectionTitle("Status e validação"));
        status = text("Importe uma imagem para começar.", 13, Color.rgb(214, 218, 232), false);
        status.setLineSpacing(dp(3), 1f);
        statusPanel.addView(status, topMargin(-1, -2, 4));
        page.addView(statusPanel, topMargin(-1, -2, 6));

        TextView footer = text("Funciona offline · Arquivos originais não são sobrescritos", 11, Color.rgb(120, 126, 145), false);
        footer.setGravity(Gravity.CENTER);
        page.addView(footer, topMargin(-1, -2, 14));
        return scroll;
    }

    private LinearLayout panel() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(14), dp(14), dp(14), dp(14));
        layout.setBackground(roundRect(Color.rgb(17, 19, 29), 14, Color.rgb(38, 43, 60), 1));
        return layout;
    }

    private TextView sectionTitle(String title) {
        TextView view = text(title, 18, Color.WHITE, true);
        view.setPadding(0, 0, 0, dp(3));
        return view;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(LanguageManager.translate(this, value));
        view.setTextSize(sp);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private Button button(String label, boolean primary) {
        Button button = new Button(this);
        button.setText(LanguageManager.translate(this, label));
        button.setAllCaps(false);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setTextColor(Color.WHITE);
        button.setBackground(roundRect(primary ? Color.rgb(31, 91, 155) : Color.rgb(31, 34, 48), 9,
                primary ? Color.rgb(63, 169, 255) : Color.rgb(55, 61, 82), 1));
        button.setSoundEffectsEnabled(true);
        button.setOnTouchListener((view, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(75).start();
                view.playSoundEffect(SoundEffectConstants.CLICK);
            } else if (event.getAction() == MotionEvent.ACTION_UP ||
                    event.getAction() == MotionEvent.ACTION_CANCEL) {
                view.animate().scaleX(1f).scaleY(1f).setDuration(110).start();
            }
            return false; // preserve the button's existing click listener
        });
        return button;
    }

    private CheckBox checkbox(String label, boolean checked) {
        CheckBox check = new CheckBox(this);
        check.setText(LanguageManager.translate(this, label));
        check.setTextSize(13);
        check.setTextColor(Color.rgb(222, 225, 238));
        check.setButtonTintList(android.content.res.ColorStateList.valueOf(Color.rgb(65, 177, 255)));
        check.setChecked(checked);
        return check;
    }

    private Spinner spinner(String[] values) {
        Spinner spinner = new Spinner(this);
        String[] translatedValues = new String[values.length];
        for (int i = 0; i < values.length; i++) translatedValues[i] = LanguageManager.translate(this, values[i]);
        android.widget.ArrayAdapter<String> adapter = new android.widget.ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, translatedValues);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setBackground(roundRect(Color.rgb(22, 25, 38), 8, Color.rgb(49, 56, 76), 1));
        return spinner;
    }

    private static final class SliderControl {
        SeekBar seekBar;
        TextView value;
    }

    private SliderControl addSlider(LinearLayout parent, String label, int min, int max, int initial) {
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(0, dp(2), 0, dp(4));
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text(label, 13, Color.rgb(222, 225, 238), false);
        row.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView value = text(Integer.toString(initial), 12, Color.rgb(79, 190, 255), true);
        value.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        row.addView(value, new LinearLayout.LayoutParams(dp(56), -2));
        container.addView(row);
        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(initial - min);
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(48, 166, 255)));
        bar.setThumbTintList(android.content.res.ColorStateList.valueOf(Color.rgb(110, 210, 255)));
        bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(56, 61, 79)));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                value.setText(Integer.toString(progress + min));
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        container.addView(bar);
        parent.addView(container, topMargin(-1, -2, 2));
        SliderControl control = new SliderControl();
        control.seekBar = bar; control.value = value;
        return control;
    }

    private LinearLayout.LayoutParams topMargin(int width, int height, int marginDp) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, height);
        params.topMargin = dp(marginDp);
        return params;
    }

    private GradientDrawable roundRect(int fill, int radiusDp, int stroke, int strokeDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), stroke);
        return drawable;
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void chooseImage() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, REQUEST_IMPORT_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == REQUEST_IMPORT_IMAGE) {
            Uri uri = data.getData();
            if (uri != null) importImage(uri);
        } else if (requestCode == REQUEST_CREATE_BMP) {
            Uri uri = data.getData();
            if (uri != null && pendingExport != null) writeExport(uri);
        }
    }

    private void importImage(Uri uri) {
        setBusy(true, "Lendo e validando a imagem…");
        worker.execute(() -> {
            try {
                Bitmap decoded = ImageProcessor.decode(this, uri);
                String name = getDisplayName(uri);
                runOnUiThread(() -> {
                    originalBitmap = decoded;
                    workingBitmap = decoded;
                    sourceName = stripExtension(name == null ? "skin" : name);
                    originalPreview.setImageBitmap(originalBitmap);
                    preview.setImageBitmap(workingBitmap);
                    filenameInput.setText(sourceName);
                    updateImageInfo();
                    setBusy(false, "Imagem importada. Ajuste a imagem ou converta para BMP.");
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    setBusy(false, "Falha na importação: " + safeMessage(e));
                });
            }
        });
    }

    private String getDisplayName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) {}
        return "skin";
    }

    private String stripExtension(String value) {
        int dot = value.lastIndexOf('.');
        String result = dot > 0 ? value.substring(0, dot) : value;
        result = result.replaceAll("[^A-Za-z0-9._-]", "_");
        return result.isEmpty() ? "skin" : result;
    }

    private void applyAdjustments() {
        if (originalBitmap == null) { showStatus("Importe uma imagem antes de aplicar os ajustes."); return; }
        setBusy(true, "Aplicando ajustes à cópia…");
        final Bitmap source = originalBitmap;
        final int brightness = brightnessBar.getProgress() - 100;
        final int contrast = contrastBar.getProgress() - 100;
        final int saturation = saturationBar.getProgress() - 100;
        final int hue = hueBar.getProgress() - 180;
        final int sharpness = sharpnessBar.getProgress();
        worker.execute(() -> {
            try {
                Bitmap edited = ImageProcessor.adjust(source, brightness, contrast, saturation, hue, sharpness);
                runOnUiThread(() -> {
                    workingBitmap = edited;
                    preview.setImageBitmap(edited);
                    updateImageInfo();
                    setBusy(false, "Ajustes aplicados. A imagem original foi mantida intacta.");
                });
            } catch (Exception e) {
                runOnUiThread(() -> setBusy(false, "Não foi possível aplicar os ajustes: " + safeMessage(e)));
            }
        });
    }

    private void resetAdjustments() {
        if (originalBitmap == null) { showStatus("Nenhuma imagem carregada."); return; }
        brightnessBar.setProgress(100); contrastBar.setProgress(100); saturationBar.setProgress(100);
        hueBar.setProgress(180); sharpnessBar.setProgress(0);
        workingBitmap = originalBitmap;
        originalPreview.setImageBitmap(originalBitmap);
        preview.setImageBitmap(workingBitmap);
        updateImageInfo();
        showStatus("Ajustes descartados. Exibindo a imagem original.");
    }

    private void convertAndExport() {
        if (workingBitmap == null) { showStatus("Importe uma imagem antes de converter."); return; }
        final Bitmap source = workingBitmap;
        final boolean indexed = formatSpinner.getSelectedItemPosition() == 0;
        final boolean dithering = ditheringCheck.isChecked();
        final boolean alphaMask = transparentMaskCheck.isChecked();
        final boolean blueMask = blueMaskCheck.isChecked();
        final int size = selectedSize();
        String typedName = filenameInput.getText().toString().trim();
        if (typedName.isEmpty()) typedName = sourceName;
        typedName = stripExtension(typedName);
        pendingExportName = typedName + (indexed ? "_8bit.bmp" : "_24bit.bmp");
        final String safeName = pendingExportName;
        setBusy(true, "Validando dimensões e convertendo a textura…");
        worker.execute(() -> {
            try {
                Bitmap output = size > 0 ? ImageProcessor.resize(source, size, size) : source;
                byte[] bytes;
                String details;
                final Bitmap convertedPreview;
                if (indexed) {
                    ImageProcessor.QuantizedImage quantized = ImageProcessor.quantize(output, dithering, alphaMask, blueMask);
                    bytes = BmpEncoder.encodeIndexed(quantized.width, quantized.height, quantized.indices, quantized.paletteArgb);
                    convertedPreview = ImageProcessor.reconstruct(quantized);
                    details = "BMP indexado de 8 bits válido; 256 posições de paleta; dithering " + (dithering ? "ativado" : "desativado")
                            + (quantized.hasReservedMask ? "; índice 255 reservado para máscara azul" : "") + ".";
                } else {
                    int[] pixels = new int[output.getWidth() * output.getHeight()];
                    output.getPixels(pixels, 0, output.getWidth(), 0, 0, output.getWidth(), output.getHeight());
                    bytes = BmpEncoder.encodeRgb24(output.getWidth(), output.getHeight(), pixels);
                    convertedPreview = ImageProcessor.rgb24Preview(output);
                    details = "BMP RGB de 24 bits válido; sem paleta indexada.";
                    if (alphaMask || blueMask) details += " As opções de máscara só se aplicam ao modo indexado de 8 bits.";
                }
                final byte[] result = bytes;
                final String report = details + " Dimensões: " + output.getWidth() + " × " + output.getHeight() + ". Arquivo: " + humanBytes(result.length) + ".";
                runOnUiThread(() -> {
                    pendingExport = result;
                    preview.setImageBitmap(convertedPreview);
                    setBusy(false, "Conversão concluída. " + report + " A prévia ao lado mostra o resultado convertido. Escolha onde salvar o BMP.");
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/octet-stream");
                    intent.putExtra(Intent.EXTRA_TITLE, safeName);
                    startActivityForResult(intent, REQUEST_CREATE_BMP);
                });
            } catch (Exception e) {
                runOnUiThread(() -> setBusy(false, "Falha na conversão: " + safeMessage(e)));
            }
        });
    }

    private int selectedSize() {
        switch (sizeSpinner.getSelectedItemPosition()) {
            case 1: return 64;
            case 2: return 128;
            case 3: return 256;
            case 4: return 512;
            case 5: return 1024;
            default: return 0;
        }
    }

    private void writeExport(Uri uri) {
        byte[] bytes = pendingExport;
        if (bytes == null) { showStatus("Não há arquivo convertido para salvar."); return; }
        setBusy(true, "Salvando o arquivo…");
        worker.execute(() -> {
            try (OutputStream output = getContentResolver().openOutputStream(uri, "w")) {
                if (output == null) throw new IOException("O Android não abriu o destino escolhido.");
                output.write(bytes);
                output.flush();
                runOnUiThread(() -> {
                    pendingExport = null;
                    setBusy(false, "Arquivo salvo com sucesso: " + pendingExportName + ". " + humanBytes(bytes.length) + ".");
                });
            } catch (Exception e) {
                runOnUiThread(() -> setBusy(false, "Falha ao salvar o arquivo: " + safeMessage(e)));
            }
        });
    }

    private void updateImageInfo() {
        if (workingBitmap == null) {
            imageInfo.setText(LanguageManager.translate(this, "Nenhuma imagem importada"));
            return;
        }
        long pixels = (long) workingBitmap.getWidth() * workingBitmap.getHeight();
        imageInfo.setText(String.format(Locale.ROOT, "%s · %d × %d · %.2f MP", sourceName,
                workingBitmap.getWidth(), workingBitmap.getHeight(), pixels / 1_000_000.0));
    }

    private void setBusy(boolean busy, String message) {
        if (status != null) showStatus(message);
        if (applyButton != null) applyButton.setEnabled(!busy);
        if (exportButton != null) exportButton.setEnabled(!busy);
    }

    private void showStatus(String message) {
        if (status != null) status.setText(LanguageManager.translate(this, message));
    }

    private void refreshForLanguage() {
        int b = brightnessBar == null ? 100 : brightnessBar.getProgress();
        int c = contrastBar == null ? 100 : contrastBar.getProgress();
        int sat = saturationBar == null ? 100 : saturationBar.getProgress();
        int h = hueBar == null ? 180 : hueBar.getProgress();
        int sharp = sharpnessBar == null ? 0 : sharpnessBar.getProgress();
        String oldFilename = filenameInput == null ? "" : filenameInput.getText().toString();
        int oldFormat = formatSpinner == null ? 0 : formatSpinner.getSelectedItemPosition();
        int oldSize = sizeSpinner == null ? 0 : sizeSpinner.getSelectedItemPosition();
        boolean oldDither = ditheringCheck != null && ditheringCheck.isChecked();
        boolean oldTransparent = transparentMaskCheck != null && transparentMaskCheck.isChecked();
        boolean oldBlueMask = blueMaskCheck != null && blueMaskCheck.isChecked();
        setContentView(buildInterface());
        if (originalBitmap != null) originalPreview.setImageBitmap(originalBitmap);
        if (workingBitmap != null) preview.setImageBitmap(workingBitmap);
        if (brightnessBar != null) brightnessBar.setProgress(b);
        if (contrastBar != null) contrastBar.setProgress(c);
        if (saturationBar != null) saturationBar.setProgress(sat);
        if (hueBar != null) hueBar.setProgress(h);
        if (sharpnessBar != null) sharpnessBar.setProgress(sharp);
        if (filenameInput != null) filenameInput.setText(oldFilename.isEmpty() ? sourceName : oldFilename);
        if (formatSpinner != null) formatSpinner.setSelection(oldFormat);
        if (sizeSpinner != null) sizeSpinner.setSelection(oldSize);
        if (ditheringCheck != null) ditheringCheck.setChecked(oldDither);
        if (transparentMaskCheck != null) transparentMaskCheck.setChecked(oldTransparent);
        if (blueMaskCheck != null) blueMaskCheck.setChecked(oldBlueMask);
        updateImageInfo();
        showStatus("Idioma alterado. As imagens e ajustes atuais foram preservados.");
    }

    private String safeMessage(Exception e) {
        String message = e.getMessage();
        return message == null || message.trim().isEmpty() ? e.getClass().getSimpleName() : message;
    }

    private String humanBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(Locale.ROOT, "%.1f KB", bytes / 1024.0);
        return String.format(Locale.ROOT, "%.2f MB", bytes / (1024.0 * 1024.0));
    }

    @Override
    protected void onDestroy() {
        worker.shutdown();
        super.onDestroy();
    }
}
