package com.fulldesign.skinstudio;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Tela redesenhada do Fulldesign Skin Studio.
 * Esta Activity e independente: pode ser adicionada sem sobrescrever MainActivity.
 * A area central permite desenhar/rascunhar e importar/exportar uma imagem PNG.
 */
public class SkinStudioRedesignActivity extends Activity {
    private static final int REQUEST_IMPORT_IMAGE = 301;
    private static final int REQUEST_EXPORT_IMAGE = 302;
    private static final int BLUE = Color.rgb(0, 103, 255);
    private static final int BG = Color.rgb(7, 11, 19);
    private static final int SURFACE = Color.rgb(17, 23, 34);
    private static final int SURFACE_2 = Color.rgb(23, 31, 45);
    private static final int TEXT = Color.rgb(245, 247, 252);
    private static final int MUTED = Color.rgb(163, 174, 193);

    private PaintCanvasView paintCanvas;
    private TextView brushSizeLabel;
    private TextView toolStatus;
    private int selectedColor = BLUE;
    private float brushSize = 12f;
    private String currentTool = "Pincel";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(5, 8, 14));
        getWindow().setNavigationBarColor(Color.rgb(5, 8, 14));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);

        ImageView wallpaper = new ImageView(this);
        try (InputStream stream = getAssets().open("skin_studio_wallpaper.png")) {
            wallpaper.setImageBitmap(BitmapFactory.decodeStream(stream));
        } catch (Exception ignored) {
            wallpaper.setBackgroundColor(BG);
        }
        wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        wallpaper.setAlpha(0.78f);
        root.addView(wallpaper, new FrameLayout.LayoutParams(-1, -1));
        View tint = new View(this);
        tint.setBackgroundColor(Color.argb(112, 4, 8, 15));
        root.addView(tint, new FrameLayout.LayoutParams(-1, -1));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setPadding(dp(14), dp(12), dp(14), dp(24));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(page, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        page.addView(buildHeader());
        page.addView(space(12));
        page.addView(buildNavigation());
        page.addView(space(18));

        TextView heading = label("Editor de skins", 22, TEXT, true);
        page.addView(heading);
        TextView subtitle = label("Crie, personalize e exporte suas artes.", 13, MUTED, false);
        page.addView(subtitle);
        page.addView(space(12));

        LinearLayout canvasPanel = panel();
        canvasPanel.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout canvasHeader = new LinearLayout(this);
        canvasHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView canvasTitle = label("ÁREA DE EDIÇÃO", 11, MUTED, true);
        canvasHeader.addView(canvasTitle, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView clearButton = button("Limpar", false);
        clearButton.setOnClickListener(v -> confirmClear());
        canvasHeader.addView(clearButton);
        canvasPanel.addView(canvasHeader);
        canvasPanel.addView(space(8));
        paintCanvas = new PaintCanvasView();
        paintCanvas.setMinimumHeight(dp(300));
        canvasPanel.addView(paintCanvas, new LinearLayout.LayoutParams(-1, dp(330)));
        page.addView(canvasPanel);

        page.addView(space(14));
        page.addView(sectionTitle("Ferramentas"));
        page.addView(space(8));
        page.addView(buildTools());
        page.addView(space(14));
        page.addView(sectionTitle("Cores rápidas"));
        page.addView(space(8));
        page.addView(buildPalette());
        page.addView(space(14));
        page.addView(buildBrushSettings());
        page.addView(space(14));
        page.addView(buildLayersPanel());
        page.addView(space(14));

        TextView footer = label("FULLDESIGN SKIN STUDIO  •  INTERFACE PREVIEW", 10, MUTED, true);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(8), 0, dp(8));
        page.addView(footer);
    }

    private View buildHeader() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout branding = new LinearLayout(this);
        branding.setOrientation(LinearLayout.VERTICAL);
        TextView brand = label("Fulldesign", 25, TEXT, true);
        brand.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD_ITALIC));
        branding.addView(brand);
        TextView sub = label("SKIN STUDIO", 11, BLUE, true);
        sub.setLetterSpacing(0.18f);
        branding.addView(sub);
        row.addView(branding, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView undo = button("↶", false);
        undo.setTextSize(24);
        undo.setOnClickListener(v -> paintCanvas.undo());
        row.addView(undo);
        TextView redo = button("↷", false);
        redo.setTextSize(24);
        LinearLayout.LayoutParams redoParams = new LinearLayout.LayoutParams(-2, dp(44));
        redoParams.leftMargin = dp(6);
        row.addView(redo, redoParams);
        redo.setOnClickListener(v -> paintCanvas.redo());
        return row;
    }

    private View buildNavigation() {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"Editor", "Modelos", "Arquivos", "Exportar", "Skin Packs"};
        for (String name : names) {
            TextView tab = button(name, name.equals("Editor"));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, dp(42));
            p.rightMargin = dp(8);
            tabs.addView(tab, p);
            tab.setOnClickListener(v -> onSectionSelected(name));
        }
        hsv.addView(tabs);
        return hsv;
    }

    private void onSectionSelected(String name) {
        if ("Arquivos".equals(name)) {
            importImage();
        } else if ("Exportar".equals(name)) {
            exportImage();
        } else if ("Modelos".equals(name)) {
            showModelsDialog();
        } else if ("Skin Packs".equals(name)) {
            new AlertDialog.Builder(this)
                    .setTitle("Skin Packs")
                    .setMessage("A interface está pronta. A lista de packs precisa ser conectada aos arquivos de skins do projeto atual.")
                    .setPositiveButton("Entendi", null).show();
        } else {
            Toast.makeText(this, "Você está no editor.", Toast.LENGTH_SHORT).show();
        }
    }

    private View buildTools() {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"Pincel", "Borracha", "Conta-gotas", "Preencher", "Selecionar", "Texto"};
        String[] symbols = {"✎", "▱", "◉", "◩", "□", "T"};
        for (int i = 0; i < names.length; i++) {
            final String name = names[i];
            LinearLayout tool = new LinearLayout(this);
            tool.setOrientation(LinearLayout.VERTICAL);
            tool.setGravity(Gravity.CENTER);
            tool.setPadding(dp(15), dp(10), dp(15), dp(10));
            tool.setBackground(panelBackground(i == 0 ? BLUE : SURFACE, i == 0 ? 0.92f : 0.92f, 14));
            TextView icon = label(symbols[i], 22, TEXT, true);
            icon.setGravity(Gravity.CENTER);
            tool.addView(icon);
            TextView caption = label(name, 11, TEXT, false);
            caption.setGravity(Gravity.CENTER);
            tool.addView(caption);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, dp(76));
            params.rightMargin = dp(8);
            tools.addView(tool, params);
            tool.setOnClickListener(v -> activateTool(name));
        }
        hsv.addView(tools);
        return hsv;
    }

    private void activateTool(String name) {
        currentTool = name;
        if ("Pincel".equals(name)) {
            paintCanvas.setEraser(false);
            paintCanvas.setDrawingColor(selectedColor);
            Toast.makeText(this, "Pincel selecionado", Toast.LENGTH_SHORT).show();
        } else if ("Borracha".equals(name)) {
            paintCanvas.setEraser(true);
            Toast.makeText(this, "Borracha selecionada", Toast.LENGTH_SHORT).show();
        } else {
            new AlertDialog.Builder(this)
                    .setTitle(name)
                    .setMessage("O controle visual está criado. Esta ferramenta avançada precisa ser ligada à lógica de edição do projeto original.")
                    .setPositiveButton("OK", null).show();
        }
    }

    private View buildPalette() {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout swatches = new LinearLayout(this);
        swatches.setOrientation(LinearLayout.HORIZONTAL);
        int[] colors = {
                Color.parseColor("#0067FF"), Color.parseColor("#19D3FF"), Color.parseColor("#7C4DFF"),
                Color.parseColor("#FF3D81"), Color.parseColor("#FF4D25"), Color.parseColor("#FFD43B"),
                Color.parseColor("#35D07F"), Color.WHITE, Color.BLACK
        };
        for (int color : colors) {
            View chip = new View(this);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(color);
            bg.setCornerRadius(dp(18));
            bg.setStroke(dp(color == selectedColor ? 3 : 1), color == selectedColor ? Color.WHITE : Color.argb(130, 255, 255, 255));
            chip.setBackground(bg);
            chip.setContentDescription(String.format("Cor #%06X", (0xFFFFFF & color)));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(38), dp(38));
            p.rightMargin = dp(10);
            swatches.addView(chip, p);
            chip.setOnClickListener(v -> {
                selectedColor = color;
                if (!"Borracha".equals(currentTool)) paintCanvas.setDrawingColor(color);
                for (int i = 0; i < swatches.getChildCount(); i++) {
                    View child = swatches.getChildAt(i);
                    int c = colors[i];
                    GradientDrawable d = new GradientDrawable();
                    d.setColor(c);
                    d.setCornerRadius(dp(18));
                    d.setStroke(dp(c == selectedColor ? 3 : 1), c == selectedColor ? Color.WHITE : Color.argb(130, 255, 255, 255));
                    child.setBackground(d);
                }
                Toast.makeText(this, String.format("Cor #%06X", (0xFFFFFF & color)), Toast.LENGTH_SHORT).show();
            });
        }
        hsv.addView(swatches);
        return hsv;
    }

    private View buildBrushSettings() {
        LinearLayout card = panel();
        LinearLayout line = new LinearLayout(this);
        line.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("Tamanho do pincel", 14, TEXT, true);
        line.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        brushSizeLabel = label("12", 14, TEXT, true);
        line.addView(brushSizeLabel);
        card.addView(line);
        SeekBar seek = new SeekBar(this);
        seek.setMax(60);
        seek.setProgress((int) brushSize - 1);
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(BLUE));
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                brushSize = Math.max(1, progress + 1);
                brushSizeLabel.setText(String.valueOf((int) brushSize));
                paintCanvas.setBrushSize(brushSize);
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        });
        card.addView(seek);
        return card;
    }

    private View buildLayersPanel() {
        LinearLayout card = panel();
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(label("Camadas", 16, TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView add = button("+", false);
        add.setTextSize(22);
        header.addView(add);
        add.setOnClickListener(v -> Toast.makeText(this, "O painel está pronto; gerenciamento real de camadas precisa ser conectado ao formato de skins atual.", Toast.LENGTH_LONG).show());
        card.addView(header);
        card.addView(space(8));
        card.addView(layerRow("◉", "Camada de desenho", true));
        card.addView(layerRow("◉", "Imagem base", false));
        return card;
    }

    private View layerRow(String icon, String title, boolean active) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(2), dp(7), dp(2), dp(7));
        TextView eye = label(icon, 18, active ? BLUE : MUTED, true);
        row.addView(eye);
        TextView name = label(title, 13, TEXT, false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
        p.leftMargin = dp(10);
        row.addView(name, p);
        TextView state = label(active ? "Ativa" : "Base", 11, MUTED, false);
        row.addView(state);
        return row;
    }

    private void showModelsDialog() {
        String[] options = {"Limpar área de edição", "Importar imagem como base", "Voltar ao app atual"};
        new AlertDialog.Builder(this).setTitle("Modelos e ações")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) paintCanvas.clearAll();
                    else if (which == 1) importImage();
                    else openOriginalActivity();
                }).show();
    }

    private void openOriginalActivity() {
        try {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir a tela atual do app. Verifique a declaração da MainActivity no Manifest.", Toast.LENGTH_LONG).show();
        }
    }

    private void importImage() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, REQUEST_IMPORT_IMAGE);
    }

    private void exportImage() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/png");
        intent.putExtra(Intent.EXTRA_TITLE, "fulldesign-skin.png");
        startActivityForResult(intent, REQUEST_EXPORT_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQUEST_IMPORT_IMAGE) {
            try (InputStream input = getContentResolver().openInputStream(uri)) {
                Bitmap bitmap = BitmapFactory.decodeStream(input);
                if (bitmap != null) {
                    paintCanvas.setBaseBitmap(bitmap);
                    Toast.makeText(this, "Imagem carregada na área de edição", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Não foi possível abrir essa imagem.", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQUEST_EXPORT_IMAGE) {
            try (OutputStream output = getContentResolver().openOutputStream(uri)) {
                if (output == null) throw new IllegalStateException("Saída indisponível");
                paintCanvas.exportBitmap().compress(Bitmap.CompressFormat.PNG, 100, output);
                Toast.makeText(this, "PNG exportado com sucesso", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "Falha ao exportar o PNG.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void confirmClear() {
        new AlertDialog.Builder(this)
                .setTitle("Limpar área de edição?")
                .setMessage("Todo o desenho atual será removido.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Limpar", (d, w) -> paintCanvas.clearAll())
                .show();
    }

    private LinearLayout panel() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(14), dp(12), dp(14), dp(12));
        layout.setBackground(panelBackground(SURFACE, 0.94f, 18));
        return layout;
    }

    private TextView sectionTitle(String value) {
        return label(value, 16, TEXT, true);
    }

    private TextView button(String value, boolean primary) {
        TextView view = label(value, 13, TEXT, true);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(14), dp(9), dp(14), dp(9));
        view.setMinHeight(dp(40));
        view.setBackground(panelBackground(primary ? BLUE : SURFACE_2, 0.97f, 13));
        view.setClickable(true);
        view.setFocusable(true);
        return view;
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }

    private View space(int height) {
        View view = new View(this);
        view.setLayoutParams(new LinearLayout.LayoutParams(1, dp(height)));
        return view;
    }

    private GradientDrawable panelBackground(int color, float alpha, int radius) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb((int) (alpha * 255), Color.red(color), Color.green(color), Color.blue(color)));
        bg.setCornerRadius(dp(radius));
        bg.setStroke(dp(1), Color.argb(65, 156, 180, 220));
        return bg;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private final class PaintCanvasView extends View {
        private final List<Stroke> strokes = new ArrayList<>();
        private final List<Stroke> undone = new ArrayList<>();
        private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int canvasBackground = Color.rgb(10, 15, 24);
        private Path currentPath;
        private Paint currentPaint;
        private Bitmap baseBitmap;
        private boolean eraser;
        private int drawColor = BLUE;
        private float lineSize = 12f;
        private float previousX, previousY;

        PaintCanvasView() {
            super(SkinStudioRedesignActivity.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            gridPaint.setColor(Color.argb(32, 150, 173, 212));
            gridPaint.setStrokeWidth(dp(1) * 0.5f);
            textPaint.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD_ITALIC));
            textPaint.setTextAlign(Paint.Align.CENTER);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.drawColor(canvasBackground);
            if (baseBitmap != null) {
                RectF dst = fitRect(baseBitmap.getWidth(), baseBitmap.getHeight(), getWidth(), getHeight());
                Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                canvas.drawBitmap(baseBitmap, null, dst, bp);
                canvas.drawColor(Color.argb(82, 8, 13, 22));
            }
            float step = dp(22);
            for (float x = 0; x < getWidth(); x += step) canvas.drawLine(x, 0, x, getHeight(), gridPaint);
            for (float y = 0; y < getHeight(); y += step) canvas.drawLine(0, y, getWidth(), y, gridPaint);
            textPaint.setColor(Color.argb(32, 210, 222, 245));
            textPaint.setTextSize(dp(36));
            canvas.drawText("FULLDESIGN", getWidth() / 2f, getHeight() / 2f, textPaint);
            for (Stroke stroke : strokes) canvas.drawPath(stroke.path, stroke.paint);
            if (currentPath != null && currentPaint != null) canvas.drawPath(currentPath, currentPaint);
            Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
            border.setStyle(Paint.Style.STROKE);
            border.setStrokeWidth(dp(1));
            border.setColor(Color.argb(120, 67, 92, 132));
            canvas.drawRoundRect(new RectF(dp(1), dp(1), getWidth() - dp(1), getHeight() - dp(1)), dp(10), dp(10), border);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            float x = event.getX(), y = event.getY();
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    currentPath = new Path();
                    currentPath.moveTo(x, y);
                    currentPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                    currentPaint.setStyle(Paint.Style.STROKE);
                    currentPaint.setStrokeCap(Paint.Cap.ROUND);
                    currentPaint.setStrokeJoin(Paint.Join.ROUND);
                    currentPaint.setStrokeWidth(dp(lineSize));
                    currentPaint.setColor(eraser ? canvasBackground : drawColor);
                    previousX = x;
                    previousY = y;
                    invalidate();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (currentPath != null) {
                        currentPath.quadTo(previousX, previousY, (x + previousX) / 2f, (y + previousY) / 2f);
                        previousX = x;
                        previousY = y;
                        invalidate();
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (currentPath != null && currentPaint != null) {
                        currentPath.lineTo(x, y);
                        strokes.add(new Stroke(currentPath, new Paint(currentPaint)));
                        undone.clear();
                        currentPath = null;
                        currentPaint = null;
                        invalidate();
                    }
                    performClick();
                    return true;
                default:
                    return true;
            }
        }

        @Override public boolean performClick() {
            super.performClick();
            return true;
        }

        void setEraser(boolean value) { eraser = value; invalidate(); }
        void setDrawingColor(int color) { drawColor = color; eraser = false; invalidate(); }
        void setBrushSize(float value) { lineSize = value; invalidate(); }
        void setBaseBitmap(Bitmap bitmap) { baseBitmap = bitmap; invalidate(); }
        void clearAll() { strokes.clear(); undone.clear(); currentPath = null; currentPaint = null; baseBitmap = null; invalidate(); }
        void undo() { if (!strokes.isEmpty()) { undone.add(strokes.remove(strokes.size() - 1)); invalidate(); } }
        void redo() { if (!undone.isEmpty()) { strokes.add(undone.remove(undone.size() - 1)); invalidate(); } }

        Bitmap exportBitmap() {
            int width = Math.max(1, getWidth());
            int height = Math.max(1, getHeight());
            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            draw(canvas);
            return bitmap;
        }

        private RectF fitRect(int imageWidth, int imageHeight, int viewWidth, int viewHeight) {
            float scale = Math.min((float) viewWidth / imageWidth, (float) viewHeight / imageHeight);
            float w = imageWidth * scale, h = imageHeight * scale;
            float left = (viewWidth - w) / 2f, top = (viewHeight - h) / 2f;
            return new RectF(left, top, left + w, top + h);
        }
    }

    private static final class Stroke {
        final Path path;
        final Paint paint;
        Stroke(Path path, Paint paint) { this.path = path; this.paint = paint; }
    }
}
