# Fulldesign Skin Studio — pacote de interface para Android

Este pacote adiciona uma Activity separada chamada `SkinStudioRedesignActivity` e o wallpaper escuro com a marca desfocada. Ele **não substitui nem apaga** `MainActivity.java`, as configurações atuais do Gradle, nem o backup Stage 3.

## Arquivos incluídos

- `FulldesignSkinStudio/app/src/main/java/com/fulldesign/skinstudio/SkinStudioRedesignActivity.java` — tela Android nativa com navegação, área de desenho, paleta, tamanho do pincel, desfazer/refazer, importação de imagem e exportação de PNG.
- `FulldesignSkinStudio/app/src/main/assets/skin_studio_wallpaper.png` — fundo com a marca desfocada.
- `docs/visual-reference.png` — imagem de referência visual.
- `AndroidManifest-activity-snippet.xml` — exemplo da declaração da Activity.

## Como colocar os arquivos no repositório

1. Faça upload deste ZIP para a raiz do repositório `Fulldesign-Skins-Studio-` no Codespaces.
2. Abra o terminal na raiz do repositório e execute:

   ```bash
   unzip -o Fulldesign-Skin-Studio-UI-Patch.zip -d /workspaces/Fulldesign-Skins-Studio-
   ```

3. Confira se os arquivos chegaram aos caminhos corretos:

   ```bash
   ls -l /workspaces/Fulldesign-Skins-Studio-/FulldesignSkinStudio/app/src/main/java/com/fulldesign/skinstudio/SkinStudioRedesignActivity.java
   ls -l /workspaces/Fulldesign-Skins-Studio-/FulldesignSkinStudio/app/src/main/assets/skin_studio_wallpaper.png
   ```

## Como registrar a tela no AndroidManifest.xml

Abra `FulldesignSkinStudio/app/src/main/AndroidManifest.xml` e, dentro de `<application>`, adicione a Activity. Para apenas registrar a nova tela sem torná-la a inicial:

```xml
<activity
    android:name=".SkinStudioRedesignActivity"
    android:exported="false" />
```

Para abrir a nova interface ao tocar no ícone do app, mova o filtro `MAIN`/`LAUNCHER` que hoje está em `MainActivity` para `SkinStudioRedesignActivity`:

```xml
<activity
    android:name=".SkinStudioRedesignActivity"
    android:exported="true">
    <intent-filter>
        <action android:name="android.intent.action.MAIN" />
        <category android:name="android.intent.category.LAUNCHER" />
    </intent-filter>
</activity>
```

Deixe `MainActivity` declarada no Manifest, mas sem o filtro `MAIN`/`LAUNCHER`. A nova tela tem a opção **Modelos e ações → Voltar ao app atual** para abrir a `MainActivity` existente. Não deixe duas Activities com o filtro `MAIN`/`LAUNCHER`, pois isso pode criar dois ícones para o mesmo aplicativo.

## Gerar o APK de teste

Depois de ajustar o Manifest, execute:

```bash
cd /workspaces/Fulldesign-Skins-Studio-/FulldesignSkinStudio
if [ -f ./gradlew ]; then
  chmod +x ./gradlew
  ./gradlew assembleDebug
else
  bash ./build.sh
fi
```

Se a compilação terminar com `BUILD SUCCESSFUL`, procure o APK em `app/build/outputs/apk/debug/` e confira o caminho que o Gradle imprimir no final.

## Limites desta primeira versão

A área central já permite desenhar com o dedo, trocar cores, mudar o tamanho do pincel, apagar traços, desfazer/refazer, importar uma imagem e exportar o resultado em PNG. **Isso ainda é uma base de interface e desenho, não um editor completo de texturas/UV do CS 1.6.** Os botões de ferramentas avançadas, as listas de Modelos e Skin Packs e o painel de camadas precisam ser conectados aos recursos existentes do projeto para editar e exportar skins no formato usado pelo aplicativo. O ZIP não contém um APK pronto e não substitui as funções da aplicação original.
