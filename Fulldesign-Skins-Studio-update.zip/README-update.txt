FULLDESIGN SKINS STUDIO — ATUALIZAÇÃO DE CÓDIGO

Conteúdo:
app/src/main/java/com/fulldesign/skinstudio/MainActivity.java

Funcionalidades incluídas nesta etapa:
- Interface escura com acentos roxos/ciano e navegação por páginas.
- Importar e pré-visualizar imagens por meio do seletor de arquivos Android.
- Ajustar saturação e brilho na pré-visualização/exportação.
- Redimensionar a textura e exportar BMP de 24 bits.
- Selecionar imagens múltiplas e exportar um ZIP com pasta textures/, README.txt e MANIFEST.txt.
- Ajustar FOV e exportar arquivo CFG de texto.

Importante:
- O ZIP é um pacote organizado de imagens, não um instalador automático para CS 1.6.
- Visualização 3D de modelos reais e instalação direta no jogo não estão incluídas nesta versão.
- Faça backup antes de substituir o código e teste a compilação no Codespaces.
