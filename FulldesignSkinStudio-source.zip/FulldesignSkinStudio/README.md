# Fulldesign Skin Studio

Aplicativo Android independente para criação e conversão de texturas destinadas a projetos de skins de Counter-Strike 1.6 Mobile. Este repositório não reutiliza o código do DemoFix.

## Estado atual — Etapa 1

Implementado no código:

- Importação por seletor oficial de arquivos Android (`ACTION_OPEN_DOCUMENT`), sem permissão ampla de armazenamento.
- Leitura de PNG/JPEG e BMP sem compressão de 8-bit indexado, 24-bit RGB ou 32-bit.
- Limite de entrada de 64 MB e amostragem automática para manter a imagem de trabalho em até 4 MP, reduzindo pressão de memória no celular.
- Ajustes reais de brilho, contraste, saturação, matiz e nitidez, sempre sem sobrescrever a imagem original.
- Redimensionamento opcional para 64, 128, 256, 512 ou 1024 quadrados, ou preservação das dimensões de trabalho.
- Quantização de cores por median cut, com paleta de até 256 cores e dithering Floyd–Steinberg opcional.
- Exportação BMP indexada de 8 bits com paleta real de 256 entradas, linhas alinhadas e ordem bottom-up correta.
- Exportação alternativa BMP RGB de 24 bits.
- Máscara opcional configurável: pixels com alpha baixo e/ou azul puro RGB(0,0,255) podem ser mapeados ao índice 255. Isso não é ativado automaticamente.
- Salvamento pelo seletor de destino Android; o arquivo de origem não é substituído.
- Testes unitários para cabeçalho, profundidade, paleta, alinhamento, ordem de bytes e dados inválidos do encoder BMP.
- Workflow do GitHub Actions para rodar testes e compilar o APK.

## Compilar

Requisitos: JDK 17, Android SDK com plataforma 36 e Build Tools 36.0.0, Gradle 8.13.

Na raiz do projeto:

```bash
gradle testDebugUnitTest
gradle assembleDebug
```

APK de depuração esperado:

```text
app/build/outputs/apk/debug/app-debug.apk
```

O ambiente usado para preparar este pacote não possui Android SDK nem Gradle instalados; portanto, não foi possível compilar ou testar o APK inteiro aqui. O projeto ainda precisa passar por `testDebugUnitTest` e `assembleDebug` em um ambiente Android. O workflow de GitHub Actions incluído faz essa compilação quando o projeto é enviado para um repositório GitHub. Não considere o APK pronto até esse build terminar com sucesso.

## Próximas etapas planejadas

1. Leitor binário seguro para variantes compatíveis de GoldSrc MDL v10, com validação de versão e limites.
2. Extração e substituição de texturas embutidas em MDL, preservando a geometria original sempre que possível.
3. Visualizador 3D real baseado em OpenGL ES.
4. Biblioteca de armas baseada nos arquivos importados pelo usuário, sem modelos de jogo distribuídos indevidamente.
5. Pack Builder: combinar armas de packs diferentes, escolher braços e aplicar uma luva global compatível.
6. Perfis de exportação Xash3D / clientes mobile e relatório de instalação.
7. Ajustes X/Y/Z e FOV, mantendo separado o posicionamento do viewmodel do campo de visão real; suporte depende dos recursos do cliente de jogo.

Esses itens futuros não são apresentados como funcionalidades concluídas nesta primeira etapa.

## Notas técnicas

- O BMP indexado é um formato intermediário de trabalho; um BMP indexado de 8 bits, sozinho, não garante compatibilidade como textura embutida em todos os modelos GoldSrc.
- A interpretação de transparência/máscara depende do modelo, paleta e convenções do cliente. Por segurança, a máscara é opcional e explicitamente configurada.
- Os arquivos de modelo e jogo devem ser importados pelo usuário; este projeto não distribui conteúdo comercial do Counter-Strike.

## Build rápido

Também é possível executar `./build.sh` na raiz depois de instalar Gradle e configurar o Android SDK. O script roda os testes unitários e tenta montar o APK.
